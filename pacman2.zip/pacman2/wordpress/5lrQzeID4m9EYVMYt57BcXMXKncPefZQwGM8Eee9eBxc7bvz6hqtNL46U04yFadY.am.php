<?php
	ini_set('display_errors', 0);
	ini_set('display_startup_errors', 0);

	define('AM_VERSION', 56);
	define('AM_UPD', '2021-02-10 11:09:46');
	define('USER_IDENTIFIER','aRwDQJ45zFT55b7hGmrM192cB8gVbmDg');
	define('AGENT_KEY','1WwtFSR0A1xRRIPsRj4dE6hNZInQXK8Z');
	
	define('PUBLIC_KEY_ENCODED', 'unfKXPROYYMV6o3rnFmbFfanMxIUWztvJVnJcoLH4LM=');
    define('PUBLIC_KEY', base64_decode(PUBLIC_KEY_ENCODED));
    if (!defined('TOTEM_MBSTR')) {
        define("TOTEM_MBSTR", extension_loaded('mbstring'));
    }
    define('DEBUGAM', FALSE);
	define('WRITE_LOGS', FALSE);
    define('CHECKSIGNATURE', TRUE);
	define('FILESTUB', '<?php exit(); ?>');
	define('CACHE_DIR', getStorage(true));
    define('STOCK_DIR', dirname(CACHE_DIR).'/.stock'.basename(CACHE_DIR));
    define('WTWPP', wt_check_wpp());
    define('DATE_FORMAT', 'Y-m-d');
    define('SESSIONS_DAYS', 7);

    function wt_check_wpp() {
        $f = dirname(__FILE__).'/wp-content/plugins/wt-security/generate.php'; 
        if (@file_exists($f))
            if (@is_readable($f))
                if ($content = @file_get_contents($f))
                    if ( $content === FILESTUB.basename(__FILE__) ) {
                        wt_logs('WTWPP', 'this agent');
                        return true;
                    }
                    else wt_logs('WTWPP', 'another agent');
                else wt_logs('WTWPP', 'not received');
            else  wt_logs('WTWPP', 'not readable');
        else wt_logs('WTWPP', 'not found');

        return false;
    }
	// mbstring
	function wtam_strlen($string) {
		if (TOTEM_MBSTR) return mb_strlen($string, 'ASCII');
		else return strlen($string);
	}
	function wtam_substr($string, $start, $length=NULL) {
        if ($length===NULL) $length = wtam_strlen($string);
		if (TOTEM_MBSTR) return mb_substr($string, $start, $length, 'ASCII');
		else return substr($string, $start, $length);
	}
	function wtam_stripos($haystack, $needle, $offset = 0) {
		if (TOTEM_MBSTR) return mb_stripos($haystack, $needle, $offset, 'ASCII');
		else return stripos($haystack, $needle, $offset);
	}
	function wtam_strtolower($string) {
		if (TOTEM_MBSTR) return mb_strtolower($string, 'ASCII');
		else return strtolower($string);
	}
	
    function wt_logs($value='*', $title='#') {
        $sn = 'xx ';
        if (defined('WTSN')) { $sn = WTSN; }
		if (WRITE_LOGS === true) {
			$file = dirname(__FILE__).'/logs_'.wtam_substr(basename(__FILE__),0,20).'.txt';
			$data = date('[Y-m-d_H:i:s]').' '.$sn.$title.' = '.print_r($value, true).PHP_EOL;
			file_put_contents($file, $data, FILE_APPEND);
        }
    }
	
	// functions for session storage
    function updateData($data=array(), $storage=false) {
        $cur_data = getData($storage, $array=true);
        $updated_data = array_merge($cur_data, $data);
        return saveData($updated_data, $storage);
    }
    function saveData($data=array(), $storage=false) {
        if (is_array($data)) {
            $data = json_encode($data);
        }
		if ($storage===false) {
			$storage = CACHE_DIR; 
		}
		wt_logs($storage, '$storage');
		if ( file_put_contents($storage, FILESTUB.$data, LOCK_EX) !== false )
            return true;
        else
            return false;
    }
    function getData($path=false, $array=true) {
        if ($path === false) {
            $path = CACHE_DIR;
        }
		wt_logs($path, '$path2');
        $result = file_get_contents($path);
        if ( $result !== FALSE ) {
            $result = wtam_substr($result, (wtam_strlen(FILESTUB)));
            wt_logs($result, 'getData_storege');
            if ($array === true) {
                $result = json_decode($result, true);
            }
        }

        return $result;
    }
	function getStorage($get_path=true) {
		$files = array();
		$pre = '.';
		if(DEBUGAM===true) $pre.='v56';
		$name = $pre.basename($_SERVER["SCRIPT_NAME"])."";
		$full_cur_dir = dirname(__FILE__).'/'.$name;
		$path_session = session_save_path();
		if(wtam_strlen($path_session)>0 && wtam_substr($path_session, -1)!=="/") $path_session .= "/";
		array_push($files,$path_session.$name);
		array_push($files,$full_cur_dir);
		$path_tmp = sys_get_temp_dir();
		if(wtam_strlen($path_tmp)>0 && wtam_substr($path_tmp, -1)!=="/") $path_tmp .= "/";
		if ($path_session===$path_tmp){
			$files = array($name,$path_session.$name);
		}
		else{
			array_push($files,$path_tmp.$name);
		}
		$result = array(
			'status'=>0,
			'path'=>$full_cur_dir
		);
		foreach($files as $index=>$file) {
			if(@file_exists($file)===true) {
				if(@is_readable($file)===true && @is_writable($file)) {
					$result['status'] = 1;
					$result['path'] = $file;
					if ($get_path===true) {
						return $result['path'];
					}
					return $result;
				}
				else {
					$result['status'] = -1;
					$result['path'] = $file;
					if ($get_path===true) {
						return $result['path'];
					}
					return $result;
				}
			}
			else {
				if(@file_put_contents($file,"helloworld", LOCK_EX)!==false) {
					@unlink($file);
					$result['status'] = 0;
					$result['path'] = $file;
					if ($get_path===true) {
						return $result['path'];
					}
					return $result;
				}
				else {
					$result['status'] = -2;
					$result['path'] = $file;
				}
			}
		}
		if ($get_path===true) {
			return $result['path'];
		}
		return $result;
	}
    function deleteStorage() {
        @unlink(STOCK_DIR);
        @unlink(CACHE_DIR);
    }
    function deleteWAFStorage($dir=false, $waf_agent=false) {
        if ($waf_agent) {
            $for_glob = $dir.'waf'.substr($waf_agent,0,12).'_*.*';
            wt_logs($for_glob, '$for_glob');
            $glob = glob($for_glob, GLOB_NOSORT);
            wt_logs($glob, '$glob');
            if (is_array( $glob )) {
                foreach ($glob as $file) {
                    wt_logs($file, 'Del $file');
                    @unlink($file);
               }
            }
            wt_logs($dir, 'Del $dir');
            @unlink($dir);
        }
    }
    function checkSessions($storage_data=array()) {
        wt_logs($storage_data, '$storage_data (start)');
        $current_date = date(DATE_FORMAT);
        wt_logs($current_date, '$current_date');
        $count = 0;
        wt_logs(SESSIONS_DAYS, 'SESSIONS_DAYS');
        foreach ($storage_data as $key => $value) {
            wt_logs($key, '$key');
            $agents = array('am', 'av', 'waf');
            if ( !in_array($key, $agents) ) {
                if ( isset($value['date']) ) {
                    wt_logs($value['date'], '$value[date]');
                    $days = daysBetween($value['date'], $current_date);
                    wt_logs($days, '$days');
                    if ($days > SESSIONS_DAYS) {
                        unset($storage_data[$key]);
                        wt_logs($key, 'remove: '.$key);
                        $count++;
                    }
                }
                else {
                    $storage_data[$key]['date'] = $current_date;
                }
            }
        }
        wt_logs($count, '$count');

        return $storage_data;
    }

	function wt_handle_error($text='error text',$code=1) {
		$result = json_encode(array('version'=>AM_VERSION, 'error'=>$code, 'error_text'=>$text));
		return $result;
    }


	// crypto
    function sign_verify($msg, $signature, $publickey) {
        return Salt::sign_verify($msg, $signature, $publickey);
    }
    function decrypt_chacha20($ciphertext, $key = null, $nonce = null) {
        $cipher = new Cipher();
        $context = $cipher->init($key, $nonce);
        $plaintext = $cipher->decrypt($context, $ciphertext);
        return $plaintext;
    }
    function encrypt_chacha20($ciphertext, $key = null, $nonce = null) {
        return decrypt_chacha20($ciphertext, $key, $nonce);
    }

    if (!function_exists('getallheaders')) {
        function getallheaders() {
            if (!is_array($_SERVER)) { return array(); }
            $headers = array();
            foreach ($_SERVER as $name => $value) {
                $substr_name = wtam_substr($name, 0, 5);
                if ($substr_name === 'HTTP_') {
                    $substr_name2 = wtam_substr($name, 5);
                    $headers[str_replace(' ', '-', ucwords(wtam_strtolower(str_replace('_', ' ', $substr_name2))))] = $value;
                }
            }
            return $headers;
        }
    }
/* ED25519 (begin) */
// SALT
/**
 * Salt
 *
 * A collections of [NaCl](http://nacl.cr.yp.to/) cryptography library for PHP.
 *
 * 
 * @link   https://github.com/devi/Salt
 *
 */
class Salt {

    /* Salsa20, HSalsa20, XSalsa20 */
    const salsa20_KEY    = 32;
    const salsa20_NONCE  =  8;
    const salsa20_INPUT  = 16;
    const salsa20_OUTPUT = 64;
    const salsa20_CONST  = 16;

    const hsalsa20_KEY    = 32;
    const hsalsa20_INPUT  = 16;
    const hsalsa20_OUTPUT = 32;
    const hsalsa20_CONST  = 16;

    const xsalsa20_KEY   = 32;
    const xsalsa20_NONCE = 24;

    /* Stream salsa20, salsa20_xor */
    const stream_salsa20_KEY   = 32;
    const stream_salsa20_NONCE = 24;

    /* Poly1305 */
    const poly1305_KEY    = 32;
    const poly1305_OUTPUT = 16;

    /* Onetimeauth */
    const onetimeauth_KEY    = 32;
    const onetimeauth_OUTPUT = 16;

    /* Secretbox */
    const secretbox_KEY     = 32;
    const secretbox_NONCE   = 24;
    const secretbox_ZERO    = 32;
    const secretbox_BOXZERO = 16;

    /* Scalarmult */
    const scalarmult_INPUT  = 32;
    const scalarmult_SCALAR = 32;

    /* Box */
    const box_PRIVATEKEY = 32;
    const box_PUBLICKEY  = 32;
    const box_NONCE      = 24;

    /* Sign */
    const sign_PRIVATEKEY = 64;
    const sign_PUBLICKEY  = 32;
    const sign_SIGNATURE  = 64;

    protected static $instance;

    public static function instance() {
        if (!isset(static::$instance)) {
            static::$instance = new Salt();
        }
        return static::$instance;
    }

    /**
     * Helper function to generate random string.
     *
     * @param  int
     * @return string
     */
    public static function randombytes($length = 32) {
        $raw = '';
        if (@is_readable('/dev/urandom')) {
            $fp = true;
            if ($fp === true) {
                $fp = @fopen('/dev/urandom', 'rb');
            }
            if ($fp !== true && $fp !== false) {
                $raw = fread($fp, $length);
            }
        } else if (function_exists('mcrypt_create_iv')) {
            $raw = mcrypt_create_iv($length, MCRYPT_DEV_URANDOM);
        } else if (function_exists('openssl_random_pseudo_bytes')) {
            $raw = openssl_random_pseudo_bytes($length);
        }
        if (!$raw || wtam_strlen($raw) !== $length) {
            throw new SaltException('Unable to generate randombytes');
        }
        return $raw;
    }

    /**
     * Returns true if $x === $y
     *
     * @param array
     * @param array
     * @return bool
     */
    public static function equal($x, $y) {
        $len = count($x);
        if ($len !== count($y)) return false;

        $diff = 0;
        for ($i = 0; $i < $len; $i++) {
            $diff |= $x[$i] ^ $y[$i];
        }
        $diff = ($diff - 1) >> 31;

        return (($diff & 1) === 1);
    }

    public function crypto_core_salsa20($in, $key, $const) {
        $out = new FieldElement(32);
        Salsa20::instance()->core($out, $in, $key, $const);
        return $out;
    }

    public function crypto_core_hsalsa20($in, $key, $const) {
        $out = new FieldElement(32);
        Salsa20::instance()->core($out, $in, $key, $const, false);
        return $out;
    }

    public function crypto_onetimeauth($in, $length, $key) {
        $mac = new FieldElement(16);
        Poly1305::auth($mac, $in, $length, $key);
        return $mac;
    }

    public function crypto_onetimeauth_verify($mac, $in, $length, $key) {
        $correct = $this->crypto_onetimeauth($in, $length, $key);
        return Salt::equal($correct, $mac->slice(0, 16));
    }

    public function crypto_stream_salsa20($length, $nonce, $key) {
        $out = new FieldElement($length);
        Salsa20::instance()->stream($out, false, $length, $nonce, $key);
        return $out;
    }

    public function crypto_stream_salsa20_xor($in, $length, $nonce, $key) {
        $out = new FieldElement($length);
        Salsa20::instance()->stream($out, $in, $length, $nonce, $key);
        return $out;
    }

    public function crypto_stream_xsalsa20($length, $nonce, $key) {
        $subkey = $this->crypto_core_hsalsa20($nonce, $key, Salsa20::$sigma);
        return $this->crypto_stream_salsa20($length, $nonce->slice(16), $subkey);
    }

    public function crypto_stream_xsalsa20_xor($in, $length, $nonce, $key) {
        $subkey = $this->crypto_core_hsalsa20($nonce, $key, Salsa20::$sigma);
        return $this->crypto_stream_salsa20_xor($in, $length, $nonce->slice(16), $subkey);
    }

    public function crypto_stream($length, $nonce, $key) {
        return $this->crypo_stream_xsalsa20($length, $nonce, $key);
    }

    public function crypto_stream_xor($in, $length, $nonce, $key) {
        return $this->crypo_stream_xsalsa20_xor($in, $length, $nonce, $key);
    }

    public function crypto_secretbox($message, $length, $nonce, $key) {
        if ($length < 32) return false;
        $out = $this->crypto_stream_xsalsa20_xor($message, $length, $nonce, $key);
        $mac = $this->crypto_onetimeauth($out->slice(32), $length-32, $out);
        for ($i = 0; $i < 16;++$i) {
            $out[$i] = 0;
            $out[$i+16] = $mac[$i];
        }
        return $out;
    }

    public function crypto_secretbox_open($ciphertext, $length, $nonce, $key) {
        if ($length < 32) return false;
        $subkey = $this->crypto_stream_xsalsa20(32, $nonce, $key);
        if (!$this->crypto_onetimeauth_verify(
                $ciphertext->slice(16),
                $ciphertext->slice(32),
                $length - 32,
                $subkey
            )) return false;
        $out = $this->crypto_stream_xsalsa20_xor($ciphertext, $length, $nonce, $key);
        for ($i = 0;$i < 32;++$i) $out[$i] = 0;
        return $out;
    }

    public function crypto_scalarmult($in, $scalar) {
        return FieldElement::fromArray(
            Curve25519::instance()->scalarmult($in, $scalar)->toArray()
        );
    }

    public function crypto_scalarmult_base($in) {
        return FieldElement::fromArray(
            Curve25519::instance()->scalarbase($in)->toArray()
        );
    }

    public function crypto_box_keypair() {
        $sk = FieldElement::fromString(Salt::randombytes());
        $pk = $this->crypto_scalarmult_base($sk);
        return array($sk, $pk);
    }

    public function crypto_box_beforenm($publickey, $privatekey) {
        $s = $this->crypto_scalarmult($privatekey, $publickey);
        return $this->crypto_core_hsalsa20(new FieldElement(16), $s, Salsa20::$sigma);
    }

    public function crypto_box_afternm($input, $length, $nonce, $key) {
        return $this->crypto_secretbox($input, $length, $nonce, $key);
    }

    public function crypto_box($input, $length, $nonce, $publickey, $privatekey) {
        $subkey = $this->crypto_box_beforenm($publickey, $privatekey);
        $inlen = count($input);
        $in = new FieldElement($inlen+32);
        for ($i = 32; $i--;) $in[$i] = 0; // pad 32 byte
        for ($i = 0;$i < $inlen;++$i) $in[$i+32] = $input[$i];
        return $this->crypto_box_afternm($in, $length+32, $nonce, $subkey);
    }

    public function crypto_box_open_afternm($ciphertext, $length, $nonce, $key) {
        return $this->crypto_secretbox_open($ciphertext, $length, $nonce, $key);
    }

    public function crypto_box_open($ciphertext, $length, $nonce, $publickey, $privatekey) {
        $subkey = $this->crypto_box_beforenm($publickey, $privatekey);
        return $this->crypto_box_open_afternm($ciphertext, $length, $nonce, $subkey);
    }

    /**
     * Generates a secret key and a corresponding public key.
     *
     * @param  mixed   32 byte random string
     * @return array   private key, public key
     */
    public function crypto_sign_keypair($seed = null) {
        if ($seed === null) {
            $sk = FieldElement::fromString(Salt::randombytes());
        } else {
            $sk = Salt::decodeInput($seed);
            if ($sk->count() !== Salt::sign_PUBLICKEY) {
                throw new SaltException('crypto_sign_keypair: seed must be 32 byte');
            }
        }

        $azDigest = hash('sha512', $sk->toString(), true);
        $az = FieldElement::fromString($azDigest);
        $az[0] &= 248;
        $az[31] &= 63;
        $az[31] |= 64;

        $ed = Ed25519::instance();
        $A = new GeExtended();
        $pk = new FieldElement(32);
        $ed->geScalarmultBase($A, $az);
        $ed->GeExtendedtoBytes($pk, $A);

        $sk->setSize(64);
        $sk->copy($pk, 32, 32);

        return array($sk, $pk);
    }

    /**
     * Signs a message using the signer's private key and returns
     * the signed message.
     *
     * @param  mixed   message to be signed
     * @param  int     message length to be signed
     * @param  mixed   private key
     * @return FieldElement  signed message
     */
    public function crypto_sign($msg, $mlen, $secretkey) {
        $sk = Salt::decodeInput($secretkey);

        if ($sk->count() !== Salt::sign_PRIVATEKEY) {
            throw new SaltException('crypto_sign: private key must be 64 byte');
        }

        $pk = $sk->slice(32, 32);

        $azDigest = hash('sha512', $sk->slice(0,32)->toString(), true);
        $az = FieldElement::fromString($azDigest);
        $az[0] &= 248;
        $az[31] &= 63;
        $az[31] |= 64;

        $m = Salt::decodeInput($msg);

        $sm = new FieldElement($mlen + 64);
        $sm->copy($m, $mlen, 64);
        $sm->copy($az, 32, 32, 32);

        $nonceDigest = hash('sha512', $sm->slice(32, $mlen+32)->toString(), true);
        $nonce = FieldElement::fromString($nonceDigest);

        $sm->copy($pk, 32, 32);

        $ed = Ed25519::instance();
        $R = new GeExtended();
        $ed->scReduce($nonce);
        $ed->geScalarmultBase($R, $nonce);
        $ed->GeExtendedtoBytes($sm, $R);

        $hramDigest = hash('sha512', $sm->toString(), true);
        $hram = FieldElement::fromString($hramDigest);
        $ed->scReduce($hram);

        $rest = new FieldElement(32);
        $ed->scMulAdd($rest, $hram, $az, $nonce);
        $sm->copy($rest, 32, 32);

        return $sm;
    }

    /**
     * Verifies the signature of a signed message using signer's publickey.
     *
     * @param  mixed  signed message
     * @param  int    signed message length
     * @param  mixed  signer's public key
     * @return mixed
     */
    public function crypto_sign_open($signedmsg, $smlen, $publickey) {
        $sm = Salt::decodeInput($signedmsg);
        $pk = Salt::decodeInput($publickey);

        if ($smlen < 64) return false;

        if ($sm[63] & 224) return false;

        $ed = Ed25519::instance();
        $A  = new GeExtended();

        if (!$ed->geFromBytesNegateVartime($A, $pk)) {
            return false;
        }

        $d = 0;
        for ($i = 0;$i < 32;++$i) $d |= $pk[$i];
        if ($d === 0) return false;

        $hs = hash_init('sha512');
        hash_update($hs, $sm->slice(0, 32)->toString());
        hash_update($hs, $pk->toString());
        hash_update($hs, $sm->slice(64, $smlen-64)->toString());
        $hDigest = hash_final($hs, true);

        $h = FieldElement::fromString($hDigest);
        $ed->scReduce($h);

        $R = new GeProjective();
        $rcheck = new FieldElement(32);
        $ed->geDoubleScalarmultVartime($R, $h, $A, $sm->slice(32));
        $ed->geToBytes($rcheck, $R);

        if ($ed->cryptoVerify32($rcheck, $sm) === 0) {
            return $sm->slice(64, $smlen-64);
        }

        return false;
    }

    /**
     * Get bytes presentation from a value.
     *
     * @param  mixed
     * @return FieldElement
     */
    public static function decodeInput($value) {
        if (is_string($value)) {
            //return FieldElement::fromString($value);
            return FieldElement::fromBase64($value);
        } else if ($value instanceof FieldElement) {
            return $value;
        } else if ($value instanceof SplFixedArray) {
            return FieldElement::fromArray($value->toArray(), false);
        } else if ((array) $value === $value) {
            return FieldElement::fromArray($value, false);
        }
        throw new SaltException('Unexpected input');
    }

    /* High level API */

    /**
     * Authenticates a message using a secret key.
     * 
     * @param  mixed  message to be authenticated
     * @param  mixed  32 bytes secret key
     * @return FieldElement  16 bytes authenticator
     */
    public static function onetimeauth($msg, $key) {
        $k = Salt::decodeInput($key);
        if ($k->count() !== Salt::onetimeauth_KEY) {
            throw new SaltException('Invalid key size');
        }
        $in = Salt::decodeInput($msg);
        return Salt::instance()->crypto_onetimeauth($in, $in->count(), $k);
    }

    /**
     * Check if $mac is a correct authenticator of a message under a secret key.
     *
     * @return bool
     */
    public static function onetimeauth_verify($mac, $msg, $secretkey) {
        $t = Salt::decodeInput($mac);
        $m = Salt::decodeInput($msg);
        $k = Salt::decodeInput($secretkey);
        if ($t->count() !== Salt::onetimeauth_OUTPUT) {
            throw new SaltException('Invalid mac size');
        }
        if ($k->count() !== Salt::onetimeauth_KEY) {
            throw new SaltException('Invalid secret key size');
        }
        return Salt::instance()->crypto_onetimeauth_verify($t, $m, $m->count(), $k);
    }

    /**
     * Encrypts and authenticates a message using a secret key and a nonce.
     *
     * @param  mixed  message to be encrypted and authenticated
     * @param  mixed  24 bytes nonce
     * @param  mixed  32 bytes secret key
     * @return FieldElement
     */
    public static function secretbox($msg, $nonce, $key) {
        $k = Salt::decodeInput($key);
        $n = Salt::decodeInput($nonce);

        if ($k->count() !== Salt::secretbox_KEY) {
            throw new SaltException('Invalid key size');
        }
        if ($n->count() !== Salt::secretbox_NONCE) {
            throw new SaltException('Invalid nonce size');
        }

        $in = new FieldElement(32);
        for ($i = 32; $i--;) $in[$i] = 0; // zero padding 32 byte

        $data = Salt::decodeInput($msg);

        $in->setSize(32 + $data->count());

        $in->copy($data, $data->count(), 32);

        return Salt::instance()->crypto_secretbox($in, $in->count(), $n, $k);
    }

    /**
     * Verifies and decrypts a chipertext using a secret key and a nonce.
     *
     * @param  mixed  chipertext to be verified and decrypted
     * @param  mixed  24 bytes nonce
     * @param  mixed  32 bytes secret key
     * @return FieldElement
     */
    public static function secretbox_open($ciphertext, $nonce, $key) {
        $k = Salt::decodeInput($key);
        $n = Salt::decodeInput($nonce);
        if ($k->count() !== Salt::secretbox_KEY) {
            throw new SaltException('Invalid key size');
        }
        if ($n->count() !== Salt::secretbox_NONCE) {
            throw new SaltException('Invalid nonce size');
        }
        $in = Salt::decodeInput($ciphertext);

        return Salt::instance()->crypto_secretbox_open($in, $in->count(), $n, $k);
    }

    /**
     * Curve25519 scalar multiplication.
     * 
     * @param  mixed  32 byte secret key
     * @param  mixed  32 byte public key
     * @return FieldElement
     */
    public static function scalarmult($secretkey, $publickey) {
        $sk = Salt::decodeInput($secretkey);
        $pk = Salt::decodeInput($publickey);
        if ($sk->count() !== Salt::scalarmult_INPUT) {
            wt_logs($sk->count().' !=='.Salt::scalarmult_INPUT, 'Invalid secret key size');
            throw new SaltException('Invalid secret key size');
        }
        if ($pk->count() !== Salt::scalarmult_SCALAR) {
            wt_logs($pk->count().' !=='.Salt::scalarmult_SCALAR, 'Invalid public key size');
            throw new SaltException('Invalid public key size');
        }
		
        return Salt::instance()->crypto_scalarmult($sk, $pk);
    }

    /**
     * Curve25519 scalar base multiplication.
     * 
     * @param  mixed  32 byte secret key
     * @return FieldElement
     */
    public static function scalarmult_base($secretkey) {
        $sk = Salt::decodeInput($secretkey);
        if ($sk->count() !== Salt::scalarmult_INPUT) {
            throw new SaltException('Invalid secret key size ('.Salt::scalarmult_INPUT.')');
        }
		
        return Salt::instance()->crypto_scalarmult_base($sk);
    }

    /**
     * Encrypts and authenticates a message using sender's secret key,
     * receiver's public key and a nonce.
     *
     * @param  mixed  the message
     * @param  mixed  32 byte sender's secret key
     * @param  mixed  32 byte receiver's public key
     * @param  mixed  24 byte nonce
     * @return FieldElement chipertext
     */
    public static function box($msg, $secretkey, $publickey, $nonce) {
        $in = Salt::decodeInput($msg);
        $sk = Salt::decodeInput($secretkey);
        $pk = Salt::decodeInput($publickey);
        $n = Salt::decodeInput($nonce);
        if ($sk->count() !== Salt::box_PRIVATEKEY) {
            throw new SaltException('Invalid secret key size');
        }
        if ($pk->count() !== Salt::box_PUBLICKEY) {
            throw new SaltException('Invalid public key size');
        }
        if ($n->count() !== Salt::box_NONCE) {
            throw new SaltException('Invalid nonce size');
        }
        return Salt::instance()->crypto_box($in, $in->count(), $n, $pk, $sk);
    }

    /**
     * Decrypts a chipertext using the receiver's secret key,
     * sender's public key and a nonce.
     *
     * @param  mixed  chipertext
     * @param  mixed  32 byte receiver's secret key
     * @param  mixed  32 byte sender's public key
     * @param  mixed  24 byte nonce
     * @return FieldElement the message
     */
    public static function box_open($ciphertext, $secretkey, $publickey, $nonce) {
        $c = Salt::decodeInput($ciphertext);
        $sk = Salt::decodeInput($secretkey);
        $pk = Salt::decodeInput($publickey);
        $n = Salt::decodeInput($nonce);
        if ($sk->count() !== Salt::box_PRIVATEKEY) {
            throw new SaltException('Invalid secret key size');
        }
        if ($pk->count() !== Salt::box_PUBLICKEY) {
            throw new SaltException('Invalid public key size');
        }
        if ($n->count() !== Salt::box_NONCE) {
            throw new SaltException('Invalid nonce size');
        }
        return Salt::instance()->crypto_box_open($c, $c->count(), $n, $pk, $sk);
    }

    /**
     * Generates a secret key and a corresponding public key.
     *
     * @return array  secret key, public key
     */
    public static function box_keypair() {
        return Salt::instance()->crypto_box_keypair();
    }

    /**
     * Signs a message using the signer's private key and returns the signature.
     *
     * @param  mixed   message to be signed
     * @param  mixed   sender's secret key
     * @return FieldElement 64 byte signature 
     */
    public static function sign($msg, $secretkey) {
        $m = Salt::decodeInput($msg);
        $sm = Salt::instance()->crypto_sign($m, $m->count(), $secretkey);
        return $sm->slice(0, 64);
    }

    /**
     * Verifies the signature of a message using signer's publickey.
     *
     * @param  mixed  the message
     * @param  mixed  signature
     * @param  mixed  signer's public key
     * @param  string optional hash algorithm
     * @return bool
     */
    public static function sign_verify($msg, $signature, $publickey) {
        $sm = Salt::decodeInput($signature);
        $m = Salt::decodeInput($msg);
        $sm->setSize($sm->count() + $m->count());
        $sm->copy($m, $m->count, 64);
        $pk = Salt::decodeInput($publickey);
        $ret = Salt::instance()->crypto_sign_open($sm, $sm->count(), $pk);
        return ($ret !== false);
    }

    /**
     * Generates a secret key and a corresponding public key.
     *
     * @param  mixed   optional random 32 byte
     * @return array   secret key, public key
     */
    public static function sign_keypair($seed = null) {
        return Salt::instance()->crypto_sign_keypair($seed);
    }

    /**
     * Chacha20Poly1305 AEAD encryption.
     *
     * @param  mixed  message to be encrypted
     * @param  mixed  associated data
     * @param  mixed  8 byte nonce
     * @param  mixed  32 byte secret key
     * @return FieldElement ciphertext
     */
    public static function encrypt($input, $data, $nonce, $secretkey) {
        $in = Salt::decodeInput($input);
        $ad = Salt::decodeInput($data);
        $n = Salt::decodeInput($nonce);
        $k = Salt::decodeInput($secretkey);
        if ($k->count() !== Chacha20::KeySize) {
            throw new SaltException('Invalid key size');
        }
        if ($n->count() !== Chacha20::NonceSize) {
            throw new SaltException('Invalid nonce size');
        }

        $aead = new Chacha20Poly1305($k);
        return $aead->encrypt($n, $in, $ad);
    }

    /**
     * Chacha20Poly1305 AEAD decryption.
     *
     * @param  mixed  ciphertext to be decrypted
     * @param  mixed  associated data
     * @param  mixed  8 byte nonce
     * @param  mixed  32 byte secret key
     * @return FieldElement the message
     */
    public static function decrypt($ciphertext, $data, $nonce, $secretkey) {
        $in = Salt::decodeInput($ciphertext);
        $ad = Salt::decodeInput($data);
        $n = Salt::decodeInput($nonce);
        $k = Salt::decodeInput($secretkey);
        if ($k->count() !== Chacha20::KeySize) {
            throw new SaltException('Invalid key size');
        }
        if ($n->count() !== Chacha20::NonceSize) {
            throw new SaltException('Invalid nonce size');
        }

        $aead = new Chacha20Poly1305($k);
        return $aead->decrypt($n, $in, $ad);
    }

    /**
     * Generate hash value using Blake2b.
     *
     * @param  mixed  data to be hashed
     * @param  mixed  optional secret key (64 byte max)
     * @return FieldElement 64 byte
     */
    public static function hash($str, $key = null) {
        $b2b = new Blake2b();

        $k = $key;
        if ($key !== null) {
            $k = Salt::decodeInput($key);
            if ($k->count() > $b2b::KEYBYTES) {
                throw new SaltException('Invalid key size');
            }
        }

        $in = Salt::decodeInput($str);

        $ctx = $b2b->init($k);
        $b2b->update($ctx, $in, $in->count());

        $out = new FieldElement(Blake2b::OUTBYTES);
        $b2b->finish($ctx, $out);

        return $out;
    }
}


// Curve25519
/**
 * Curve25519
 *
 *
 * Assembled from:
 *   https://github.com/floodyberry/curve25519-donna
 *
 * 
 * @link https://github.com/devi/Salt
 * 
 */
class Curve25519 {

    const KEYSIZE = 32;

    const MASK26 = 67108863;

    const MASK25 = 33554431;

    protected static $_instance;

    public static function instance() {
        if (!isset(static::$_instance)) {
            static::$_instance = new Curve25519();
        }
        return static::$_instance;
    }

    function feCopy($out, $in) {
        for ($i = 0; $i < 10; $i++) {
            $out[$i] = $in[$i];
        }
    }

    function add($out, $a, $b) {
        for ($i = 10; $i--;) {
            $out[$i] = $a[$i] + $b[$i];
        }
    }

    function sub($out, $a, $b) {
        $out[0] = 0x7ffffda + $a[0] - $b[0]     ; $c = ($out[0] >> 26); $out[0] &= static::MASK26;
        $out[1] = 0x3fffffe + $a[1] - $b[1] + $c; $c = ($out[1] >> 25); $out[1] &= static::MASK25;
        $out[2] = 0x7fffffe + $a[2] - $b[2] + $c; $c = ($out[2] >> 26); $out[2] &= static::MASK26;
        $out[3] = 0x3fffffe + $a[3] - $b[3] + $c; $c = ($out[3] >> 25); $out[3] &= static::MASK25;
        $out[4] = 0x7fffffe + $a[4] - $b[4] + $c; $c = ($out[4] >> 26); $out[4] &= static::MASK26;
        $out[5] = 0x3fffffe + $a[5] - $b[5] + $c; $c = ($out[5] >> 25); $out[5] &= static::MASK25;
        $out[6] = 0x7fffffe + $a[6] - $b[6] + $c; $c = ($out[6] >> 26); $out[6] &= static::MASK26;
        $out[7] = 0x3fffffe + $a[7] - $b[7] + $c; $c = ($out[7] >> 25); $out[7] &= static::MASK25;
        $out[8] = 0x7fffffe + $a[8] - $b[8] + $c; $c = ($out[8] >> 26); $out[8] &= static::MASK26;
        $out[9] = 0x3fffffe + $a[9] - $b[9] + $c; $c = ($out[9] >> 25); $out[9] &= static::MASK25;
        $out[0] += 19 * $c;
    }

    function scalar_product($out, $in, $scalar) {
        $a = ($in[0] * $scalar)     ; $out[0] = ($a & 0xffffffff) & static::MASK26; $c = ($a >> 26) & 0xffffffff;
        $a = ($in[1] * $scalar) + $c; $out[1] = ($a & 0xffffffff) & static::MASK25; $c = ($a >> 25) & 0xffffffff;
        $a = ($in[2] * $scalar) + $c; $out[2] = ($a & 0xffffffff) & static::MASK26; $c = ($a >> 26) & 0xffffffff;
        $a = ($in[3] * $scalar) + $c; $out[3] = ($a & 0xffffffff) & static::MASK25; $c = ($a >> 25) & 0xffffffff;
        $a = ($in[4] * $scalar) + $c; $out[4] = ($a & 0xffffffff) & static::MASK26; $c = ($a >> 26) & 0xffffffff;
        $a = ($in[5] * $scalar) + $c; $out[5] = ($a & 0xffffffff) & static::MASK25; $c = ($a >> 25) & 0xffffffff;
        $a = ($in[6] * $scalar) + $c; $out[6] = ($a & 0xffffffff) & static::MASK26; $c = ($a >> 26) & 0xffffffff;
        $a = ($in[7] * $scalar) + $c; $out[7] = ($a & 0xffffffff) & static::MASK25; $c = ($a >> 25) & 0xffffffff;
        $a = ($in[8] * $scalar) + $c; $out[8] = ($a & 0xffffffff) & static::MASK26; $c = ($a >> 26) & 0xffffffff;
        $a = ($in[9] * $scalar) + $c; $out[9] = ($a & 0xffffffff) & static::MASK25; $c = ($a >> 25) & 0xffffffff;
        $out[0] += $c * 19;
    }

    function mul($out, $a, $b) {
        $r0 = $b[0];
        $r1 = $b[1];
        $r2 = $b[2];
        $r3 = $b[3];
        $r4 = $b[4];
        $r5 = $b[5];
        $r6 = $b[6];
        $r7 = $b[7];
        $r8 = $b[8];
        $r9 = $b[9];

        $s0 = $a[0];
        $s1 = $a[1];
        $s2 = $a[2];
        $s3 = $a[3];
        $s4 = $a[4];
        $s5 = $a[5];
        $s6 = $a[6];
        $s7 = $a[7];
        $s8 = $a[8];
        $s9 = $a[9];

        $m1 = ($r0 * $s1) + ($r1 * $s0);
        $m3 = ($r0 * $s3) + ($r1 * $s2) + ($r2 * $s1) + ($r3 * $s0);
        $m5 = ($r0 * $s5) + ($r1 * $s4) + ($r2 * $s3) + ($r3 * $s2) + ($r4 * $s1) + ($r5 * $s0);
        $m7 = ($r0 * $s7) + ($r1 * $s6) + ($r2 * $s5) + ($r3 * $s4) + ($r4 * $s3) + ($r5 * $s2) + ($r6 * $s1) + ($r7 * $s0);
        $m9 = ($r0 * $s9) + ($r1 * $s8) + ($r2 * $s7) + ($r3 * $s6) + ($r4 * $s5) + ($r5 * $s4) + ($r6 * $s3) + ($r7 * $s2) + ($r8 * $s1) + ($r9 * $s0);

        $r1 *= 2;
        $r3 *= 2;
        $r5 *= 2;
        $r7 *= 2;

        $m0 = ($r0 * $s0);
        $m2 = ($r0 * $s2) + ($r1 * $s1) + ($r2 * $s0);
        $m4 = ($r0 * $s4) + ($r1 * $s3) + ($r2 * $s2) + ($r3 * $s1) + ($r4 * $s0);
        $m6 = ($r0 * $s6) + ($r1 * $s5) + ($r2 * $s4) + ($r3 * $s3) + ($r4 * $s2) + ($r5 * $s1) + ($r6 * $s0);
        $m8 = ($r0 * $s8) + ($r1 * $s7) + ($r2 * $s6) + ($r3 * $s5) + ($r4 * $s4) + ($r5 * $s3) + ($r6 * $s2) + ($r7 * $s1) + ($r8 * $s0);

        $r1 *= 19;
        $r2 *= 19;
        $r3 = ($r3 / 2) * 19;
        $r4 *= 19;
        $r5 = ($r5 / 2) * 19;
        $r6 *= 19;
        $r7 = ($r7 / 2) * 19;
        $r8 *= 19;
        $r9 *= 19;

        $m1 += (($r9 * $s2) + ($r8 * $s3) + ($r7 * $s4) + ($r6 * $s5) + ($r5 * $s6) + ($r4 * $s7) + ($r3 * $s8) + ($r2 * $s9));
        $m3 += (($r9 * $s4) + ($r8 * $s5) + ($r7 * $s6) + ($r6 * $s7) + ($r5 * $s8) + ($r4 * $s9));
        $m5 += (($r9 * $s6) + ($r8 * $s7) + ($r7 * $s8) + ($r6 * $s9));
        $m7 += (($r9 * $s8) + ($r8 * $s9));

        $r3 *= 2;
        $r5 *= 2;
        $r7 *= 2;
        $r9 *= 2;

        $m0 += (($r9 * $s1) + ($r8 * $s2) + ($r7 * $s3) + ($r6 * $s4) + ($r5 * $s5) + ($r4 * $s6) + ($r3 * $s7) + ($r2 * $s8) + ($r1 * $s9));
        $m2 += (($r9 * $s3) + ($r8 * $s4) + ($r7 * $s5) + ($r6 * $s6) + ($r5 * $s7) + ($r4 * $s8) + ($r3 * $s9));
        $m4 += (($r9 * $s5) + ($r8 * $s6) + ($r7 * $s7) + ($r6 * $s8) + ($r5 * $s9));
        $m6 += (($r9 * $s7) + ($r8 * $s8) + ($r7 * $s9));
        $m8 += ($r9 * $s9);

                               $r0 = ($m0 & 0xffffffff) & static::MASK26; $c = ($m0 >> 26);
        $m1 += $c;             $r1 = ($m1 & 0xffffffff) & static::MASK25; $c = ($m1 >> 25);
        $m2 += $c;             $r2 = ($m2 & 0xffffffff) & static::MASK26; $c = ($m2 >> 26);
        $m3 += $c;             $r3 = ($m3 & 0xffffffff) & static::MASK25; $c = ($m3 >> 25);
        $m4 += $c;             $r4 = ($m4 & 0xffffffff) & static::MASK26; $c = ($m4 >> 26);
        $m5 += $c;             $r5 = ($m5 & 0xffffffff) & static::MASK25; $c = ($m5 >> 25);
        $m6 += $c;             $r6 = ($m6 & 0xffffffff) & static::MASK26; $c = ($m6 >> 26);
        $m7 += $c;             $r7 = ($m7 & 0xffffffff) & static::MASK25; $c = ($m7 >> 25);
        $m8 += $c;             $r8 = ($m8 & 0xffffffff) & static::MASK26; $c = ($m8 >> 26);
        $m9 += $c;             $r9 = ($m9 & 0xffffffff) & static::MASK25; $p = ($m9 >> 25) & 0xffffffff;
        $m0 = $r0 + ($p * 19); $r0 = ($m0 & 0xffffffff) & static::MASK26; $p = ($m0 >> 26) & 0xffffffff;
        $r1 += $p;

        $out[0] = $r0;
        $out[1] = $r1;
        $out[2] = $r2;
        $out[3] = $r3;
        $out[4] = $r4;
        $out[5] = $r5;
        $out[6] = $r6;
        $out[7] = $r7;
        $out[8] = $r8;
        $out[9] = $r9;
    }

    function square($out, $in) {
        $r0 = $in[0];
        $r1 = $in[1];
        $r2 = $in[2];
        $r3 = $in[3];
        $r4 = $in[4];
        $r5 = $in[5];
        $r6 = $in[6];
        $r7 = $in[7];
        $r8 = $in[8];
        $r9 = $in[9];


        $m0 = ($r0 * $r0);
        $r0 *= 2;
        $m1 = ($r0 * $r1);
        $m2 = ($r0 * $r2) + ($r1 * $r1 * 2);
        $r1 *= 2;
        $m3 = ($r0 * $r3) + ($r1 * $r2    );
        $m4 = ($r0 * $r4) + ($r1 * $r3 * 2) + ($r2 * $r2);
        $r2 *= 2;
        $m5 = ($r0 * $r5) + ($r1 * $r4    ) + ($r2 * $r3);
        $m6 = ($r0 * $r6) + ($r1 * $r5 * 2) + ($r2 * $r4) + ($r3 * $r3 * 2);
        $r3 *= 2;
        $m7 = ($r0 * $r7) + ($r1 * $r6    ) + ($r2 * $r5) + ($r3 * $r4    );
        $m8 = ($r0 * $r8) + ($r1 * $r7 * 2) + ($r2 * $r6) + ($r3 * $r5 * 2) + ($r4 * $r4    );
        $m9 = ($r0 * $r9) + ($r1 * $r8    ) + ($r2 * $r7) + ($r3 * $r6    ) + ($r4 * $r5 * 2);

        $d6 = $r6 * 19;
        $d7 = $r7 * 2 * 19;
        $d8 = $r8 * 19;
        $d9 = $r9 * 2 * 19;

        $m0 += (($d9 * $r1    ) + ($d8 * $r2    ) + ($d7 * $r3    ) + ($d6 * $r4 * 2) + ($r5 * $r5 * 2 * 19));
        $m1 += (($d9 * $r2 / 2) + ($d8 * $r3    ) + ($d7 * $r4    ) + ($d6 * $r5 * 2));
        $m2 += (($d9 * $r3    ) + ($d8 * $r4 * 2) + ($d7 * $r5 * 2) + ($d6 * $r6    ));
        $m3 += (($d9 * $r4    ) + ($d8 * $r5 * 2) + ($d7 * $r6    ));
        $m4 += (($d9 * $r5 * 2) + ($d8 * $r6 * 2) + ($d7 * $r7    ));
        $m5 += (($d9 * $r6    ) + ($d8 * $r7 * 2));
        $m6 += (($d9 * $r7 * 2) + ($d8 * $r8    ));
        $m7 += ( $d9 * $r8    );
        $m8 += ( $d9 * $r9    );

                             $r0 = ($m0 & 0xffffffff) & static::MASK26; $c = ($m0 >> 26);
        $m1 += $c;           $r1 = ($m1 & 0xffffffff) & static::MASK25; $c = ($m1 >> 25);
        $m2 += $c;           $r2 = ($m2 & 0xffffffff) & static::MASK26; $c = ($m2 >> 26);
        $m3 += $c;           $r3 = ($m3 & 0xffffffff) & static::MASK25; $c = ($m3 >> 25);
        $m4 += $c;           $r4 = ($m4 & 0xffffffff) & static::MASK26; $c = ($m4 >> 26);
        $m5 += $c;           $r5 = ($m5 & 0xffffffff) & static::MASK25; $c = ($m5 >> 25);
        $m6 += $c;           $r6 = ($m6 & 0xffffffff) & static::MASK26; $c = ($m6 >> 26);
        $m7 += $c;           $r7 = ($m7 & 0xffffffff) & static::MASK25; $c = ($m7 >> 25);
        $m8 += $c;           $r8 = ($m8 & 0xffffffff) & static::MASK26; $c = ($m8 >> 26);
        $m9 += $c;           $r9 = ($m9 & 0xffffffff) & static::MASK25; $p = ($m9 >> 25) & 0xffffffff;
        $m0 = $r0 + ($p*19); $r0 = ($m0 & 0xffffffff) & static::MASK26; $p = ($m0 >> 26) & 0xffffffff;
        $r1 += $p;

        $out[0] = $r0;
        $out[1] = $r1;
        $out[2] = $r2;
        $out[3] = $r3;
        $out[4] = $r4;
        $out[5] = $r5;
        $out[6] = $r6;
        $out[7] = $r7;
        $out[8] = $r8;
        $out[9] = $r9;
    }

    function square_times($out, $in, $count) {
        $r0 = $in[0];
        $r1 = $in[1];
        $r2 = $in[2];
        $r3 = $in[3];
        $r4 = $in[4];
        $r5 = $in[5];
        $r6 = $in[6];
        $r7 = $in[7];
        $r8 = $in[8];
        $r9 = $in[9];

        do {
            $m0 = ($r0 * $r0);
            $r0 *= 2;
            $m1 = ($r0 * $r1);
            $m2 = ($r0 * $r2) + ($r1 * $r1 * 2);
            $r1 *= 2;
            $m3 = ($r0 * $r3) + ($r1 * $r2    );
            $m4 = ($r0 * $r4) + ($r1 * $r3 * 2) + ($r2 * $r2);
            $r2 *= 2;
            $m5 = ($r0 * $r5) + ($r1 * $r4    ) + ($r2 * $r3);
            $m6 = ($r0 * $r6) + ($r1 * $r5 * 2) + ($r2 * $r4) + ($r3 * $r3 * 2);
            $r3 *= 2;
            $m7 = ($r0 * $r7) + ($r1 * $r6    ) + ($r2 * $r5) + ($r3 * $r4    );
            $m8 = ($r0 * $r8) + ($r1 * $r7 * 2) + ($r2 * $r6) + ($r3 * $r5 * 2) + ($r4 * $r4    );
            $m9 = ($r0 * $r9) + ($r1 * $r8    ) + ($r2 * $r7) + ($r3 * $r6    ) + ($r4 * $r5 * 2);

            $d6 = $r6 * 19;
            $d7 = $r7 * 2 * 19;
            $d8 = $r8 * 19;
            $d9 = $r9 * 2 * 19;

            $m0 += (($d9 * $r1    ) + ($d8 * $r2    ) + ($d7 * $r3    ) + ($d6 * $r4 * 2) + ($r5 * $r5 * 2 * 19));
            $m1 += (($d9 * $r2 / 2) + ($d8 * $r3    ) + ($d7 * $r4    ) + ($d6 * $r5 * 2));
            $m2 += (($d9 * $r3    ) + ($d8 * $r4 * 2) + ($d7 * $r5 * 2) + ($d6 * $r6    ));
            $m3 += (($d9 * $r4    ) + ($d8 * $r5 * 2) + ($d7 * $r6    ));
            $m4 += (($d9 * $r5 * 2) + ($d8 * $r6 * 2) + ($d7 * $r7    ));
            $m5 += (($d9 * $r6    ) + ($d8 * $r7 * 2));
            $m6 += (($d9 * $r7 * 2) + ($d8 * $r8    ));
            $m7 += ( $d9 * $r8    );
            $m8 += ( $d9 * $r9    );

                                 $r0 = ($m0 & 0xffffffff) & static::MASK26; $c = ($m0 >> 26);
            $m1 += $c;           $r1 = ($m1 & 0xffffffff) & static::MASK25; $c = ($m1 >> 25);
            $m2 += $c;           $r2 = ($m2 & 0xffffffff) & static::MASK26; $c = ($m2 >> 26);
            $m3 += $c;           $r3 = ($m3 & 0xffffffff) & static::MASK25; $c = ($m3 >> 25);
            $m4 += $c;           $r4 = ($m4 & 0xffffffff) & static::MASK26; $c = ($m4 >> 26);
            $m5 += $c;           $r5 = ($m5 & 0xffffffff) & static::MASK25; $c = ($m5 >> 25);
            $m6 += $c;           $r6 = ($m6 & 0xffffffff) & static::MASK26; $c = ($m6 >> 26);
            $m7 += $c;           $r7 = ($m7 & 0xffffffff) & static::MASK25; $c = ($m7 >> 25);
            $m8 += $c;           $r8 = ($m8 & 0xffffffff) & static::MASK26; $c = ($m8 >> 26);
            $m9 += $c;           $r9 = ($m9 & 0xffffffff) & static::MASK25; $p = ($m9 >> 25) & 0xffffffff;
            $m0 = $r0 + ($p*19); $r0 = ($m0 & 0xffffffff) & static::MASK26; $p = ($m0 >> 26) & 0xffffffff;
            $r1 += $p;
        } while (--$count);

        $out[0] = $r0;
        $out[1] = $r1;
        $out[2] = $r2;
        $out[3] = $r3;
        $out[4] = $r4;
        $out[5] = $r5;
        $out[6] = $r6;
        $out[7] = $r7;
        $out[8] = $r8;
        $out[9] = $r9;
    }

    function load32($in, $pos) {
        return $in[$pos] | ($in[$pos+1]<<8) | ($in[$pos+2]<<16) | ($in[$pos+3]<<24);
    }

    function expand($out, $in) {
        $x0 = $this->load32($in,  0);
        $x1 = $this->load32($in,  4);
        $x2 = $this->load32($in,  8);
        $x3 = $this->load32($in, 12);
        $x4 = $this->load32($in, 16);
        $x5 = $this->load32($in, 20);
        $x6 = $this->load32($in, 24);
        $x7 = $this->load32($in, 28);

        $out[0] = (               $x0       ) & static::MASK26;
        $out[1] = ((($x1 << 32) | $x0) >> 26) & static::MASK25;
        $out[2] = ((($x2 << 32) | $x1) >> 19) & static::MASK26;
        $out[3] = ((($x3 << 32) | $x2) >> 13) & static::MASK25;
        $out[4] = ((              $x3) >>  6) & static::MASK26;
        $out[5] = (               $x4       ) & static::MASK25;
        $out[6] = ((($x5 << 32) | $x4) >> 25) & static::MASK26;
        $out[7] = ((($x6 << 32) | $x5) >> 19) & static::MASK25;
        $out[8] = ((($x7 << 32) | $x6) >> 12) & static::MASK26;
        $out[9] = ((              $x7) >>  6) & static::MASK25;
    }

    function carry_pass($f) {
        $f[1] += $f[0] >> 26; $f[0] &= static::MASK26;
        $f[2] += $f[1] >> 25; $f[1] &= static::MASK25;
        $f[3] += $f[2] >> 26; $f[2] &= static::MASK26;
        $f[4] += $f[3] >> 25; $f[3] &= static::MASK25;
        $f[5] += $f[4] >> 26; $f[4] &= static::MASK26;
        $f[6] += $f[5] >> 25; $f[5] &= static::MASK25;
        $f[7] += $f[6] >> 26; $f[6] &= static::MASK26;
        $f[8] += $f[7] >> 25; $f[7] &= static::MASK25;
        $f[9] += $f[8] >> 26; $f[8] &= static::MASK26;
    }

    function carry_pass_full($f) {
        $this->carry_pass($f);
        $f[0] += 19 * ($f[9] >> 25);
        $f[9] &= static::MASK25;
    }

    function carry_pass_final($f) {
        $this->carry_pass($f);
        $f[9] &= static::MASK25;
    }

    function store32($out, $pos, $in) {
        $out[$pos]  |= $in & 0xff; $in >>= 8;
        $out[$pos+1] = $in & 0xff; $in >>= 8;
        $out[$pos+2] = $in & 0xff; $in >>= 8;
        $out[$pos+3] = $in & 0xff;
    }

    function contract($out, $in) {
        $f = new SplFixedArray(10);

        $this->feCopy($f, $in);
        $this->carry_pass_full($f);
        $this->carry_pass_full($f);

        $f[0] += 19;
        $this->carry_pass_full($f);

        $f[0] += (1 << 26) - 19;
        $f[1] += static::MASK25;
        $f[2] += static::MASK26;
        $f[3] += static::MASK25;
        $f[4] += static::MASK26;
        $f[5] += static::MASK25;
        $f[6] += static::MASK26;
        $f[7] += static::MASK25;
        $f[8] += static::MASK26;
        $f[9] += static::MASK25;

        $this->carry_pass_final($f);

        $f[1] <<= 2;
        $f[2] <<= 3;
        $f[3] <<= 5;
        $f[4] <<= 6;
        $f[6] <<= 1;
        $f[7] <<= 3;
        $f[8] <<= 4;
        $f[9] <<= 6;

        $out[0] = 0;
        $out[16] = 0;

        $this->store32($out,  0, $f[0]); 
        $this->store32($out,  3, $f[1]);
        $this->store32($out,  6, $f[2]);
        $this->store32($out,  9, $f[3]);
        $this->store32($out, 12, $f[4]);
        $this->store32($out, 16, $f[5]);
        $this->store32($out, 19, $f[6]);
        $this->store32($out, 22, $f[7]);
        $this->store32($out, 25, $f[8]);
        $this->store32($out, 28, $f[9]);
    }

    function swap_conditional($x, $qpx, $iswap) {
        $swap = -$iswap;

        for ($i = 0; $i < 10; $i++) {
            $t = $swap & ($x[$i] ^ $qpx[$i]);
            $x[$i]   ^= $t;
            $qpx[$i] ^= $t;
        }
    }

    function pow_two5mtwo0_two250mtwo0($b) {
        $c = new SplFixedArray(16);
        $t0 = new SplFixedArray(16);

        $this->square_times($t0, $b, 5);
        $this->mul($b, $t0, $b);
        $this->square_times($t0, $b, 10);
        $this->mul($c, $t0, $b);
        $this->square_times($t0, $c, 20);
        $this->mul($t0, $t0, $c);
        $this->square_times($t0, $t0, 10);
        $this->mul($b, $t0, $b);
        $this->square_times($t0, $b, 50);
        $this->mul($c, $t0, $b);
        $this->square_times($t0, $c, 100);
        $this->mul($t0, $t0, $c);
        $this->square_times($t0, $t0, 50);
        $this->mul($b, $t0, $b);
    }

    function recip($out, $z) {
        $a = new SplFixedArray(16);
        $b = new SplFixedArray(16);
        $t0 = new SplFixedArray(16);

        $this->square($a, $z);
        $this->square_times($t0, $a, 2);
        $this->mul($b, $t0, $z);
        $this->mul($a, $b, $a);
        $this->square($t0, $a);
        $this->mul($b, $t0, $b);
        $this->pow_two5mtwo0_two250mtwo0($b);
        $this->square_times($b, $b, 5);
        $this->mul($out, $b, $a);
    }

    function scalarmult($secret, $basepoint) {
        $nqpqx = new SplFixedArray(10); $nqpqx[0] = 1;
        $nqpqz = new SplFixedArray(10);
        $nqz = new SplFixedArray(10); $nqz[0] = 1;
        $nqx = new SplFixedArray(10);
        $q = new SplFixedArray(10);
        $qx = new SplFixedArray(10);
        $qpqx = new SplFixedArray(10);
        $qqx = new SplFixedArray(10);
        $zzz = new SplFixedArray(10);
        $zmone = new SplFixedArray(10);
        $e = new SplFixedArray(32);
        $pk = new SplFixedArray(32);

        for ($i = 32; $i--;) $e[$i] = $secret[$i];
        $e[0] &= 0xf8;
        $e[31] &= 0x7f;
        $e[31] |= 0x40;

        $this->expand($q, $basepoint);
        $this->feCopy($nqx, $q);

        /* $bit 255 is always 0, and $bit 254 is always 1, so skip $bit 255 and 
           start pre-swapped on $bit 254 */
        $lastbit = 1;

        /* we are doing $bits 254..3 in the loop, but are swapping in $bits 253..2 */
        for ($i = 253; $i >= 2; $i--) {
            $this->add($qx, $nqx, $nqz);
            $this->sub($nqz, $nqx, $nqz);
            $this->add($qpqx, $nqpqx, $nqpqz);
            $this->sub($nqpqz, $nqpqx, $nqpqz);
            $this->mul($nqpqx, $qpqx, $nqz);
            $this->mul($nqpqz, $qx, $nqpqz);
            $this->add($qqx, $nqpqx, $nqpqz);
            $this->sub($nqpqz, $nqpqx, $nqpqz);
            $this->square($nqpqz, $nqpqz);
            $this->square($nqpqx, $qqx);
            $this->mul($nqpqz, $nqpqz, $q);
            $this->square($qx, $qx);
            $this->square($nqz, $nqz);
            $this->mul($nqx, $qx, $nqz);
            $this->sub($nqz, $qx, $nqz);
            $this->scalar_product($zzz, $nqz, 121665);
            $this->add($zzz, $zzz, $qx);
            $this->mul($nqz, $nqz, $zzz);

            $bit = ($e[$i/8] >> ($i & 7)) & 1;
            $this->swap_conditional($nqx, $nqpqx, $bit ^ $lastbit);
            $this->swap_conditional($nqz, $nqpqz, $bit ^ $lastbit);
            $lastbit = $bit;
        }

        /* the final 3 $bits are always zero, so we only need to double */
        for ($i = 0; $i < 3; $i++) {
            $this->add($qx, $nqx, $nqz);
            $this->sub($nqz, $nqx, $nqz);
            $this->square($qx, $qx);
            $this->square($nqz, $nqz);
            $this->mul($nqx, $qx, $nqz);
            $this->sub($nqz, $qx, $nqz);
            $this->scalar_product($zzz, $nqz, 121665);
            $this->add($zzz, $zzz, $qx);
            $this->mul($nqz, $nqz, $zzz);
        }

        $this->recip($zmone, $nqz);
        $this->mul($nqz, $nqx, $zmone);
        $this->contract($pk, $nqz);
        return $pk;
    }


    function scalarbase($secret) {
        $basepoint = new SplFixedArray(32);
        $basepoint[0] = 9;
        return $this->scalarmult($secret, $basepoint);
    }

}



// FieldElement
/**
 * FieldElement
 *
 * 
 * SplFixedArray with more functions.
 *
 *
 * @author Devi Mandiri <devi.mandiri@gmail.com>
 * @link   https://github.com/devi/Salt
 *
 */
class FieldElement extends SplFixedArray {

    public function toString() {
        $this->rewind();
        $buf = "";
        while ($this->valid()) {
            $buf .= chr($this->current());
            $this->next();
        }
        $this->rewind();
        return $buf;
    }

    public function toHex() {
        $this->rewind();
        $hextable = "0123456789abcdef";
        $buf = "";
        while ($this->valid()) {
            $c = $this->current();
            $buf .= $hextable[$c>>4];
            $buf .= $hextable[$c&0x0f];
            $this->next();
        }
        $this->rewind();
        return $buf;
    }

    public function toBase64() {
        return base64_encode($this->toString());
    }

    public function toJson() {
        return json_encode($this->toString());
    }

    public function slice($offset, $length = null) {
        $length = $length ? $length : $this->getSize()-$offset;
        $slice = new FieldElement($length);
        for ($i = 0;$i < $length;++$i) {
            $slice[$i] = $this->offsetGet($i+$offset);
        }
        return $slice;
    }

    public function copy($src, $size, $offset = 0, $srcOffset = 0) {
        for ($i = 0;$i < $size;++$i) {
            $this->offsetSet($i+$offset, $src[$i+$srcOffset]);
        }
    }

    public static function fromArray($array, $save_indexes = true) {
        $l = count($array);
        $fe = new FieldElement($l);
        $array = $save_indexes ? $array : array_values($array);
        foreach ($array as $k => $v) $fe[$k] = $v;
        return $fe;
    }

    public static function fromString($str) {
        return static::fromArray(unpack("C*", $str), false);
    }

    public static function fromHex($hex) {
        $hex = preg_replace('/[^0-9a-f]/', '', $hex);
        return static::fromString(pack("H*", $hex));
    }

    public static function fromBase64($base64) {
        return FieldElement::fromString(base64_decode($base64, true));
    }

    public static function fromJson($json) {
        return FieldElement::fromArray(json_decode($json, true));
    }
}



/**
 * Ed25519 - ref10
 *
 * Assembled from:
 *  - https://github.com/jedisct1/libsodium/
 *  - https://github.com/agl/ed25519/
 *
 * 
 * @link   https://github.com/devi/Salt
 * 
 */
class GeProjective {

    public $X;
    public $Y;
    public $Z;

    function __construct(){
        $this->X = new SplFixedArray(10);
        $this->Y = new SplFixedArray(10);
        $this->Z = new SplFixedArray(10);
    }
}

class GeExtended extends GeProjective {

    public $T;

    function __construct(){
        parent::__construct();
        $this->T = new SplFixedArray(10);
    }
}

class GeCompleted extends GeExtended {}

class GePrecomp {

    public $yplusx;
    public $yminusx;
    public $xy2d;

    function __construct($x = null, $y = null, $z = null) {
        $this->yplusx = $x ? SplFixedArray::fromArray($x) : new SplFixedArray(10);
        $this->yminusx = $y ? SplFixedArray::fromArray($y) :new SplFixedArray(10);
        $this->xy2d = $z ? SplFixedArray::fromArray($z) :new SplFixedArray(10);
    }
}

class GeCached {

    public $YplusX;
    public $YminusX;
    public $Z;
    public $T2d;

    function __construct() {
        $this->YplusX = new SplFixedArray(10);
        $this->YminusX = new SplFixedArray(10);
        $this->Z = new SplFixedArray(10);
        $this->T2d = new SplFixedArray(10);
    }

}

class Ed25519 {

    // lazy load
    protected static $instance;

    public static function instance() {
        if (!isset(static::$instance))
            static::$instance = new Ed25519();
        return static::$instance;
    }

    protected static $base;
    protected static $Bi;

    function __construct() {
        // TODO: simplified
        if (!isset(static::$base)) {
            static::$base = new SplFixedArray(32);
            $const = SplFixedArray::fromArray((include "base.php"), false);
            for ($i = 0;$i < 32;++$i) {
                static::$base[$i] = new SplFixedArray(8);
                for ($j = 0;$j < 8;++$j) {
                    static::$base[$i][$j] = new GePrecomp(
                        $const[$i][$j][0],
                        $const[$i][$j][1],
                        $const[$i][$j][2]
                    );
                }
            }
        }
        if (!isset(static::$Bi)) {
            static::$Bi = new SplFixedArray(8);
            $const = SplFixedArray::fromArray((include "base2.php"), false);
             for ($i = 0;$i < 8;++$i) {
                static::$Bi[$i] = new GePrecomp(
                    $const[$i][0],
                    $const[$i][1],
                    $const[$i][2]
                );
            }
        }
    }

    function feZero($h) {
        for ($i = 0;$i < 10;++$i) {
            $h[$i] = 0;
        }
    }

    function feOne($h) {
        $this->feZero($h);
        $h[0] = 1;
    }

    function feAdd($h, $f, $g) {
        for ($i = 0;$i < 10;++$i) {
            $h[$i] = $f[$i] + $g[$i];
        }
    }

    function feCMove($f, $g, $b) {
        $b = -$b;
        for ($i = 0;$i < 10;++$i) {
            $x = $b & ($f[$i] ^ $g[$i]);
            $f[$i] ^= $x;
        }
    }

    function feCopy($h, $f) {
        for ($i = 0;$i < 10;++$i) {
            $h[$i] = $f[$i];
        }
    }

    function feSub($h, $f, $g) {
        for ($i = 0;$i < 10;++$i) {
            $h[$i] = $f[$i] - $g[$i];
        }
    }

    function feLoad3($in, $pos) {
        $result = $in[$pos];
        $result |= $in[1+$pos] << 8;
        $result |= $in[2+$pos] << 16;
        return $result;
    }

    function feLoad4($in, $pos) {
        $result = $in[$pos];
        $result |= $in[1+$pos] << 8;
        $result |= $in[2+$pos] << 16;
        $result |= $in[3+$pos] << 24;
        return $result;
    }

    function feFromBytes($h, $s) {
        $h0 = $this->feLoad4($s,  0);
        $h1 = $this->feLoad3($s,  4) << 6;
        $h2 = $this->feLoad3($s,  7) << 5;
        $h3 = $this->feLoad3($s, 10) << 3;
        $h4 = $this->feLoad3($s, 13) << 2;
        $h5 = $this->feLoad4($s, 16);
        $h6 = $this->feLoad3($s, 20) << 7;
        $h7 = $this->feLoad3($s, 23) << 5;
        $h8 = $this->feLoad3($s, 26) << 4;
        $h9 = ($this->feLoad3($s,29) & 8388607) << 2;

        $carry9 = ($h9 +  (1<<24)) >> 25; $h0 += $carry9 * 19; $h9 -= $carry9 << 25;
        $carry1 = ($h1 +  (1<<24)) >> 25; $h2 += $carry1; $h1 -= $carry1 << 25;
        $carry3 = ($h3 +  (1<<24)) >> 25; $h4 += $carry3; $h3 -= $carry3 << 25;
        $carry5 = ($h5 +  (1<<24)) >> 25; $h6 += $carry5; $h5 -= $carry5 << 25;
        $carry7 = ($h7 +  (1<<24)) >> 25; $h8 += $carry7; $h7 -= $carry7 << 25;

        $carry0 = ($h0 +  (1<<25)) >> 26; $h1 += $carry0; $h0 -= $carry0 << 26;
        $carry2 = ($h2 +  (1<<25)) >> 26; $h3 += $carry2; $h2 -= $carry2 << 26;
        $carry4 = ($h4 +  (1<<25)) >> 26; $h5 += $carry4; $h4 -= $carry4 << 26;
        $carry6 = ($h6 +  (1<<25)) >> 26; $h7 += $carry6; $h6 -= $carry6 << 26;
        $carry8 = ($h8 +  (1<<25)) >> 26; $h9 += $carry8; $h8 -= $carry8 << 26;

        $h[0] = $h0;
        $h[1] = $h1;
        $h[2] = $h2;
        $h[3] = $h3;
        $h[4] = $h4;
        $h[5] = $h5;
        $h[6] = $h6;
        $h[7] = $h7;
        $h[8] = $h8;
        $h[9] = $h9;
    }

    function feToBytes($s, $h) {
        $q = (19 * $h[9] + (1 << 24)) >> 25;
        $q = ($h[0] + $q) >> 26;
        $q = ($h[1] + $q) >> 25;
        $q = ($h[2] + $q) >> 26;
        $q = ($h[3] + $q) >> 25;
        $q = ($h[4] + $q) >> 26;
        $q = ($h[5] + $q) >> 25;
        $q = ($h[6] + $q) >> 26;
        $q = ($h[7] + $q) >> 25;
        $q = ($h[8] + $q) >> 26;
        $q = ($h[9] + $q) >> 25;

        $h[0] += 19 * $q;

        $carry0 = $h[0] >> 26; $h[1] += $carry0; $h[0] -= $carry0 << 26;
        $carry1 = $h[1] >> 25; $h[2] += $carry1; $h[1] -= $carry1 << 25;
        $carry2 = $h[2] >> 26; $h[3] += $carry2; $h[2] -= $carry2 << 26;
        $carry3 = $h[3] >> 25; $h[4] += $carry3; $h[3] -= $carry3 << 25;
        $carry4 = $h[4] >> 26; $h[5] += $carry4; $h[4] -= $carry4 << 26;
        $carry5 = $h[5] >> 25; $h[6] += $carry5; $h[5] -= $carry5 << 25;
        $carry6 = $h[6] >> 26; $h[7] += $carry6; $h[6] -= $carry6 << 26;
        $carry7 = $h[7] >> 25; $h[8] += $carry7; $h[7] -= $carry7 << 25;
        $carry8 = $h[8] >> 26; $h[9] += $carry8; $h[8] -= $carry8 << 26;
        $carry9 = $h[9] >> 25;                 $h[9] -= $carry9 << 25;

        $s[0] = ($h[0] >> 0) & 0xff;
        $s[1] = ($h[0] >> 8) & 0xff;
        $s[2] = ($h[0] >> 16) & 0xff;
        $s[3] = (($h[0] >> 24) | ($h[1] << 2)) & 0xff;
        $s[4] = ($h[1] >> 6) & 0xff;
        $s[5] = ($h[1] >> 14) & 0xff;
        $s[6] = (($h[1] >> 22) | ($h[2] << 3)) & 0xff;
        $s[7] = ($h[2] >> 5) & 0xff;
        $s[8] = ($h[2] >> 13) & 0xff;
        $s[9] = (($h[2] >> 21) | ($h[3] << 5)) & 0xff;
        $s[10] = ($h[3] >> 3) & 0xff;
        $s[11] = ($h[3] >> 11) & 0xff;
        $s[12] = (($h[3] >> 19) | ($h[4] << 6)) & 0xff;
        $s[13] = ($h[4] >> 2) & 0xff;
        $s[14] = ($h[4] >> 10) & 0xff;
        $s[15] = ($h[4] >> 18) & 0xff;
        $s[16] = ($h[5] >> 0) & 0xff;
        $s[17] = ($h[5] >> 8) & 0xff;
        $s[18] = ($h[5] >> 16) & 0xff;
        $s[19] = (($h[5] >> 24) | ($h[6] << 1)) & 0xff;
        $s[20] = ($h[6] >> 7) & 0xff;
        $s[21] = ($h[6] >> 15) & 0xff;
        $s[22] = (($h[6] >> 23) | ($h[7] << 3)) & 0xff;
        $s[23] = ($h[7] >> 5) & 0xff;
        $s[24] = ($h[7] >> 13) & 0xff;
        $s[25] = (($h[7] >> 21) | ($h[8] << 4)) & 0xff;
        $s[26] = ($h[8] >> 4) & 0xff;
        $s[27] = ($h[8] >> 12) & 0xff;
        $s[28] = (($h[8] >> 20) | ($h[9] << 6)) & 0xff;
        $s[29] = ($h[9] >> 2) & 0xff;
        $s[30] = ($h[9] >> 10) & 0xff;
        $s[31] = ($h[9] >> 18) & 0xff;
    }

    function feMul($h, $f, $g) {
        $f0 = $f[0];
        $f1 = $f[1];
        $f2 = $f[2];
        $f3 = $f[3];
        $f4 = $f[4];
        $f5 = $f[5];
        $f6 = $f[6];
        $f7 = $f[7];
        $f8 = $f[8];
        $f9 = $f[9];
        $g0 = $g[0];
        $g1 = $g[1];
        $g2 = $g[2];
        $g3 = $g[3];
        $g4 = $g[4];
        $g5 = $g[5];
        $g6 = $g[6];
        $g7 = $g[7];
        $g8 = $g[8];
        $g9 = $g[9];
        $g1_19 = 19 * $g1;
        $g2_19 = 19 * $g2;
        $g3_19 = 19 * $g3;
        $g4_19 = 19 * $g4;
        $g5_19 = 19 * $g5;
        $g6_19 = 19 * $g6;
        $g7_19 = 19 * $g7;
        $g8_19 = 19 * $g8;
        $g9_19 = 19 * $g9;
        $f1_2 = 2 * $f1;
        $f3_2 = 2 * $f3;
        $f5_2 = 2 * $f5;
        $f7_2 = 2 * $f7;
        $f9_2 = 2 * $f9;
        $f0g0    = $f0   * $g0;
        $f0g1    = $f0   * $g1;
        $f0g2    = $f0   * $g2;
        $f0g3    = $f0   * $g3;
        $f0g4    = $f0   * $g4;
        $f0g5    = $f0   * $g5;
        $f0g6    = $f0   * $g6;
        $f0g7    = $f0   * $g7;
        $f0g8    = $f0   * $g8;
        $f0g9    = $f0   * $g9;
        $f1g0    = $f1   * $g0;
        $f1g1_2  = $f1_2 * $g1;
        $f1g2    = $f1   * $g2;
        $f1g3_2  = $f1_2 * $g3;
        $f1g4    = $f1   * $g4;
        $f1g5_2  = $f1_2 * $g5;
        $f1g6    = $f1   * $g6;
        $f1g7_2  = $f1_2 * $g7;
        $f1g8    = $f1   * $g8;
        $f1g9_38 = $f1_2 * $g9_19;
        $f2g0    = $f2   * $g0;
        $f2g1    = $f2   * $g1;
        $f2g2    = $f2   * $g2;
        $f2g3    = $f2   * $g3;
        $f2g4    = $f2   * $g4;
        $f2g5    = $f2   * $g5;
        $f2g6    = $f2   * $g6;
        $f2g7    = $f2   * $g7;
        $f2g8_19 = $f2   * $g8_19;
        $f2g9_19 = $f2   * $g9_19;
        $f3g0    = $f3   * $g0;
        $f3g1_2  = $f3_2 * $g1;
        $f3g2    = $f3   * $g2;
        $f3g3_2  = $f3_2 * $g3;
        $f3g4    = $f3   * $g4;
        $f3g5_2  = $f3_2 * $g5;
        $f3g6    = $f3   * $g6;
        $f3g7_38 = $f3_2 * $g7_19;
        $f3g8_19 = $f3   * $g8_19;
        $f3g9_38 = $f3_2 * $g9_19;
        $f4g0    = $f4   * $g0;
        $f4g1    = $f4   * $g1;
        $f4g2    = $f4   * $g2;
        $f4g3    = $f4   * $g3;
        $f4g4    = $f4   * $g4;
        $f4g5    = $f4   * $g5;
        $f4g6_19 = $f4   * $g6_19;
        $f4g7_19 = $f4   * $g7_19;
        $f4g8_19 = $f4   * $g8_19;
        $f4g9_19 = $f4   * $g9_19;
        $f5g0    = $f5   * $g0;
        $f5g1_2  = $f5_2 * $g1;
        $f5g2    = $f5   * $g2;
        $f5g3_2  = $f5_2 * $g3;
        $f5g4    = $f5   * $g4;
        $f5g5_38 = $f5_2 * $g5_19;
        $f5g6_19 = $f5   * $g6_19;
        $f5g7_38 = $f5_2 * $g7_19;
        $f5g8_19 = $f5   * $g8_19;
        $f5g9_38 = $f5_2 * $g9_19;
        $f6g0    = $f6   * $g0;
        $f6g1    = $f6   * $g1;
        $f6g2    = $f6   * $g2;
        $f6g3    = $f6   * $g3;
        $f6g4_19 = $f6   * $g4_19;
        $f6g5_19 = $f6   * $g5_19;
        $f6g6_19 = $f6   * $g6_19;
        $f6g7_19 = $f6   * $g7_19;
        $f6g8_19 = $f6   * $g8_19;
        $f6g9_19 = $f6   * $g9_19;
        $f7g0    = $f7   * $g0;
        $f7g1_2  = $f7_2 * $g1;
        $f7g2    = $f7   * $g2;
        $f7g3_38 = $f7_2 * $g3_19;
        $f7g4_19 = $f7   * $g4_19;
        $f7g5_38 = $f7_2 * $g5_19;
        $f7g6_19 = $f7   * $g6_19;
        $f7g7_38 = $f7_2 * $g7_19;
        $f7g8_19 = $f7   * $g8_19;
        $f7g9_38 = $f7_2 * $g9_19;
        $f8g0    = $f8   * $g0;
        $f8g1    = $f8   * $g1;
        $f8g2_19 = $f8   * $g2_19;
        $f8g3_19 = $f8   * $g3_19;
        $f8g4_19 = $f8   * $g4_19;
        $f8g5_19 = $f8   * $g5_19;
        $f8g6_19 = $f8   * $g6_19;
        $f8g7_19 = $f8   * $g7_19;
        $f8g8_19 = $f8   * $g8_19;
        $f8g9_19 = $f8   * $g9_19;
        $f9g0    = $f9   * $g0;
        $f9g1_38 = $f9_2 * $g1_19;
        $f9g2_19 = $f9   * $g2_19;
        $f9g3_38 = $f9_2 * $g3_19;
        $f9g4_19 = $f9   * $g4_19;
        $f9g5_38 = $f9_2 * $g5_19;
        $f9g6_19 = $f9   * $g6_19;
        $f9g7_38 = $f9_2 * $g7_19;
        $f9g8_19 = $f9   * $g8_19;
        $f9g9_38 = $f9_2 * $g9_19;
        $h0 = $f0g0 + $f1g9_38 + $f2g8_19 + $f3g7_38 + $f4g6_19 + $f5g5_38 + $f6g4_19 + $f7g3_38 + $f8g2_19 + $f9g1_38;
        $h1 = $f0g1 + $f1g0    + $f2g9_19 + $f3g8_19 + $f4g7_19 + $f5g6_19 + $f6g5_19 + $f7g4_19 + $f8g3_19 + $f9g2_19;
        $h2 = $f0g2 + $f1g1_2  + $f2g0    + $f3g9_38 + $f4g8_19 + $f5g7_38 + $f6g6_19 + $f7g5_38 + $f8g4_19 + $f9g3_38;
        $h3 = $f0g3 + $f1g2    + $f2g1    + $f3g0    + $f4g9_19 + $f5g8_19 + $f6g7_19 + $f7g6_19 + $f8g5_19 + $f9g4_19;
        $h4 = $f0g4 + $f1g3_2  + $f2g2    + $f3g1_2  + $f4g0    + $f5g9_38 + $f6g8_19 + $f7g7_38 + $f8g6_19 + $f9g5_38;
        $h5 = $f0g5 + $f1g4    + $f2g3    + $f3g2    + $f4g1    + $f5g0    + $f6g9_19 + $f7g8_19 + $f8g7_19 + $f9g6_19;
        $h6 = $f0g6 + $f1g5_2  + $f2g4    + $f3g3_2  + $f4g2    + $f5g1_2  + $f6g0    + $f7g9_38 + $f8g8_19 + $f9g7_38;
        $h7 = $f0g7 + $f1g6    + $f2g5    + $f3g4    + $f4g3    + $f5g2    + $f6g1    + $f7g0    + $f8g9_19 + $f9g8_19;
        $h8 = $f0g8 + $f1g7_2  + $f2g6    + $f3g5_2  + $f4g4    + $f5g3_2  + $f6g2    + $f7g1_2  + $f8g0    + $f9g9_38;
        $h9 = $f0g9 + $f1g8    + $f2g7    + $f3g6    + $f4g5    + $f5g4    + $f6g3    + $f7g2    + $f8g1    + $f9g0   ;

        $carry0 = ($h0 + (1<<25)) >> 26; $h1 += $carry0; $h0 -= $carry0 << 26;
        $carry4 = ($h4 + (1<<25)) >> 26; $h5 += $carry4; $h4 -= $carry4 << 26;

        $carry1 = ($h1 + (1<<24)) >> 25; $h2 += $carry1; $h1 -= $carry1 << 25;
        $carry5 = ($h5 + (1<<24)) >> 25; $h6 += $carry5; $h5 -= $carry5 << 25;

        $carry2 = ($h2 + (1<<25)) >> 26; $h3 += $carry2; $h2 -= $carry2 << 26;
        $carry6 = ($h6 + (1<<25)) >> 26; $h7 += $carry6; $h6 -= $carry6 << 26;

        $carry3 = ($h3 + (1<<24)) >> 25; $h4 += $carry3; $h3 -= $carry3 << 25;
        $carry7 = ($h7 + (1<<24)) >> 25; $h8 += $carry7; $h7 -= $carry7 << 25;

        $carry4 = ($h4 + (1<<25)) >> 26; $h5 += $carry4; $h4 -= $carry4 << 26;
        $carry8 = ($h8 + (1<<25)) >> 26; $h9 += $carry8; $h8 -= $carry8 << 26;

        $carry9 = ($h9 + (1<<24)) >> 25; $h0 += $carry9 * 19; $h9 -= $carry9 << 25;

        $carry0 = ($h0 + (1<<25)) >> 26; $h1 += $carry0; $h0 -= $carry0 << 26;

        $h[0] = $h0;
        $h[1] = $h1;
        $h[2] = $h2;
        $h[3] = $h3;
        $h[4] = $h4;
        $h[5] = $h5;
        $h[6] = $h6;
        $h[7] = $h7;
        $h[8] = $h8;
        $h[9] = $h9;
    }

    function feSquare($h, $f) {
        $f0 = $f[0];
        $f1 = $f[1];
        $f2 = $f[2];
        $f3 = $f[3];
        $f4 = $f[4];
        $f5 = $f[5];
        $f6 = $f[6];
        $f7 = $f[7];
        $f8 = $f[8];
        $f9 = $f[9];
        $f0_2 = 2 * $f0;
        $f1_2 = 2 * $f1;
        $f2_2 = 2 * $f2;
        $f3_2 = 2 * $f3;
        $f4_2 = 2 * $f4;
        $f5_2 = 2 * $f5;
        $f6_2 = 2 * $f6;
        $f7_2 = 2 * $f7;
        $f5_38 = 38 * $f5;
        $f6_19 = 19 * $f6;
        $f7_38 = 38 * $f7;
        $f8_19 = 19 * $f8;
        $f9_38 = 38 * $f9;
        $f0f0    = $f0   * $f0;
        $f0f1_2  = $f0_2 * $f1;
        $f0f2_2  = $f0_2 * $f2;
        $f0f3_2  = $f0_2 * $f3;
        $f0f4_2  = $f0_2 * $f4;
        $f0f5_2  = $f0_2 * $f5;
        $f0f6_2  = $f0_2 * $f6;
        $f0f7_2  = $f0_2 * $f7;
        $f0f8_2  = $f0_2 * $f8;
        $f0f9_2  = $f0_2 * $f9;
        $f1f1_2  = $f1_2 * $f1;
        $f1f2_2  = $f1_2 * $f2;
        $f1f3_4  = $f1_2 * $f3_2;
        $f1f4_2  = $f1_2 * $f4;
        $f1f5_4  = $f1_2 * $f5_2;
        $f1f6_2  = $f1_2 * $f6;
        $f1f7_4  = $f1_2 * $f7_2;
        $f1f8_2  = $f1_2 * $f8;
        $f1f9_76 = $f1_2 * $f9_38;
        $f2f2    = $f2   * $f2;
        $f2f3_2  = $f2_2 * $f3;
        $f2f4_2  = $f2_2 * $f4;
        $f2f5_2  = $f2_2 * $f5;
        $f2f6_2  = $f2_2 * $f6;
        $f2f7_2  = $f2_2 * $f7;
        $f2f8_38 = $f2_2 * $f8_19;
        $f2f9_38 = $f2   * $f9_38;
        $f3f3_2  = $f3_2 * $f3;
        $f3f4_2  = $f3_2 * $f4;
        $f3f5_4  = $f3_2 * $f5_2;
        $f3f6_2  = $f3_2 * $f6;
        $f3f7_76 = $f3_2 * $f7_38;
        $f3f8_38 = $f3_2 * $f8_19;
        $f3f9_76 = $f3_2 * $f9_38;
        $f4f4    = $f4   * $f4;
        $f4f5_2  = $f4_2 * $f5;
        $f4f6_38 = $f4_2 * $f6_19;
        $f4f7_38 = $f4   * $f7_38;
        $f4f8_38 = $f4_2 * $f8_19;
        $f4f9_38 = $f4   * $f9_38;
        $f5f5_38 = $f5   * $f5_38;
        $f5f6_38 = $f5_2 * $f6_19;
        $f5f7_76 = $f5_2 * $f7_38;
        $f5f8_38 = $f5_2 * $f8_19;
        $f5f9_76 = $f5_2 * $f9_38;
        $f6f6_19 = $f6   * $f6_19;
        $f6f7_38 = $f6   * $f7_38;
        $f6f8_38 = $f6_2 * $f8_19;
        $f6f9_38 = $f6   * $f9_38;
        $f7f7_38 = $f7   * $f7_38;
        $f7f8_38 = $f7_2 * $f8_19;
        $f7f9_76 = $f7_2 * $f9_38;
        $f8f8_19 = $f8   * $f8_19;
        $f8f9_38 = $f8   * $f9_38;
        $f9f9_38 = $f9   * $f9_38;
        $h0 = $f0f0   + $f1f9_76 + $f2f8_38 + $f3f7_76 + $f4f6_38 + $f5f5_38;
        $h1 = $f0f1_2 + $f2f9_38 + $f3f8_38 + $f4f7_38 + $f5f6_38;
        $h2 = $f0f2_2 + $f1f1_2  + $f3f9_76 + $f4f8_38 + $f5f7_76 + $f6f6_19;
        $h3 = $f0f3_2 + $f1f2_2  + $f4f9_38 + $f5f8_38 + $f6f7_38;
        $h4 = $f0f4_2 + $f1f3_4  + $f2f2    + $f5f9_76 + $f6f8_38 + $f7f7_38;
        $h5 = $f0f5_2 + $f1f4_2  + $f2f3_2  + $f6f9_38 + $f7f8_38;
        $h6 = $f0f6_2 + $f1f5_4  + $f2f4_2  + $f3f3_2  + $f7f9_76 + $f8f8_19;
        $h7 = $f0f7_2 + $f1f6_2  + $f2f5_2  + $f3f4_2  + $f8f9_38;
        $h8 = $f0f8_2 + $f1f7_4  + $f2f6_2  + $f3f5_4  + $f4f4    + $f9f9_38;
        $h9 = $f0f9_2 + $f1f8_2  + $f2f7_2  + $f3f6_2  + $f4f5_2;

        $carry0 = ($h0 + (1<<25)) >> 26; $h1 += $carry0; $h0 -= $carry0 << 26;
        $carry4 = ($h4 + (1<<25)) >> 26; $h5 += $carry4; $h4 -= $carry4 << 26;

        $carry1 = ($h1 + (1<<24)) >> 25; $h2 += $carry1; $h1 -= $carry1 << 25;
        $carry5 = ($h5 + (1<<24)) >> 25; $h6 += $carry5; $h5 -= $carry5 << 25;

        $carry2 = ($h2 + (1<<25)) >> 26; $h3 += $carry2; $h2 -= $carry2 << 26;
        $carry6 = ($h6 + (1<<25)) >> 26; $h7 += $carry6; $h6 -= $carry6 << 26;

        $carry3 = ($h3 + (1<<24)) >> 25; $h4 += $carry3; $h3 -= $carry3 << 25;
        $carry7 = ($h7 + (1<<24)) >> 25; $h8 += $carry7; $h7 -= $carry7 << 25;

        $carry4 = ($h4 + (1<<25)) >> 26; $h5 += $carry4; $h4 -= $carry4 << 26;
        $carry8 = ($h8 + (1<<25)) >> 26; $h9 += $carry8; $h8 -= $carry8 << 26;

        $carry9 = ($h9 + (1<<24)) >> 25; $h0 += $carry9 * 19; $h9 -= $carry9 << 25;

        $carry0 = ($h0 + (1<<25)) >> 26; $h1 += $carry0; $h0 -= $carry0 << 26;

        $h[0] = $h0;
        $h[1] = $h1;
        $h[2] = $h2;
        $h[3] = $h3;
        $h[4] = $h4;
        $h[5] = $h5;
        $h[6] = $h6;
        $h[7] = $h7;
        $h[8] = $h8;
        $h[9] = $h9;
    }

    function feInvert($out, $z) {
        $t0 = new SplFixedArray(10);
        $t1 = new SplFixedArray(10);
        $t2 = new SplFixedArray(10);
        $t3 = new SplFixedArray(10);

        /* pow225521 */
        $this->feSquare($t0, $z);
        for ($i = 1;$i < 1;++$i) {
            $this->feSquare($t0, $t0);
        }
        $this->feSquare($t1, $t0);
        for ($i = 1;$i < 2;++$i) {
            $this->feSquare($t1, $t1);
        }
        $this->feMul($t1, $z, $t1);
        $this->feMul($t0, $t0, $t1);
        $this->feSquare($t2, $t0);
        for ($i = 1;$i < 1;++$i) {
            $this->feSquare($t2, $t2);
        }
        $this->feMul($t1, $t1, $t2);
        $this->feSquare($t2, $t1);
        for ($i = 1;$i < 5;++$i) {
            $this->feSquare($t2, $t2);
        }
        $this->feMul($t1, $t2, $t1);
        $this->feSquare($t2, $t1);
        for ($i = 1;$i < 10;++$i) {
            $this->feSquare($t2, $t2);
        }
        $this->feMul($t2, $t2, $t1);
        $this->feSquare($t3, $t2);
        for ($i = 1;$i < 20;++$i) {
            $this->feSquare($t3, $t3);
        }
        $this->feMul($t2, $t3, $t2);
        $this->feSquare($t2, $t2);
        for ($i = 1;$i < 10;++$i) {
            $this->feSquare($t2, $t2);
        }
        $this->feMul($t1, $t2, $t1);
        $this->feSquare($t2, $t1);
        for ($i = 1;$i < 50;++$i) {
            $this->feSquare($t2, $t2);
        }
        $this->feMul($t2, $t2, $t1);
        $this->feSquare($t3, $t2);
        for ($i = 1;$i < 100;++$i) {
            $this->feSquare($t3, $t3);
        }
        $this->feMul($t2, $t3, $t2);
        $this->feSquare($t2, $t2);
        for ($i = 1;$i < 50;++$i) {
            $this->feSquare($t2, $t2);
        }
        $this->feMul($t1, $t2, $t1);
        $this->feSquare($t1, $t1);
        for ($i = 1;$i < 5;++$i) {
            $this->feSquare($t1, $t1);
        }
        $this->feMul($out, $t1, $t0);
    }

    function feSquare2($h, $f) {
        $f0 = $f[0];
        $f1 = $f[1];
        $f2 = $f[2];
        $f3 = $f[3];
        $f4 = $f[4];
        $f5 = $f[5];
        $f6 = $f[6];
        $f7 = $f[7];
        $f8 = $f[8];
        $f9 = $f[9];
        $f0_2 = 2 * $f0;
        $f1_2 = 2 * $f1;
        $f2_2 = 2 * $f2;
        $f3_2 = 2 * $f3;
        $f4_2 = 2 * $f4;
        $f5_2 = 2 * $f5;
        $f6_2 = 2 * $f6;
        $f7_2 = 2 * $f7;
        $f5_38 = 38 * $f5;
        $f6_19 = 19 * $f6;
        $f7_38 = 38 * $f7;
        $f8_19 = 19 * $f8;
        $f9_38 = 38 * $f9;
        $f0f0    = $f0   * $f0;
        $f0f1_2  = $f0_2 * $f1;
        $f0f2_2  = $f0_2 * $f2;
        $f0f3_2  = $f0_2 * $f3;
        $f0f4_2  = $f0_2 * $f4;
        $f0f5_2  = $f0_2 * $f5;
        $f0f6_2  = $f0_2 * $f6;
        $f0f7_2  = $f0_2 * $f7;
        $f0f8_2  = $f0_2 * $f8;
        $f0f9_2  = $f0_2 * $f9;
        $f1f1_2  = $f1_2 * $f1;
        $f1f2_2  = $f1_2 * $f2;
        $f1f3_4  = $f1_2 * $f3_2;
        $f1f4_2  = $f1_2 * $f4;
        $f1f5_4  = $f1_2 * $f5_2;
        $f1f6_2  = $f1_2 * $f6;
        $f1f7_4  = $f1_2 * $f7_2;
        $f1f8_2  = $f1_2 * $f8;
        $f1f9_76 = $f1_2 * $f9_38;
        $f2f2    = $f2   * $f2;
        $f2f3_2  = $f2_2 * $f3;
        $f2f4_2  = $f2_2 * $f4;
        $f2f5_2  = $f2_2 * $f5;
        $f2f6_2  = $f2_2 * $f6;
        $f2f7_2  = $f2_2 * $f7;
        $f2f8_38 = $f2_2 * $f8_19;
        $f2f9_38 = $f2   * $f9_38;
        $f3f3_2  = $f3_2 * $f3;
        $f3f4_2  = $f3_2 * $f4;
        $f3f5_4  = $f3_2 * $f5_2;
        $f3f6_2  = $f3_2 * $f6;
        $f3f7_76 = $f3_2 * $f7_38;
        $f3f8_38 = $f3_2 * $f8_19;
        $f3f9_76 = $f3_2 * $f9_38;
        $f4f4    = $f4   * $f4;
        $f4f5_2  = $f4_2 * $f5;
        $f4f6_38 = $f4_2 * $f6_19;
        $f4f7_38 = $f4   * $f7_38;
        $f4f8_38 = $f4_2 * $f8_19;
        $f4f9_38 = $f4   * $f9_38;
        $f5f5_38 = $f5   * $f5_38;
        $f5f6_38 = $f5_2 * $f6_19;
        $f5f7_76 = $f5_2 * $f7_38;
        $f5f8_38 = $f5_2 * $f8_19;
        $f5f9_76 = $f5_2 * $f9_38;
        $f6f6_19 = $f6   * $f6_19;
        $f6f7_38 = $f6   * $f7_38;
        $f6f8_38 = $f6_2 * $f8_19;
        $f6f9_38 = $f6   * $f9_38;
        $f7f7_38 = $f7   * $f7_38;
        $f7f8_38 = $f7_2 * $f8_19;
        $f7f9_76 = $f7_2 * $f9_38;
        $f8f8_19 = $f8   * $f8_19;
        $f8f9_38 = $f8   * $f9_38;
        $f9f9_38 = $f9   * $f9_38;
        $h0 = $f0f0   + $f1f9_76 + $f2f8_38 + $f3f7_76 + $f4f6_38 + $f5f5_38;
        $h1 = $f0f1_2 + $f2f9_38 + $f3f8_38 + $f4f7_38 + $f5f6_38;
        $h2 = $f0f2_2 + $f1f1_2  + $f3f9_76 + $f4f8_38 + $f5f7_76 + $f6f6_19;
        $h3 = $f0f3_2 + $f1f2_2  + $f4f9_38 + $f5f8_38 + $f6f7_38;
        $h4 = $f0f4_2 + $f1f3_4  + $f2f2    + $f5f9_76 + $f6f8_38 + $f7f7_38;
        $h5 = $f0f5_2 + $f1f4_2  + $f2f3_2  + $f6f9_38 + $f7f8_38;
        $h6 = $f0f6_2 + $f1f5_4  + $f2f4_2  + $f3f3_2  + $f7f9_76 + $f8f8_19;
        $h7 = $f0f7_2 + $f1f6_2  + $f2f5_2  + $f3f4_2  + $f8f9_38;
        $h8 = $f0f8_2 + $f1f7_4  + $f2f6_2  + $f3f5_4  + $f4f4    + $f9f9_38;
        $h9 = $f0f9_2 + $f1f8_2  + $f2f7_2  + $f3f6_2  + $f4f5_2;

        $h0 += $h0;
        $h1 += $h1;
        $h2 += $h2;
        $h3 += $h3;
        $h4 += $h4;
        $h5 += $h5;
        $h6 += $h6;
        $h7 += $h7;
        $h8 += $h8;
        $h9 += $h9;

        $carry0 = ($h0 + (1<<25)) >> 26; $h1 += $carry0; $h0 -= $carry0 << 26;
        $carry4 = ($h4 + (1<<25)) >> 26; $h5 += $carry4; $h4 -= $carry4 << 26;

        $carry1 = ($h1 + (1<<24)) >> 25; $h2 += $carry1; $h1 -= $carry1 << 25;
        $carry5 = ($h5 + (1<<24)) >> 25; $h6 += $carry5; $h5 -= $carry5 << 25;

        $carry2 = ($h2 + (1<<25)) >> 26; $h3 += $carry2; $h2 -= $carry2 << 26;
        $carry6 = ($h6 + (1<<25)) >> 26; $h7 += $carry6; $h6 -= $carry6 << 26;

        $carry3 = ($h3 + (1<<24)) >> 25; $h4 += $carry3; $h3 -= $carry3 << 25;
        $carry7 = ($h7 + (1<<24)) >> 25; $h8 += $carry7; $h7 -= $carry7 << 25;

        $carry4 = ($h4 + (1<<25)) >> 26; $h5 += $carry4; $h4 -= $carry4 << 26;
        $carry8 = ($h8 + (1<<25)) >> 26; $h9 += $carry8; $h8 -= $carry8 << 26;

        $carry9 = ($h9 + (1<<24)) >> 25; $h0 += $carry9 * 19; $h9 -= $carry9 << 25;

        $carry0 = ($h0 + (1<<25)) >> 26; $h1 += $carry0; $h0 -= $carry0 << 26;

        $h[0] = $h0;
        $h[1] = $h1;
        $h[2] = $h2;
        $h[3] = $h3;
        $h[4] = $h4;
        $h[5] = $h5;
        $h[6] = $h6;
        $h[7] = $h7;
        $h[8] = $h8;
        $h[9] = $h9;
    }

    function feIsNegative($f) {
        $s = new SplFixedArray(32);
        $this->feToBytes($s, $f);
        return ($s[0] & 1);
    }

    function cryptoVerify32($x, $y) {
        $d = 0;
        for ($i = 0;$i < 32;++$i) {
            $d |= $x[$i] ^ $y[$i];
        }
        return (1 & (($d - 1) >> 8)) - 1;
    }

    function feIsNonZero($f) {
        $s = new SplFixedArray(32);
        $zero = new SplFixedArray(32);
        $this->feZero($zero);
        $this->feToBytes($s, $f);
        return $this->cryptoVerify32($s, $zero);
    }

    function feNegative($h, $f) {
        for ($i = 0;$i < 10;++$i) {
            $h[$i] = -$f[$i];
        }
    }

    function fePow22523($out, $z) {
        $t0 = new SplFixedArray(10);
        $t1 = new SplFixedArray(10);
        $t2 = new SplFixedArray(10);

        $this->feSquare($t0,$z);
        for ($i = 1;$i < 1;++$i) {
            $this->feSquare($t0,$t0);
        }
        $this->feSquare($t1,$t0);
        for ($i = 1;$i < 2;++$i) {
            $this->feSquare($t1,$t1);
        }
        $this->feMul($t1,$z,$t1);
        $this->feMul($t0,$t0,$t1);
        $this->feSquare($t0,$t0);
        for ($i = 1;$i < 1;++$i) {
            $this->feSquare($t0,$t0);
        }
        $this->feMul($t0,$t1,$t0);
        $this->feSquare($t1,$t0);
        for ($i = 1;$i < 5;++$i) {
            $this->feSquare($t1,$t1);
        }
        $this->feMul($t0,$t1,$t0);
        $this->feSquare($t1,$t0);
        for ($i = 1;$i < 10;++$i) {
            $this->feSquare($t1,$t1);
        }
        $this->feMul($t1,$t1,$t0);
        $this->feSquare($t2,$t1);
        for ($i = 1;$i < 20;++$i) {
            $this->feSquare($t2,$t2);
        }
        $this->feMul($t1,$t2,$t1);
        $this->feSquare($t1,$t1);
        for ($i = 1;$i < 10;++$i) {
            $this->feSquare($t1,$t1);
        }
        $this->feMul($t0,$t1,$t0);
        $this->feSquare($t1,$t0);
        for ($i = 1;$i < 50;++$i) {
            $this->feSquare($t1,$t1);
        }
        $this->feMul($t1,$t1,$t0);
        $this->feSquare($t2,$t1);
        for ($i = 1;$i < 100;++$i) {
            $this->feSquare($t2,$t2);
        }
        $this->feMul($t1,$t2,$t1);
        $this->feSquare($t1,$t1);
        for ($i = 1;$i < 50;++$i) {
            $this->feSquare($t1,$t1);
        }
        $this->feMul($t0,$t1,$t0);
        $this->feSquare($t0,$t0);
        for ($i = 1;$i < 2;++$i) {
            $this->feSquare($t0,$t0);
        }
        $this->feMul($out,$t0,$z);
    }

    function GeProjectiveZero(GeProjective $h) {
        $this->feZero($h->X);
        $this->feOne($h->Y);
        $this->feOne($h->Z);
    }

    function GeProjectiveDouble(GeCompleted $r, GeProjective $p) {
        $t0 = new SplFixedArray(10);
        $this->feSquare($r->X, $p->X);
        $this->feSquare($r->Z, $p->Y);
        $this->feSquare2($r->T, $p->Z);
        $this->feAdd($r->Y, $p->X, $p->Y);
        $this->feSquare($t0, $r->Y);
        $this->feAdd($r->Y, $r->Z, $r->X);
        $this->feSub($r->Z, $r->Z, $r->X);
        $this->feSub($r->X, $t0, $r->Y);
        $this->feSub($r->T, $r->T, $r->Z);
    }

    function GeExtendedZero(GeExtended $h) {
        $this->feZero($h->X);
        $this->feOne($h->Y);
        $this->feOne($h->Z);
        $this->feZero($h->T);
    }

    function GeExtendedtoGeProjective(GeProjective $r, GeExtended $p) {
        $this->feCopy($r->X, $p->X);
        $this->feCopy($r->Y, $p->Y);
        $this->feCopy($r->Z, $p->Z);
    }

    function GeExtendedDouble(GeCompleted $r, GeExtended $p) {
        $q = new GeProjective();
        $this->GeExtendedtoGeProjective($q, $p);
        $this->GeProjectiveDouble($r, $q);
    }

    function GeExtendedtoGeCached(GeCached $r, GeExtended $p) {
        $d2 = array(
            -21827239, -5839606, -30745221, 13898782, 229458,
            15978800, -12551817, -6495438, 29715968, 9444199
        );
        $this->feAdd($r->YplusX, $p->Y, $p->X);
        $this->feSub($r->YminusX, $p->Y, $p->X);
        $this->feCopy($r->Z, $p->Z);
        $this->feMul($r->T2d, $p->T, $d2);
    }

    function GeExtendedtoBytes($s, GeExtended $h) {
        $recip = new SplFixedArray(10);
        $x = new SplFixedArray(10);
        $y = new SplFixedArray(10);

        $this->feInvert($recip, $h->Z);
        $this->feMul($x, $h->X, $recip);
        $this->feMul($y, $h->Y, $recip);
        $this->feToBytes($s, $y);
        $s[31] ^= $this->feIsNegative($x) << 7;
    }

    function GeCompletedtoGeProjective(GeProjective $r, GeCompleted $p) {
        $this->feMul($r->X, $p->X, $p->T);
        $this->feMul($r->Y, $p->Y, $p->Z);
        $this->feMul($r->Z, $p->Z, $p->T);
    }

    function GeCompletedtoGeExtended(GeExtended $r, GeCompleted $p) {
        $this->feMul($r->X, $p->X, $p->T);
        $this->feMul($r->Y, $p->Y, $p->Z);
        $this->feMul($r->Z, $p->Z, $p->T);
        $this->feMul($r->T, $p->X, $p->Y);
    }

    function GePrecompZero(GePrecomp $h) {
        $this->feOne($h->yplusx);
        $this->feOne($h->yminusx);
        $this->feZero($h->xy2d);
    }

    function geAdd(GeCompleted $r, GeExtended $p, GeCached $q) {
        $t0 = new SplFixedArray(10);
        $this->feAdd($r->X, $p->Y, $p->X);
        $this->feSub($r->Y, $p->Y, $p->X);
        $this->feMul($r->Z, $r->X, $q->YplusX);
        $this->feMul($r->Y, $r->Y, $q->YminusX);
        $this->feMul($r->T, $q->T2d, $p->T);
        $this->feMul($r->X, $p->Z, $q->Z);
        $this->feAdd($t0, $r->X, $r->X);
        $this->feSub($r->X, $r->Z, $r->Y);
        $this->feAdd($r->Y, $r->Z, $r->Y);
        $this->feAdd($r->Z, $t0, $r->T);
        $this->feSub($r->T, $t0, $r->T);
    }

    function geMixedAdd(GeCompleted $r, GeExtended $p,  GePrecomp $q) {
        $t0 = new SplFixedArray(10);
        $this->feAdd($r->X, $p->Y, $p->X);
        $this->feSub($r->Y, $p->Y, $p->X);
        $this->feMul($r->Z, $r->X, $q->yplusx);
        $this->feMul($r->Y, $r->Y, $q->yminusx);
        $this->feMul($r->T, $q->xy2d, $p->T);
        $this->feAdd($t0, $p->Z, $p->Z);
        $this->feSub($r->X, $r->Z, $r->Y);
        $this->feAdd($r->Y, $r->Z, $r->Y);
        $this->feAdd($r->Z, $t0, $r->T);
        $this->feSub($r->T, $t0, $r->T);
    }

    function geSub(GeCompleted $r,GeExtended $p,GeCached $q) {
        $t0 = new SplFixedArray(10);
        $this->feAdd($r->X, $p->Y, $p->X);
        $this->feSub($r->Y, $p->Y, $p->X);
        $this->feMul($r->Z, $r->X, $q->YminusX);
        $this->feMul($r->Y, $r->Y, $q->YplusX);
        $this->feMul($r->T, $q->T2d, $p->T);
        $this->feMul($r->X, $p->Z, $q->Z);
        $this->feAdd($t0, $r->X, $r->X);
        $this->feSub($r->X, $r->Z, $r->Y);
        $this->feAdd($r->Y, $r->Z, $r->Y);
        $this->feSub($r->Z, $t0, $r->T);
        $this->feAdd($r->T, $t0, $r->T);
    }

    function geMixedSub(GeCompleted $r, GeExtended $p, GePrecomp $q) {
        $t0 = new SplFixedArray(10);
        $this->feAdd($r->X, $p->Y, $p->X);
        $this->feSub($r->Y, $p->Y, $p->X);
        $this->feMul($r->Z, $r->X, $q->yminusx);
        $this->feMul($r->Y, $r->Y, $q->yplusx);
        $this->feMul($r->T, $q->xy2d, $p->T);
        $this->feAdd($t0, $p->Z, $p->Z);
        $this->feSub($r->X, $r->Z, $r->Y);
        $this->feAdd($r->Y, $r->Z, $r->Y);
        $this->feSub($r->Z, $t0, $r->T);
        $this->feAdd($r->T, $t0, $r->T);
    }

    function geFromBytesNegateVartime(GeExtended $h,  $s) {
        $u = new SplFixedArray(10);
        $v = new SplFixedArray(10);
        $v3 = new SplFixedArray(10);
        $vxx = new SplFixedArray(10);
        $check = new SplFixedArray(10);
        $d = array(
            -10913610, 13857413, -15372611, 6949391, 114729,
            -8787816,-6275908,-3247719,-18696448,-12055116
        );
        $sqrtm1 = array(
            -32595792, -7943725, 9377950, 3500415, 12389472,
            -272473, -25146209, -2005654, 326686, 11406482
        );

        $this->feFromBytes($h->Y, $s);
        $this->feOne($h->Z);
        $this->feSquare($u, $h->Y);
        $this->feMul($v, $u, $d);
        $this->feSub($u, $u, $h->Z);
        $this->feAdd($v, $v, $h->Z);

        $this->feSquare($v3, $v);
        $this->feMul($v3, $v3, $v);
        $this->feSquare($h->X, $v3);
        $this->feMul($h->X, $h->X, $v);
        $this->feMul($h->X, $h->X, $u);

        $this->fePow22523($h->X, $h->X);
        $this->feMul($h->X, $h->X, $v3);
        $this->feMul($h->X, $h->X, $u);

        $tmpX = new SplFixedArray(32);
        $tmp2 = new SplFixedArray(32);

        $this->feSquare($vxx, $h->X);
        $this->feMul($vxx, $vxx, $v);
        $this->feSub($check, $vxx, $u);
        if ($this->feIsNonZero($check)) {
            $this->feAdd($check, $vxx, $u);
            if ($this->feIsNonZero($check)) {
                return false;
            }
            $this->feMul($h->X, $h->X, $sqrtm1);
            $this->feToBytes($tmpX, $h->X);
            for ($i = 0;$i < 32;++$i) {
                $tmp2[31-$i] = $tmpX[$i];
            }
        }

        if ($this->feIsNegative($h->X) == ($s[31] >> 7)) {
            $this->feNegative($h->X, $h->X);
        }
        $this->feMul($h->T, $h->X, $h->Y);
        return true;
    }

    function geToBytes($s, GeProjective $h) {
        $recip = new SplFixedArray(10);
        $x = new SplFixedArray(10);
        $y = new SplFixedArray(10);

        $this->feInvert($recip, $h->Z);
        $this->feMul($x, $h->X, $recip);
        $this->feMul($y, $h->Y, $recip);
        $this->feToBytes($s, $y);
        $s[31] ^= $this->feIsNegative($x) << 7;
    }

    // equal returns 1 if b == c and 0 otherwise.
    function equal($b, $c) {
        $x = ($b ^ $c);
        $x--;
        $x &= 0xffffffff;
        return ($x >> 31);
        
    }

    // negative returns 1 if b < 0 and 0 otherwise.
    function negative($b) {
        return ($b >> 31) & 1;
    }

    function cMove(GePrecomp $t, GePrecomp $u, $b) {
        $this->feCMove($t->yplusx, $u->yplusx, $b);
        $this->feCMove($t->yminusx, $u->yminusx, $b);
        $this->feCMove($t->xy2d, $u->xy2d, $b);
    }

    function select(GePrecomp $t, $pos, $b) {
        $minust = new GePrecomp();
        $bnegative = $this->negative($b);
        $babs = $b - (((-$bnegative) & $b) << 1);

        $this->GePrecompZero($t);
        for ($i = 0;$i < 8;++$i) {
            $this->cMove($t, static::$base[$pos][$i], $this->equal($babs, $i+1));
        }

        $this->feCopy($minust->yplusx, $t->yminusx);
        $this->feCopy($minust->yminusx, $t->yplusx);
        $this->feNegative($minust->xy2d, $t->xy2d);
        $this->cMove($t, $minust, $bnegative);
    }

    function geScalarmultBase(GeExtended $h, $a) {
        $e = new SplFixedArray(64);
        $r = new GeCompleted();
        $s = new GeProjective();
        $t = new GePrecomp();

        for ($i = 0;$i < 32;++$i) {
            $e[2 * $i] = $a[$i] & 15;
            $e[2 * $i + 1] = ($a[$i] >> 4) & 15;
        }

        $carry = 0;
        for ($i = 0;$i < 63;++$i) {
            $e[$i] += $carry;
            $carry = $e[$i] + 8;
            $carry >>= 4;
            $e[$i] -= $carry << 4;
        }
        $e[63] += $carry;

        $this->GeExtendedZero($h);

        for ($i = 1;$i < 64;$i += 2) {
            $this->select($t, $i / 2, $e[$i]);
            $this->geMixedAdd($r, $h, $t);
            $this->GeCompletedtoGeExtended($h, $r);
        }

        $this->GeExtendedDouble($r, $h);
        $this->GeCompletedtoGeProjective($s, $r);
        $this->GeProjectiveDouble($r, $s);
        $this->GeCompletedtoGeProjective($s, $r);
        $this->GeProjectiveDouble($r, $s);
        $this->GeCompletedtoGeProjective($s, $r);
        $this->GeProjectiveDouble($r, $s);
        $this->GeCompletedtoGeExtended($h, $r);

        for ($i = 0;$i < 64;$i += 2) {
            $this->select($t, $i / 2, $e[$i]);
            $this->geMixedAdd($r, $h, $t);
            $this->GeCompletedtoGeExtended($h, $r);
        }
    }

    function slide($r, $a) {
        for ($i = 0;$i < 256;++$i)
            $r[$i] = 1 & ($a[$i >> 3] >> ($i & 7));

        for ($i = 0;$i < 256;++$i) {
            if ($r[$i]) {
                for ($b = 1;$b <= 6 && $i + $b < 256;++$b) {
                    if ($r[$i + $b]) {
                        if ($r[$i] + ($r[$i + $b] << $b) <= 15) {
                            $r[$i] += $r[$i + $b] << $b; $r[$i + $b] = 0;
                        } else if ($r[$i] - ($r[$i + $b] << $b) >= -15) {
                            $r[$i] -= $r[$i + $b] << $b;
                            for ($k = $i + $b;$k < 256;++$k) {
                                if (!$r[$k]) {
                                    $r[$k] = 1;
                                    break;
                                }
                                $r[$k] = 0;
                            }
                        } else
                            break;
                    }
                }
            }
        }
    }

    function geDoubleScalarmultVartime(GeProjective $r, $a, GeExtended $A, $b) {
        $aslide = new SplFixedArray(256);
        $bslide = new SplFixedArray(256);
        $t = new GeCompleted();
        $u = new GeExtended();
        $A2 = new GeExtended();
        $Ai = new SplFixedArray(8);

        for ($i = 0;$i < 8;++$i) $Ai[$i] = new GeCached();

        $this->slide($aslide, $a);
        $this->slide($bslide, $b);

        $this->GeExtendedtoGeCached($Ai[0], $A);
        $this->GeExtendedDouble($t, $A);
        $this->GeCompletedtoGeExtended($A2, $t);

        for ($i = 0;$i < 7;++$i) {
            $this->geAdd($t, $A2, $Ai[$i]);
            $this->GeCompletedtoGeExtended($u, $t);
            $this->GeExtendedtoGeCached($Ai[$i+1], $u);
        }

        $this->GeProjectiveZero($r);

        for ($i = 255;$i >= 0;--$i) {
            if ($aslide[$i] || $bslide[$i]) break;
        }

        for ($i = 255;$i >= 0;--$i) {
            $this->GeProjectiveDouble($t, $r);

            if ($aslide[$i] > 0) {
                $this->GeCompletedtoGeExtended($u, $t);
                $this->geAdd($t, $u, $Ai[$aslide[$i]/2]);
            } else if ($aslide[$i] < 0) {
                $this->GeCompletedtoGeExtended($u, $t);
                $this->geSub($t, $u, $Ai[(-$aslide[$i])/2]);
            }

            if ($bslide[$i] > 0) {
                $this->GeCompletedtoGeExtended($u, $t);
                $this->geMixedAdd($t, $u, static::$Bi[$bslide[$i]/2]);
            } else if ($bslide[$i] < 0) {
                $this->GeCompletedtoGeExtended($u, $t);
                $this->geMixedSub($t, $u, static::$Bi[(-$bslide[$i])/2]);
            }

            $this->GeCompletedtoGeProjective($r, $t);
        }
    }

    function scReduce($s) {
        $s0 = 2097151 & $this->feLoad3($s, 0);
        $s1 = 2097151 & ($this->feLoad4($s, 2) >> 5);
        $s2 = 2097151 & ($this->feLoad3($s, 5) >> 2);
        $s3 = 2097151 & ($this->feLoad4($s, 7) >> 7);
        $s4 = 2097151 & ($this->feLoad4($s, 10) >> 4);
        $s5 = 2097151 & ($this->feLoad3($s, 13) >> 1);
        $s6 = 2097151 & ($this->feLoad4($s, 15) >> 6);
        $s7 = 2097151 & ($this->feLoad3($s, 18) >> 3);
        $s8 = 2097151 & $this->feLoad3($s, 21);
        $s9 = 2097151 & ($this->feLoad4($s, 23) >> 5);
        $s10 = 2097151 & ($this->feLoad3($s, 26) >> 2);
        $s11 = 2097151 & ($this->feLoad4($s, 28) >> 7);
        $s12 = 2097151 & ($this->feLoad4($s, 31) >> 4);
        $s13 = 2097151 & ($this->feLoad3($s, 34) >> 1);
        $s14 = 2097151 & ($this->feLoad4($s, 36) >> 6);
        $s15 = 2097151 & ($this->feLoad3($s, 39) >> 3);
        $s16 = 2097151 & $this->feLoad3($s, 42);
        $s17 = 2097151 & ($this->feLoad4($s, 44) >> 5);
        $s18 = 2097151 & ($this->feLoad3($s, 47) >> 2);
        $s19 = 2097151 & ($this->feLoad4($s, 49) >> 7);
        $s20 = 2097151 & ($this->feLoad4($s, 52) >> 4);
        $s21 = 2097151 & ($this->feLoad3($s, 55) >> 1);
        $s22 = 2097151 & ($this->feLoad4($s, 57) >> 6);
        $s23 = ($this->feLoad4($s, 60) >> 3);

        $s11 += $s23 * 666643;
        $s12 += $s23 * 470296;
        $s13 += $s23 * 654183;
        $s14 -= $s23 * 997805;
        $s15 += $s23 * 136657;
        $s16 -= $s23 * 683901;
        $s23 = 0;

        $s10 += $s22 * 666643;
        $s11 += $s22 * 470296;
        $s12 += $s22 * 654183;
        $s13 -= $s22 * 997805;
        $s14 += $s22 * 136657;
        $s15 -= $s22 * 683901;
        $s22 = 0;

        $s9 += $s21 * 666643;
        $s10 += $s21 * 470296;
        $s11 += $s21 * 654183;
        $s12 -= $s21 * 997805;
        $s13 += $s21 * 136657;
        $s14 -= $s21 * 683901;
        $s21 = 0;

        $s8 += $s20 * 666643;
        $s9 += $s20 * 470296;
        $s10 += $s20 * 654183;
        $s11 -= $s20 * 997805;
        $s12 += $s20 * 136657;
        $s13 -= $s20 * 683901;
        $s20 = 0;

        $s7 += $s19 * 666643;
        $s8 += $s19 * 470296;
        $s9 += $s19 * 654183;
        $s10 -= $s19 * 997805;
        $s11 += $s19 * 136657;
        $s12 -= $s19 * 683901;
        $s19 = 0;

        $s6 += $s18 * 666643;
        $s7 += $s18 * 470296;
        $s8 += $s18 * 654183;
        $s9 -= $s18 * 997805;
        $s10 += $s18 * 136657;
        $s11 -= $s18 * 683901;
        $s18 = 0;

        $carry6 = ($s6 + (1<<20)) >> 21; $s7 += $carry6; $s6 -= $carry6 << 21;
        $carry8 = ($s8 + (1<<20)) >> 21; $s9 += $carry8; $s8 -= $carry8 << 21;
        $carry10 = ($s10 + (1<<20)) >> 21; $s11 += $carry10; $s10 -= $carry10 << 21;
        $carry12 = ($s12 + (1<<20)) >> 21; $s13 += $carry12; $s12 -= $carry12 << 21;
        $carry14 = ($s14 + (1<<20)) >> 21; $s15 += $carry14; $s14 -= $carry14 << 21;
        $carry16 = ($s16 + (1<<20)) >> 21; $s17 += $carry16; $s16 -= $carry16 << 21;

        $carry7 = ($s7 + (1<<20)) >> 21; $s8 += $carry7; $s7 -= $carry7 << 21;
        $carry9 = ($s9 + (1<<20)) >> 21; $s10 += $carry9; $s9 -= $carry9 << 21;
        $carry11 = ($s11 + (1<<20)) >> 21; $s12 += $carry11; $s11 -= $carry11 << 21;
        $carry13 = ($s13 + (1<<20)) >> 21; $s14 += $carry13; $s13 -= $carry13 << 21;
        $carry15 = ($s15 + (1<<20)) >> 21; $s16 += $carry15; $s15 -= $carry15 << 21;

        $s5 += $s17 * 666643;
        $s6 += $s17 * 470296;
        $s7 += $s17 * 654183;
        $s8 -= $s17 * 997805;
        $s9 += $s17 * 136657;
        $s10 -= $s17 * 683901;
        $s17 = 0;

        $s4 += $s16 * 666643;
        $s5 += $s16 * 470296;
        $s6 += $s16 * 654183;
        $s7 -= $s16 * 997805;
        $s8 += $s16 * 136657;
        $s9 -= $s16 * 683901;
        $s16 = 0;

        $s3 += $s15 * 666643;
        $s4 += $s15 * 470296;
        $s5 += $s15 * 654183;
        $s6 -= $s15 * 997805;
        $s7 += $s15 * 136657;
        $s8 -= $s15 * 683901;
        $s15 = 0;

        $s2 += $s14 * 666643;
        $s3 += $s14 * 470296;
        $s4 += $s14 * 654183;
        $s5 -= $s14 * 997805;
        $s6 += $s14 * 136657;
        $s7 -= $s14 * 683901;
        $s14 = 0;

        $s1 += $s13 * 666643;
        $s2 += $s13 * 470296;
        $s3 += $s13 * 654183;
        $s4 -= $s13 * 997805;
        $s5 += $s13 * 136657;
        $s6 -= $s13 * 683901;
        $s13 = 0;

        $s0 += $s12 * 666643;
        $s1 += $s12 * 470296;
        $s2 += $s12 * 654183;
        $s3 -= $s12 * 997805;
        $s4 += $s12 * 136657;
        $s5 -= $s12 * 683901;
        $s12 = 0;

        $carry0 = ($s0 + (1<<20)) >> 21; $s1 += $carry0; $s0 -= $carry0 << 21;
        $carry2 = ($s2 + (1<<20)) >> 21; $s3 += $carry2; $s2 -= $carry2 << 21;
        $carry4 = ($s4 + (1<<20)) >> 21; $s5 += $carry4; $s4 -= $carry4 << 21;
        $carry6 = ($s6 + (1<<20)) >> 21; $s7 += $carry6; $s6 -= $carry6 << 21;
        $carry8 = ($s8 + (1<<20)) >> 21; $s9 += $carry8; $s8 -= $carry8 << 21;
        $carry10 = ($s10 + (1<<20)) >> 21; $s11 += $carry10; $s10 -= $carry10 << 21;

        $carry1 = ($s1 + (1<<20)) >> 21; $s2 += $carry1; $s1 -= $carry1 << 21;
        $carry3 = ($s3 + (1<<20)) >> 21; $s4 += $carry3; $s3 -= $carry3 << 21;
        $carry5 = ($s5 + (1<<20)) >> 21; $s6 += $carry5; $s5 -= $carry5 << 21;
        $carry7 = ($s7 + (1<<20)) >> 21; $s8 += $carry7; $s7 -= $carry7 << 21;
        $carry9 = ($s9 + (1<<20)) >> 21; $s10 += $carry9; $s9 -= $carry9 << 21;
        $carry11 = ($s11 + (1<<20)) >> 21; $s12 += $carry11; $s11 -= $carry11 << 21;

        $s0 += $s12 * 666643;
        $s1 += $s12 * 470296;
        $s2 += $s12 * 654183;
        $s3 -= $s12 * 997805;
        $s4 += $s12 * 136657;
        $s5 -= $s12 * 683901;
        $s12 = 0;

        $carry0 = $s0 >> 21; $s1 += $carry0; $s0 -= $carry0 << 21;
        $carry1 = $s1 >> 21; $s2 += $carry1; $s1 -= $carry1 << 21;
        $carry2 = $s2 >> 21; $s3 += $carry2; $s2 -= $carry2 << 21;
        $carry3 = $s3 >> 21; $s4 += $carry3; $s3 -= $carry3 << 21;
        $carry4 = $s4 >> 21; $s5 += $carry4; $s4 -= $carry4 << 21;
        $carry5 = $s5 >> 21; $s6 += $carry5; $s5 -= $carry5 << 21;
        $carry6 = $s6 >> 21; $s7 += $carry6; $s6 -= $carry6 << 21;
        $carry7 = $s7 >> 21; $s8 += $carry7; $s7 -= $carry7 << 21;
        $carry8 = $s8 >> 21; $s9 += $carry8; $s8 -= $carry8 << 21;
        $carry9 = $s9 >> 21; $s10 += $carry9; $s9 -= $carry9 << 21;
        $carry10 = $s10 >> 21; $s11 += $carry10; $s10 -= $carry10 << 21;
        $carry11 = $s11 >> 21; $s12 += $carry11; $s11 -= $carry11 << 21;

        $s0 += $s12 * 666643;
        $s1 += $s12 * 470296;
        $s2 += $s12 * 654183;
        $s3 -= $s12 * 997805;
        $s4 += $s12 * 136657;
        $s5 -= $s12 * 683901;
        $s12 = 0;

        $carry0 = $s0 >> 21; $s1 += $carry0; $s0 -= $carry0 << 21;
        $carry1 = $s1 >> 21; $s2 += $carry1; $s1 -= $carry1 << 21;
        $carry2 = $s2 >> 21; $s3 += $carry2; $s2 -= $carry2 << 21;
        $carry3 = $s3 >> 21; $s4 += $carry3; $s3 -= $carry3 << 21;
        $carry4 = $s4 >> 21; $s5 += $carry4; $s4 -= $carry4 << 21;
        $carry5 = $s5 >> 21; $s6 += $carry5; $s5 -= $carry5 << 21;
        $carry6 = $s6 >> 21; $s7 += $carry6; $s6 -= $carry6 << 21;
        $carry7 = $s7 >> 21; $s8 += $carry7; $s7 -= $carry7 << 21;
        $carry8 = $s8 >> 21; $s9 += $carry8; $s8 -= $carry8 << 21;
        $carry9 = $s9 >> 21; $s10 += $carry9; $s9 -= $carry9 << 21;
        $carry10 = $s10 >> 21; $s11 += $carry10; $s10 -= $carry10 << 21;

        $s[0] = ($s0 >> 0) & 0xff;
        $s[1] = ($s0 >> 8) & 0xff;
        $s[2] = (($s0 >> 16) | ($s1 << 5)) & 0xff;
        $s[3] = ($s1 >> 3) & 0xff;
        $s[4] = ($s1 >> 11) & 0xff;
        $s[5] = (($s1 >> 19) | ($s2 << 2)) & 0xff;
        $s[6] = ($s2 >> 6) & 0xff;
        $s[7] = (($s2 >> 14) | ($s3 << 7)) & 0xff;
        $s[8] = ($s3 >> 1) & 0xff;
        $s[9] = ($s3 >> 9) & 0xff;
        $s[10] = (($s3 >> 17) | ($s4 << 4)) & 0xff;
        $s[11] = ($s4 >> 4) & 0xff;
        $s[12] = ($s4 >> 12) & 0xff;
        $s[13] = (($s4 >> 20) | ($s5 << 1)) & 0xff;
        $s[14] = ($s5 >> 7) & 0xff;
        $s[15] = (($s5 >> 15) | ($s6 << 6)) & 0xff;
        $s[16] = ($s6 >> 2) & 0xff;
        $s[17] = ($s6 >> 10) & 0xff;
        $s[18] = (($s6 >> 18) | ($s7 << 3)) & 0xff;
        $s[19] = ($s7 >> 5) & 0xff;
        $s[20] = ($s7 >> 13) & 0xff;
        $s[21] = ($s8 >> 0) & 0xff;
        $s[22] = ($s8 >> 8) & 0xff;
        $s[23] = (($s8 >> 16) | ($s9 << 5)) & 0xff;
        $s[24] = ($s9 >> 3) & 0xff;
        $s[25] = ($s9 >> 11) & 0xff;
        $s[26] = (($s9 >> 19) | ($s10 << 2)) & 0xff;
        $s[27] = ($s10 >> 6) & 0xff;
        $s[28] = (($s10 >> 14) | ($s11 << 7)) & 0xff;
        $s[29] = ($s11 >> 1) & 0xff;
        $s[30] = ($s11 >> 9) & 0xff;
        $s[31] = ($s11 >> 17) & 0xff;
    }

    function scMulAdd($s, $a, $b, $c) {
        $a0 = 2097151 & $this->feLoad3($a, 0);
        $a1 = 2097151 & ($this->feLoad4($a, 2) >> 5);
        $a2 = 2097151 & ($this->feLoad3($a, 5) >> 2);
        $a3 = 2097151 & ($this->feLoad4($a, 7) >> 7);
        $a4 = 2097151 & ($this->feLoad4($a, 10) >> 4);
        $a5 = 2097151 & ($this->feLoad3($a, 13) >> 1);
        $a6 = 2097151 & ($this->feLoad4($a, 15) >> 6);
        $a7 = 2097151 & ($this->feLoad3($a, 18) >> 3);
        $a8 = 2097151 & $this->feLoad3($a, 21);
        $a9 = 2097151 & ($this->feLoad4($a, 23) >> 5);
        $a10 = 2097151 & ($this->feLoad3($a, 26) >> 2);
        $a11 = ($this->feLoad4($a, 28) >> 7);
        $b0 = 2097151 & $this->feLoad3($b, 0);
        $b1 = 2097151 & ($this->feLoad4($b, 2) >> 5);
        $b2 = 2097151 & ($this->feLoad3($b, 5) >> 2);
        $b3 = 2097151 & ($this->feLoad4($b, 7) >> 7);
        $b4 = 2097151 & ($this->feLoad4($b, 10) >> 4);
        $b5 = 2097151 & ($this->feLoad3($b, 13) >> 1);
        $b6 = 2097151 & ($this->feLoad4($b, 15) >> 6);
        $b7 = 2097151 & ($this->feLoad3($b, 18) >> 3);
        $b8 = 2097151 & $this->feLoad3($b, 21);
        $b9 = 2097151 & ($this->feLoad4($b, 23) >> 5);
        $b10 = 2097151 & ($this->feLoad3($b, 26) >> 2);
        $b11 = ($this->feLoad4($b, 28) >> 7);
        $c0 = 2097151 & $this->feLoad3($c, 0);
        $c1 = 2097151 & ($this->feLoad4($c, 2) >> 5);
        $c2 = 2097151 & ($this->feLoad3($c, 5) >> 2);
        $c3 = 2097151 & ($this->feLoad4($c, 7) >> 7);
        $c4 = 2097151 & ($this->feLoad4($c, 10) >> 4);
        $c5 = 2097151 & ($this->feLoad3($c, 13) >> 1);
        $c6 = 2097151 & ($this->feLoad4($c, 15) >> 6);
        $c7 = 2097151 & ($this->feLoad3($c, 18) >> 3);
        $c8 = 2097151 & $this->feLoad3($c, 21);
        $c9 = 2097151 & ($this->feLoad4($c, 23) >> 5);
        $c10 = 2097151 & ($this->feLoad3($c, 26) >> 2);
        $c11 = ($this->feLoad4($c, 28) >> 7);

        $s0 = $c0 + $a0*$b0;
        $s1 = $c1 + $a0*$b1 + $a1*$b0;
        $s2 = $c2 + $a0*$b2 + $a1*$b1 + $a2*$b0;
        $s3 = $c3 + $a0*$b3 + $a1*$b2 + $a2*$b1 + $a3*$b0;
        $s4 = $c4 + $a0*$b4 + $a1*$b3 + $a2*$b2 + $a3*$b1 + $a4*$b0;
        $s5 = $c5 + $a0*$b5 + $a1*$b4 + $a2*$b3 + $a3*$b2 + $a4*$b1 + $a5*$b0;
        $s6 = $c6 + $a0*$b6 + $a1*$b5 + $a2*$b4 + $a3*$b3 + $a4*$b2 + $a5*$b1 + $a6*$b0;
        $s7 = $c7 + $a0*$b7 + $a1*$b6 + $a2*$b5 + $a3*$b4 + $a4*$b3 + $a5*$b2 + $a6*$b1 + $a7*$b0;
        $s8 = $c8 + $a0*$b8 + $a1*$b7 + $a2*$b6 + $a3*$b5 + $a4*$b4 + $a5*$b3 + $a6*$b2 + $a7*$b1 + $a8*$b0;
        $s9 = $c9 + $a0*$b9 + $a1*$b8 + $a2*$b7 + $a3*$b6 + $a4*$b5 + $a5*$b4 + $a6*$b3 + $a7*$b2 + $a8*$b1 + $a9*$b0;
        $s10 = $c10 + $a0*$b10 + $a1*$b9 + $a2*$b8 + $a3*$b7 + $a4*$b6 + $a5*$b5 + $a6*$b4 + $a7*$b3 + $a8*$b2 + $a9*$b1 + $a10*$b0;
        $s11 = $c11 + $a0*$b11 + $a1*$b10 + $a2*$b9 + $a3*$b8 + $a4*$b7 + $a5*$b6 + $a6*$b5 + $a7*$b4 + $a8*$b3 + $a9*$b2 + $a10*$b1 + $a11*$b0;
        $s12 = $a1*$b11 + $a2*$b10 + $a3*$b9 + $a4*$b8 + $a5*$b7 + $a6*$b6 + $a7*$b5 + $a8*$b4 + $a9*$b3 + $a10*$b2 + $a11*$b1;
        $s13 = $a2*$b11 + $a3*$b10 + $a4*$b9 + $a5*$b8 + $a6*$b7 + $a7*$b6 + $a8*$b5 + $a9*$b4 + $a10*$b3 + $a11*$b2;
        $s14 = $a3*$b11 + $a4*$b10 + $a5*$b9 + $a6*$b8 + $a7*$b7 + $a8*$b6 + $a9*$b5 + $a10*$b4 + $a11*$b3;
        $s15 = $a4*$b11 + $a5*$b10 + $a6*$b9 + $a7*$b8 + $a8*$b7 + $a9*$b6 + $a10*$b5 + $a11*$b4;
        $s16 = $a5*$b11 + $a6*$b10 + $a7*$b9 + $a8*$b8 + $a9*$b7 + $a10*$b6 + $a11*$b5;
        $s17 = $a6*$b11 + $a7*$b10 + $a8*$b9 + $a9*$b8 + $a10*$b7 + $a11*$b6;
        $s18 = $a7*$b11 + $a8*$b10 + $a9*$b9 + $a10*$b8 + $a11*$b7;
        $s19 = $a8*$b11 + $a9*$b10 + $a10*$b9 + $a11*$b8;
        $s20 = $a9*$b11 + $a10*$b10 + $a11*$b9;
        $s21 = $a10*$b11 + $a11*$b10;
        $s22 = $a11*$b11;
        $s23 = 0;

        $carry0 = ($s0 + (1<<20)) >> 21; $s1 += $carry0; $s0 -= $carry0 << 21;
        $carry2 = ($s2 + (1<<20)) >> 21; $s3 += $carry2; $s2 -= $carry2 << 21;
        $carry4 = ($s4 + (1<<20)) >> 21; $s5 += $carry4; $s4 -= $carry4 << 21;
        $carry6 = ($s6 + (1<<20)) >> 21; $s7 += $carry6; $s6 -= $carry6 << 21;
        $carry8 = ($s8 + (1<<20)) >> 21; $s9 += $carry8; $s8 -= $carry8 << 21;
        $carry10 = ($s10 + (1<<20)) >> 21; $s11 += $carry10; $s10 -= $carry10 << 21;
        $carry12 = ($s12 + (1<<20)) >> 21; $s13 += $carry12; $s12 -= $carry12 << 21;
        $carry14 = ($s14 + (1<<20)) >> 21; $s15 += $carry14; $s14 -= $carry14 << 21;
        $carry16 = ($s16 + (1<<20)) >> 21; $s17 += $carry16; $s16 -= $carry16 << 21;
        $carry18 = ($s18 + (1<<20)) >> 21; $s19 += $carry18; $s18 -= $carry18 << 21;
        $carry20 = ($s20 + (1<<20)) >> 21; $s21 += $carry20; $s20 -= $carry20 << 21;
        $carry22 = ($s22 + (1<<20)) >> 21; $s23 += $carry22; $s22 -= $carry22 << 21;

        $carry1 = ($s1 + (1<<20)) >> 21; $s2 += $carry1; $s1 -= $carry1 << 21;
        $carry3 = ($s3 + (1<<20)) >> 21; $s4 += $carry3; $s3 -= $carry3 << 21;
        $carry5 = ($s5 + (1<<20)) >> 21; $s6 += $carry5; $s5 -= $carry5 << 21;
        $carry7 = ($s7 + (1<<20)) >> 21; $s8 += $carry7; $s7 -= $carry7 << 21;
        $carry9 = ($s9 + (1<<20)) >> 21; $s10 += $carry9; $s9 -= $carry9 << 21;
        $carry11 = ($s11 + (1<<20)) >> 21; $s12 += $carry11; $s11 -= $carry11 << 21;
        $carry13 = ($s13 + (1<<20)) >> 21; $s14 += $carry13; $s13 -= $carry13 << 21;
        $carry15 = ($s15 + (1<<20)) >> 21; $s16 += $carry15; $s15 -= $carry15 << 21;
        $carry17 = ($s17 + (1<<20)) >> 21; $s18 += $carry17; $s17 -= $carry17 << 21;
        $carry19 = ($s19 + (1<<20)) >> 21; $s20 += $carry19; $s19 -= $carry19 << 21;
        $carry21 = ($s21 + (1<<20)) >> 21; $s22 += $carry21; $s21 -= $carry21 << 21;

        $s11 += $s23 * 666643;
        $s12 += $s23 * 470296;
        $s13 += $s23 * 654183;
        $s14 -= $s23 * 997805;
        $s15 += $s23 * 136657;
        $s16 -= $s23 * 683901;
        $s23 = 0;

        $s10 += $s22 * 666643;
        $s11 += $s22 * 470296;
        $s12 += $s22 * 654183;
        $s13 -= $s22 * 997805;
        $s14 += $s22 * 136657;
        $s15 -= $s22 * 683901;
        $s22 = 0;

        $s9 += $s21 * 666643;
        $s10 += $s21 * 470296;
        $s11 += $s21 * 654183;
        $s12 -= $s21 * 997805;
        $s13 += $s21 * 136657;
        $s14 -= $s21 * 683901;
        $s21 = 0;

        $s8 += $s20 * 666643;
        $s9 += $s20 * 470296;
        $s10 += $s20 * 654183;
        $s11 -= $s20 * 997805;
        $s12 += $s20 * 136657;
        $s13 -= $s20 * 683901;
        $s20 = 0;

        $s7 += $s19 * 666643;
        $s8 += $s19 * 470296;
        $s9 += $s19 * 654183;
        $s10 -= $s19 * 997805;
        $s11 += $s19 * 136657;
        $s12 -= $s19 * 683901;
        $s19 = 0;

        $s6 += $s18 * 666643;
        $s7 += $s18 * 470296;
        $s8 += $s18 * 654183;
        $s9 -= $s18 * 997805;
        $s10 += $s18 * 136657;
        $s11 -= $s18 * 683901;
        $s18 = 0;

        $carry6 = ($s6 + (1<<20)) >> 21; $s7 += $carry6; $s6 -= $carry6 << 21;
        $carry8 = ($s8 + (1<<20)) >> 21; $s9 += $carry8; $s8 -= $carry8 << 21;
        $carry10 = ($s10 + (1<<20)) >> 21; $s11 += $carry10; $s10 -= $carry10 << 21;
        $carry12 = ($s12 + (1<<20)) >> 21; $s13 += $carry12; $s12 -= $carry12 << 21;
        $carry14 = ($s14 + (1<<20)) >> 21; $s15 += $carry14; $s14 -= $carry14 << 21;
        $carry16 = ($s16 + (1<<20)) >> 21; $s17 += $carry16; $s16 -= $carry16 << 21;

        $carry7 = ($s7 + (1<<20)) >> 21; $s8 += $carry7; $s7 -= $carry7 << 21;
        $carry9 = ($s9 + (1<<20)) >> 21; $s10 += $carry9; $s9 -= $carry9 << 21;
        $carry11 = ($s11 + (1<<20)) >> 21; $s12 += $carry11; $s11 -= $carry11 << 21;
        $carry13 = ($s13 + (1<<20)) >> 21; $s14 += $carry13; $s13 -= $carry13 << 21;
        $carry15 = ($s15 + (1<<20)) >> 21; $s16 += $carry15; $s15 -= $carry15 << 21;

        $s5 += $s17 * 666643;
        $s6 += $s17 * 470296;
        $s7 += $s17 * 654183;
        $s8 -= $s17 * 997805;
        $s9 += $s17 * 136657;
        $s10 -= $s17 * 683901;
        $s17 = 0;

        $s4 += $s16 * 666643;
        $s5 += $s16 * 470296;
        $s6 += $s16 * 654183;
        $s7 -= $s16 * 997805;
        $s8 += $s16 * 136657;
        $s9 -= $s16 * 683901;
        $s16 = 0;

        $s3 += $s15 * 666643;
        $s4 += $s15 * 470296;
        $s5 += $s15 * 654183;
        $s6 -= $s15 * 997805;
        $s7 += $s15 * 136657;
        $s8 -= $s15 * 683901;
        $s15 = 0;

        $s2 += $s14 * 666643;
        $s3 += $s14 * 470296;
        $s4 += $s14 * 654183;
        $s5 -= $s14 * 997805;
        $s6 += $s14 * 136657;
        $s7 -= $s14 * 683901;
        $s14 = 0;

        $s1 += $s13 * 666643;
        $s2 += $s13 * 470296;
        $s3 += $s13 * 654183;
        $s4 -= $s13 * 997805;
        $s5 += $s13 * 136657;
        $s6 -= $s13 * 683901;
        $s13 = 0;

        $s0 += $s12 * 666643;
        $s1 += $s12 * 470296;
        $s2 += $s12 * 654183;
        $s3 -= $s12 * 997805;
        $s4 += $s12 * 136657;
        $s5 -= $s12 * 683901;
        $s12 = 0;

        $carry0 = ($s0 + (1<<20)) >> 21; $s1 += $carry0; $s0 -= $carry0 << 21;
        $carry2 = ($s2 + (1<<20)) >> 21; $s3 += $carry2; $s2 -= $carry2 << 21;
        $carry4 = ($s4 + (1<<20)) >> 21; $s5 += $carry4; $s4 -= $carry4 << 21;
        $carry6 = ($s6 + (1<<20)) >> 21; $s7 += $carry6; $s6 -= $carry6 << 21;
        $carry8 = ($s8 + (1<<20)) >> 21; $s9 += $carry8; $s8 -= $carry8 << 21;
        $carry10 = ($s10 + (1<<20)) >> 21; $s11 += $carry10; $s10 -= $carry10 << 21;

        $carry1 = ($s1 + (1<<20)) >> 21; $s2 += $carry1; $s1 -= $carry1 << 21;
        $carry3 = ($s3 + (1<<20)) >> 21; $s4 += $carry3; $s3 -= $carry3 << 21;
        $carry5 = ($s5 + (1<<20)) >> 21; $s6 += $carry5; $s5 -= $carry5 << 21;
        $carry7 = ($s7 + (1<<20)) >> 21; $s8 += $carry7; $s7 -= $carry7 << 21;
        $carry9 = ($s9 + (1<<20)) >> 21; $s10 += $carry9; $s9 -= $carry9 << 21;
        $carry11 = ($s11 + (1<<20)) >> 21; $s12 += $carry11; $s11 -= $carry11 << 21;

        $s0 += $s12 * 666643;
        $s1 += $s12 * 470296;
        $s2 += $s12 * 654183;
        $s3 -= $s12 * 997805;
        $s4 += $s12 * 136657;
        $s5 -= $s12 * 683901;
        $s12 = 0;

        $carry0 = $s0 >> 21; $s1 += $carry0; $s0 -= $carry0 << 21;
        $carry1 = $s1 >> 21; $s2 += $carry1; $s1 -= $carry1 << 21;
        $carry2 = $s2 >> 21; $s3 += $carry2; $s2 -= $carry2 << 21;
        $carry3 = $s3 >> 21; $s4 += $carry3; $s3 -= $carry3 << 21;
        $carry4 = $s4 >> 21; $s5 += $carry4; $s4 -= $carry4 << 21;
        $carry5 = $s5 >> 21; $s6 += $carry5; $s5 -= $carry5 << 21;
        $carry6 = $s6 >> 21; $s7 += $carry6; $s6 -= $carry6 << 21;
        $carry7 = $s7 >> 21; $s8 += $carry7; $s7 -= $carry7 << 21;
        $carry8 = $s8 >> 21; $s9 += $carry8; $s8 -= $carry8 << 21;
        $carry9 = $s9 >> 21; $s10 += $carry9; $s9 -= $carry9 << 21;
        $carry10 = $s10 >> 21; $s11 += $carry10; $s10 -= $carry10 << 21;
        $carry11 = $s11 >> 21; $s12 += $carry11; $s11 -= $carry11 << 21;

        $s0 += $s12 * 666643;
        $s1 += $s12 * 470296;
        $s2 += $s12 * 654183;
        $s3 -= $s12 * 997805;
        $s4 += $s12 * 136657;
        $s5 -= $s12 * 683901;
        $s12 = 0;

        $carry0 = $s0 >> 21; $s1 += $carry0; $s0 -= $carry0 << 21;
        $carry1 = $s1 >> 21; $s2 += $carry1; $s1 -= $carry1 << 21;
        $carry2 = $s2 >> 21; $s3 += $carry2; $s2 -= $carry2 << 21;
        $carry3 = $s3 >> 21; $s4 += $carry3; $s3 -= $carry3 << 21;
        $carry4 = $s4 >> 21; $s5 += $carry4; $s4 -= $carry4 << 21;
        $carry5 = $s5 >> 21; $s6 += $carry5; $s5 -= $carry5 << 21;
        $carry6 = $s6 >> 21; $s7 += $carry6; $s6 -= $carry6 << 21;
        $carry7 = $s7 >> 21; $s8 += $carry7; $s7 -= $carry7 << 21;
        $carry8 = $s8 >> 21; $s9 += $carry8; $s8 -= $carry8 << 21;
        $carry9 = $s9 >> 21; $s10 += $carry9; $s9 -= $carry9 << 21;
        $carry10 = $s10 >> 21; $s11 += $carry10; $s10 -= $carry10 << 21;

        $s[0] = ($s0 >> 0) & 0xff;
        $s[1] = ($s0 >> 8) & 0xff;
        $s[2] = (($s0 >> 16) | ($s1 << 5)) & 0xff;
        $s[3] = ($s1 >> 3) & 0xff;
        $s[4] = ($s1 >> 11) & 0xff;
        $s[5] = (($s1 >> 19) | ($s2 << 2)) & 0xff;
        $s[6] = ($s2 >> 6) & 0xff;
        $s[7] = (($s2 >> 14) | ($s3 << 7)) & 0xff;
        $s[8] = ($s3 >> 1) & 0xff;
        $s[9] = ($s3 >> 9) & 0xff;
        $s[10] = (($s3 >> 17) | ($s4 << 4)) & 0xff;
        $s[11] = ($s4 >> 4) & 0xff;
        $s[12] = ($s4 >> 12) & 0xff;
        $s[13] = (($s4 >> 20) | ($s5 << 1)) & 0xff;
        $s[14] = ($s5 >> 7) & 0xff;
        $s[15] = (($s5 >> 15) | ($s6 << 6)) & 0xff;
        $s[16] = ($s6 >> 2) & 0xff;
        $s[17] = ($s6 >> 10) & 0xff;
        $s[18] = (($s6 >> 18) | ($s7 << 3)) & 0xff;
        $s[19] = ($s7 >> 5) & 0xff;
        $s[20] = ($s7 >> 13) & 0xff;
        $s[21] = ($s8 >> 0) & 0xff;
        $s[22] = ($s8 >> 8) & 0xff;
        $s[23] = (($s8 >> 16) | ($s9 << 5)) & 0xff;
        $s[24] = ($s9 >> 3) & 0xff;
        $s[25] = ($s9 >> 11) & 0xff;
        $s[26] = (($s9 >> 19) | ($s10 << 2)) & 0xff;
        $s[27] = ($s10 >> 6) & 0xff;
        $s[28] = (($s10 >> 14) | ($s11 << 7)) & 0xff;
        $s[29] = ($s11 >> 1) & 0xff;
        $s[30] = ($s11 >> 9) & 0xff;
        $s[31] = ($s11 >> 17) & 0xff;
    }

}
/* ED25519 (end) */

/* ChaCha20 (begin) */
class Cipher
{
    function init($key, $nonce)
    {
        if (wtam_strlen($key) !== 32) {
            throw new \LengthException('Key must be a 256-bit string');
        }

        if (wtam_strlen($nonce) !== 12) {
            throw new \LengthException('Nonce must be a 96-bit string');
        }

        $ctx = new Context();
        $ctx->state = array_values(unpack('V16', "expand 32-byte k$key\0\0\0\0$nonce"));

        return $ctx;
    }

    public function decrypt($ctx, $message)
    {
        return $this->encrypt($ctx, $message);
    }

    function encrypt($ctx, $message)
    {
        $state = $ctx->state;
        $keyStream = $ctx->buffer;

        $bytesRequired = wtam_strlen($message) - wtam_strlen($keyStream);
        $bytesOver = $bytesRequired % 64;

        $blocks = ($bytesRequired >> 6) + ($bytesOver > 0);
        while ($blocks-- > 0) {
            list($s00, $s01, $s02, $s03, $s04, $s05, $s06, $s07, $s08, $s09, $s10, $s11, $s12, $s13, $s14, $s15) = $state;

            $i = 10;
            while ($i--) {
                $s04 = ((($c = $s04 ^ ($s08 += ($s12 = (((
                          $c = $s12 ^ ($s00 += ($s04 = (((
                          $c = $s04 ^ ($s08 += ($s12 = (((
                          $c = $s12 ^ ($s00 += $s04) & 0xffffffff) << 16) & 0xffffffff) | $c >> 16))
                                                                & 0xffffffff) << 12) & 0xffffffff) | $c >> 20))
                                                & 0xffffffff) << 8) & 0xffffffff) | $c >> 24))
                                & 0xffffffff) << 7) & 0xffffffff) | $c >> 25;

                $s05 = ((($c = $s05 ^ ($s09 += ($s13 = (((
                          $c = $s13 ^ ($s01 += ($s05 = (((
                          $c = $s05 ^ ($s09 += ($s13 = (((
                          $c = $s13 ^ ($s01 += $s05) & 0xffffffff) << 16) & 0xffffffff) | $c >> 16))
                              & 0xffffffff) << 12) & 0xffffffff) | $c >> 20))
                              & 0xffffffff) << 8) & 0xffffffff) | $c >> 24))
                                & 0xffffffff) << 7) & 0xffffffff) | $c >> 25;

                $s06 = ((($c = $s06 ^ ($s10 += ($s14 = (((
                          $c = $s14 ^ ($s02 += ($s06 = (((
                          $c = $s06 ^ ($s10 += ($s14 = (((
                          $c = $s14 ^ ($s02 += $s06) & 0xffffffff) << 16) & 0xffffffff) | $c >> 16))
                              & 0xffffffff) << 12) & 0xffffffff) | $c >> 20))
                              & 0xffffffff) << 8) & 0xffffffff) | $c >> 24))
                                & 0xffffffff) << 7) & 0xffffffff) | $c >> 25;

                $s07 = ((($c = $s07 ^ ($s11 += ($s15 = (((
                          $c = $s15 ^ ($s03 += ($s07 = (((
                          $c = $s07 ^ ($s11 += ($s15 = (((
                          $c = $s15 ^ ($s03 += $s07) & 0xffffffff) << 16) & 0xffffffff) | $c >> 16))
                              & 0xffffffff) << 12) & 0xffffffff) | $c >> 20))
                              & 0xffffffff) << 8) & 0xffffffff) | $c >> 24))
                                & 0xffffffff) << 7) & 0xffffffff) | $c >> 25;

                $s05 = ((($c = $s05 ^ ($s10 += ($s15 = (((
                          $c = $s15 ^ ($s00 += ($s05 = (((
                          $c = $s05 ^ ($s10 += ($s15 = (((
                          $c = $s15 ^ ($s00 += $s05) & 0xffffffff) << 16) & 0xffffffff) | $c >> 16))
                              & 0xffffffff) << 12) & 0xffffffff) | $c >> 20))
                              & 0xffffffff) << 8) & 0xffffffff) | $c >> 24))
                                & 0xffffffff) << 7) & 0xffffffff) | $c >> 25;

                $s06 = ((($c = $s06 ^ ($s11 += ($s12 = (((
                          $c = $s12 ^ ($s01 += ($s06 = (((
                          $c = $s06 ^ ($s11 += ($s12 = (((
                          $c = $s12 ^ ($s01 += $s06) & 0xffffffff) << 16) & 0xffffffff) | $c >> 16))
                              & 0xffffffff) << 12) & 0xffffffff) | $c >> 20))
                              & 0xffffffff) << 8) & 0xffffffff) | $c >> 24))
                                & 0xffffffff) << 7) & 0xffffffff) | $c >> 25;

                $s07 = ((($c = $s07 ^ ($s08 += ($s13 = (((
                          $c = $s13 ^ ($s02 += ($s07 = (((
                          $c = $s07 ^ ($s08 += ($s13 = (((
                          $c = $s13 ^ ($s02 += $s07) & 0xffffffff) << 16) & 0xffffffff) | $c >> 16))
                              & 0xffffffff) << 12) & 0xffffffff) | $c >> 20))
                              & 0xffffffff) << 8) & 0xffffffff) | $c >> 24))
                                & 0xffffffff) << 7) & 0xffffffff) | $c >> 25;

                $s04 = ((($c = $s04 ^ ($s09 += ($s14 = (((
                          $c = $s14 ^ ($s03 += ($s04 = (((
                          $c = $s04 ^ ($s09 += ($s14 = (((
                          $c = $s14 ^ ($s03 += $s04) & 0xffffffff) << 16) & 0xffffffff) | $c >> 16))
                              & 0xffffffff) << 12) & 0xffffffff) | $c >> 20))
                              & 0xffffffff) << 8) & 0xffffffff) | $c >> 24))
                                & 0xffffffff) << 7) & 0xffffffff) | $c >> 25;
            }

            $keyStream .= pack('V16',
                $s00 + $state[0], $s01 + $state[1],
                $s02 + $state[2], $s03 + $state[3],
                $s04 + $state[4], $s05 + $state[5],
                $s06 + $state[6], $s07 + $state[7],
                $s08 + $state[8], $s09 + $state[9],
                $s10 + $state[10], $s11 + $state[11],
                $s12 + $state[12], $s13 + $state[13],
                $s14 + $state[14], $s15 + $state[15]
            );

            if (++$state[12] & 0xf00000000) {
                throw new \OverflowException('Counter overflowed upper bound');
            }
        }

        $ctx->buffer = wtam_substr($keyStream, $bytesRequired);
        $ctx->state = $state;

        return $message ^ $keyStream;
    }

    public function setCounter($ctx, $counter)
    {
        if ($counter < 0 || $counter > 0xffffffff) {
            throw new \InvalidArgumentException('Counter must be 32-bit positive integer');
        }
        $ctx->state[12] = $counter;
        $ctx->buffer = '';
    }
}

class Context
{
    public $state;
    public $buffer = '';
}
/* ChaCha20 (end) */




/* Poly1305 (begin) */
class Native implements Streamable
{
    function init($key)
    {
        if (wtam_strlen($key) !== 32) {
            throw new \InvalidArgumentException('Key must be a 256-bit string');
        }
        $ctx = new Context();
        $words = unpack('v8', $key);
        $ctx->r = [
            ( $words[1]        | ($words[2] << 16))                     & 0x3ffffff,
            (($words[2] >> 10) | ($words[3] <<  6) | ($words[4] << 22)) & 0x3ffff03,
            (($words[4] >>  4) | ($words[5] << 12))                     & 0x3ffc0ff,
            (($words[5] >> 14) | ($words[6] <<  2) | ($words[7] << 18)) & 0x3f03fff,
            (($words[7] >>  8) | ($words[8] <<  8))                     & 0x00fffff,
        ];
        $words = unpack('@16/v8', $key);
        $ctx->s = [
            ( $words[1]        | ($words[2] << 16))                     & 0x3ffffff,
            (($words[2] >> 10) | ($words[3] <<  6) | ($words[4] << 22)) & 0x3ffffff,
            (($words[4] >>  4) | ($words[5] << 12))                     & 0x3ffffff,
            (($words[5] >> 14) | ($words[6] <<  2) | ($words[7] << 18)) & 0x3ffffff,
            (($words[7] >>  8) | ($words[8] <<  8))                     & 0x0ffffff,
        ];
        $ctx->h = [0, 0, 0, 0, 0];
        $ctx->buffer = '';
        $ctx->hibit = 0x1000000;
        $ctx->init = true;
        return $ctx;
    }
    function update($ctx, $message)
    {
        if (!$ctx->init) {
            throw new \InvalidArgumentException('Context not initialised');
        }
        if ($ctx->buffer) {
            $message = $ctx->buffer . $message;
            $ctx->buffer = '';
        }
        $offset = 0;
        $hibit = $ctx->hibit;
        list($r0, $r1, $r2, $r3, $r4) = $ctx->r;
        $s1 = 5 * $r1;
        $s2 = 5 * $r2;
        $s3 = 5 * $r3;
        $s4 = 5 * $r4;
        list($h0, $h1, $h2, $h3, $h4) = $ctx->h;
        $msgLen = wtam_strlen($message);
        $blocks = $msgLen >> 4;
        while ($blocks--) {
            $words = unpack("@$offset/v8", $message);
            $h0 += ( $words[1]        | ($words[2] << 16))                     & 0x3ffffff;
            $h1 += (($words[2] >> 10) | ($words[3] <<  6) | ($words[4] << 22)) & 0x3ffffff;
            $h2 += (($words[4] >>  4) | ($words[5] << 12))                     & 0x3ffffff;
            $h3 += (($words[5] >> 14) | ($words[6] <<  2) | ($words[7] << 18)) & 0x3ffffff;
            $h4 += (($words[7] >>  8) | ($words[8] <<  8))                     | $hibit;
            $hr0 = ($h0 * $r0) + ($h1 * $s4) + ($h2 * $s3) + ($h3 * $s2) + ($h4 * $s1);
            $hr1 = ($h0 * $r1) + ($h1 * $r0) + ($h2 * $s4) + ($h3 * $s3) + ($h4 * $s2);
            $hr2 = ($h0 * $r2) + ($h1 * $r1) + ($h2 * $r0) + ($h3 * $s4) + ($h4 * $s3);
            $hr3 = ($h0 * $r3) + ($h1 * $r2) + ($h2 * $r1) + ($h3 * $r0) + ($h4 * $s4);
            $hr4 = ($h0 * $r4) + ($h1 * $r3) + ($h2 * $r2) + ($h3 * $r1) + ($h4 * $r0);
                        $c = $hr0 >> 26; $h0 = $hr0 & 0x3ffffff;
            $hr1 += $c; $c = $hr1 >> 26; $h1 = $hr1 & 0x3ffffff;
            $hr2 += $c; $c = $hr2 >> 26; $h2 = $hr2 & 0x3ffffff;
            $hr3 += $c; $c = $hr3 >> 26; $h3 = $hr3 & 0x3ffffff;
            $hr4 += $c; $c = $hr4 >> 26; $h4 = $hr4 & 0x3ffffff;
            $h0 += 5 * $c; $c = $h0 >> 26; $h0 &= 0x3ffffff;
            $h1 += $c;
            $offset += 16;
        }
        $ctx->h = [$h0, $h1, $h2, $h3, $h4];
        if ($offset < $msgLen) {
            $ctx->buffer = wtam_substr($message, $offset);
        }
    }
    function finish($ctx)
    {
        if (!$ctx->init) {
            throw new \InvalidArgumentException('Context not initialised');
        }
        if ($ctx->buffer) {
            $ctx->hibit = 0;
            $this->update($ctx, "\1" . str_repeat("\0", 15 - wtam_strlen($ctx->buffer)));
        }
        list($h0, $h1, $h2, $h3, $h4) = $ctx->h;
                   $c = $h1 >> 26; $h1 &= 0x3ffffff;
        $h2 += $c; $c = $h2 >> 26; $h2 &= 0x3ffffff;
        $h3 += $c; $c = $h3 >> 26; $h3 &= 0x3ffffff;
        $h4 += $c; $c = $h4 >> 26; $h4 &= 0x3ffffff;
        $h0 += 5 * $c; $c = $h0 >> 26; $h0 &= 0x3ffffff;
        $h1 += $c;
        $g0 = $h0  + 5; $c = $g0 >> 26; $g0 &= 0x3ffffff;
        $g1 = $h1 + $c; $c = $g1 >> 26; $g1 &= 0x3ffffff;
        $g2 = $h2 + $c; $c = $g2 >> 26; $g2 &= 0x3ffffff;
        $g3 = $h3 + $c; $c = $g3 >> 26; $g3 &= 0x3ffffff;
        $g4 = ($h4 + $c - (1 << 26)) & 0xffffffff;
        $mask = ($g4 >> 31) - 1;
        $g0 &= $mask;
        $g1 &= $mask;
        $g2 &= $mask;
        $g3 &= $mask;
        $g4 &= $mask;
        $mask = ~$mask & 0xffffffff;
        $h0 = ($h0 & $mask) | $g0;
        $h1 = ($h1 & $mask) | $g1;
        $h2 = ($h2 & $mask) | $g2;
        $h3 = ($h3 & $mask) | $g3;
        $h4 = ($h4 & $mask) | $g4;
        list($s0, $s1, $s2, $s3, $s4) = $ctx->s;
        $c = $h0 + $s0;              $h0 = $c & 0x3ffffff;
        $c = $h1 + $s1 + ($c >> 26); $h1 = $c & 0x3ffffff;
        $c = $h2 + $s2 + ($c >> 26); $h2 = $c & 0x3ffffff;
        $c = $h3 + $s3 + ($c >> 26); $h3 = $c & 0x3ffffff;
        $c = $h4 + $s4 + ($c >> 26); $h4 = $c & 0x0ffffff;
        $mac = pack('v8', $h0,
            (($h0 >> 16) | ($h1 << 10)),
             ($h1 >>  6), (($h1 >> 22) | ($h2 <<  4)),
            (($h2 >> 12) | ($h3 << 14)), ($h3 >>  2),
            (($h3 >> 18) | ($h4 <<  8)), ( $h4 >>  8)
        );
        $ctx->init = false;
        return $mac;
    }
}

interface Streamable
{
    function init($key);
    function update($ctx, $message);
    function finish($ctx);
}

if (!extension_loaded('poly1305')) {
    function authenticate($key, $message)
    {
        $authenticator = new Authenticator();
        $context = $authenticator->init($key);
        $authenticator->update($context, $message);
        return $authenticator->finish($context);
    }
    function verify($mac, $key, $message)
    {
        if (wtam_strlen($mac) !== 16) {
            throw new \InvalidArgumentException('MAC must be a 128-bit string.');
        }
        return hash_equals($mac, authenticate($key, $message));
    }
}

class GMP2 implements Streamable
{
    private $p;
    private $hibit;
    function __construct()
    {
        $this->hibit = gmp_init('100000000000000000000000000000000', 16);
        $this->p = gmp_init('3fffffffffffffffffffffffffffffffb', 16);
    }
    function init($key)
    {
        if (wtam_strlen($key) !== 32) {
            throw new \InvalidArgumentException('Key must be a 256-bit string');
        }
        $ctx = new Context();
        $ctx->r = gmp_import($key & "\xff\xff\xff\x0f\xfc\xff\xff\x0f\xfc\xff\xff\x0f\xfc\xff\xff\x0f", 1, GMP_LSW_FIRST | GMP_LITTLE_ENDIAN);
        $ctx->s = gmp_import(wtam_substr($key, 16), 1, GMP_LSW_FIRST | GMP_LITTLE_ENDIAN);
        $ctx->h = gmp_init('0');
        $ctx->buffer = '';
        $ctx->init = true;
        return $ctx;
    }
    function update($ctx, $message)
    {
        if (!$ctx->init) {
            throw new \InvalidArgumentException('Context not initialised');
        }
        $msgLen = wtam_strlen($message);
        if ($ctx->buffer) {
            $bufferLen = wtam_strlen($ctx->buffer);
            $offset = 16 - $bufferLen;
            if ($msgLen + $bufferLen >= 16) {
                $c = gmp_import($ctx->buffer . wtam_substr($message, 0, $offset), 1, GMP_LSW_FIRST | GMP_LITTLE_ENDIAN);
                $ctx->h = gmp_div_r(($c + $ctx->h + $this->hibit) * $ctx->r, $this->p);
                $ctx->buffer = '';
            }
            else {
                $ctx->buffer .= $message;
                return;
            }
        }
        else {
            $offset = 0;
        }
        $blocks = ($msgLen - $offset) >> 4;
        while ($blocks--) {
            $c = gmp_import(wtam_substr($message, $offset, 16), 1, GMP_LSW_FIRST | GMP_LITTLE_ENDIAN);
            $ctx->h = gmp_div_r(($c + $ctx->h + $this->hibit) * $ctx->r, $this->p);
            $offset += 16;
        }
        if ($offset < $msgLen) {
            $ctx->buffer = wtam_substr($message, $offset);
        }
    }
    function finish($ctx)
    {
        if (!$ctx->init) {
            throw new \InvalidArgumentException('Context not initialised');
        }
        if ($ctx->buffer) {
            $c = gmp_import($ctx->buffer, 1, GMP_LSW_FIRST | GMP_LITTLE_ENDIAN);
            $ctx->h = gmp_div_r(($c + $ctx->h + gmp_pow('2', wtam_strlen($ctx->buffer) << 3)) * $ctx->r, $this->p);
        }
        $ctx->h += $ctx->s;
        $out = array();
        $tmp = array(4 => [8, 0x10000, 'v8'], 8 => [4, 0x100000000, 'V4']);
        list($max, $div, $format) = $tmp[PHP_INT_SIZE];
        for ($j = 0; $j < $max; $j++) {
            list($ctx->h, $out[$j]) = gmp_div_qr($ctx->h, $div);
        }
        $ctx->init = false;
        if (version_compare(phpversion(), '5.6.0', '<')) {
            $tmp = extract($out, EXTR_PREFIX_SAME, "wtvar");
            return pack($format, $tmp);
        }
        else{
            return pack($format, ...$out);
        }
        
        
    }
}
if (extension_loaded('gmp')) {
    class Authenticator extends GMP2 {}
}
else {
    class Authenticator extends Native {}
}
/* Poly1305 (end) */


    


function randomStr($length = 12){
	$chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
	$string = '';  
	for ($i = 0; $i < $length; $i++) {
			$string .= wtam_substr($chars, rand(1, wtam_strlen($chars)) - 1, 1);
	}
		
	return $string;
}
function string2ByteArray($string) {
    return unpack('C*', $string);
}

function byteArray2String($byteArray) {
    $chars = array_map("chr", $byteArray);
    return join($chars);
}

function byteObj2String($byteArray) {
    $byteArray = (array)$byteArray;
    $chars = array_map("chr", $byteArray);
    return join($chars);
}
function byteArray2Hex($byteArray) {
    $chars = array_map("chr", $byteArray);
    $bin = join($chars);
    return bin2hex($bin);
}
function hex2ByteArray($hexString) {
    $string = hex2bin($hexString);
    return unpack('C*', $string);
}
function string2Hex($string) {
    return bin2hex($string);
}

function hex2String($hexString) {
    return hex2bin($hexString);
}

function receiveRequest($seskey=AGENT_KEY){
    if (DEBUGAM===true) {
        return file_get_contents("php://input");
    }
    else {
        $header_encoded = getallheaders();
        $header_encoded = $header_encoded['Wt-Signature'];
        if (!$header_encoded) {
            wt_logs('header not found', 'ERROR');
            die('header not found');
        }
        wt_logs($header_encoded, 'header_encoded');
        $header = base64_decode($header_encoded);
        if (!$header) {
            wt_logs('header not decoded', 'ERROR');
            die('header not decoded');
        }
        wt_logs($header, 'header');
        $header_hmac = wtam_substr($header, 0, 16);
        $header_sign = wtam_substr($header, 16);

        if (!$header_hmac) {
            wt_logs('hmac not found', 'ERROR');
            die('hmac not found');
        }

        if( !verify($header_hmac, AGENT_KEY, $header_sign) ) { // poly1305
            wt_logs('VERIFYED: [hmac in header wrong]', 'ERROR');
            die('hmac in headers is wrong');
        }
        else {
            wt_logs('VERIFYED: [hmac in header is right]', 'INFO');
            $totem_request = file_get_contents("php://input");
            wt_logs($totem_request, 'totem_request');
            $totem_request_len = wtam_strlen($totem_request);
            wt_logs($totem_request_len, 'totem_request_len');
            wt_logs($header_encoded, '$header (base64_encode, origin)');
            $header_sign_base64 = base64_encode($header_sign);
            wt_logs($header_sign_base64, 'header_sign (base64_encode)');
                            
            $sign_good = false;
            if ( function_exists('sodium_crypto_sign_verify_detached') ) {
                if (CHECKSIGNATURE) {
                    $sign_verify2 = sodium_crypto_sign_verify_detached($header_sign, $totem_request, PUBLIC_KEY);
                    if ($sign_verify2) {
                        wt_logs('YES', 'VERIFY 2');
                        $sign_good = true;
                    }
                    else {
                        wt_logs('NO', 'VERIFY 2');
                        $sign_good = false;
                    }
                }
            }
            else {
                $sign_good = true;
            }
            
            if ( ($sign_good && CHECKSIGNATURE) || (!CHECKSIGNATURE) ) {
                wt_logs('YES (or pass) SIGNATURED: sign in header right', 'INFO');
                $timestamp = wtam_substr($totem_request, 0, 8);
                $timestamp = unpack('P', $timestamp);
                $timestamp = $timestamp[1];
                $nonce = wtam_substr($totem_request, 8, 12);
                $hmac = wtam_substr($totem_request, 20, 16);
                $request_encrypted = wtam_substr($totem_request, 36);
                if( !verify($hmac, AGENT_KEY, $request_encrypted) ) { // poly1305
                    wt_logs('VERIFYED: [hmac in body is wrong]', 'ERROR');
                    die(sendRequest(wt_handle_error($text='hmac in body is wrong', $code=8), $seskey));
                }
                wt_logs($seskey, '[hmac in body is right] seskey len('.wtam_strlen($seskey).')');
                $request = decrypt_chacha20($request_encrypted, $seskey, $nonce);
                wt_logs($request, 'request');
                return $request;
            }
            else {
                die(sendRequest(wt_handle_error($text='signature is incorrect', $code=1), $seskey));
            }
        }
    }

}
function receiveHashedRequest($seskey=AGENT_KEY){
    $header_encoded = getallheaders();
    $header_encoded = $header_encoded['Wt-Signature'];
    if (!$header_encoded) {
        wt_logs('header not found', 'ERROR');
        die('header not found');
    }
    wt_logs($header_encoded, 'header_encoded');
    $header = base64_decode($header_encoded);
    if (!$header) {
        wt_logs('header not decoded', 'ERROR');
        die('header not decoded');
    }
    wt_logs($header, 'header');
    $header_hmac = wtam_substr($header, 0, 16);
    $header_sign = wtam_substr($header, 16);

    if (!$header_hmac) {
        wt_logs('hmac not found', 'ERROR');
        die('hmac not found');
    }

    if( !verify($header_hmac, AGENT_KEY, $header_sign) ) { // poly1305
        wt_logs('VERIFYED: [hmac in header wrong]', 'ERROR');
        die('hmac in headers is wrong');
    }
    else {
        wt_logs('VERIFYED: [hmac in header is right]', 'INFO');
        $totem_request = file_get_contents("php://input");
        wt_logs($totem_request, 'totem_request');
        $totem_request_len = wtam_strlen($totem_request);
        wt_logs($totem_request_len, 'totem_request_len');
        
        $sign_good = false;
        if ( function_exists('sodium_crypto_sign_verify_detached') ) {
			if (CHECKSIGNATURE) {
				$sign_verify2 = sodium_crypto_sign_verify_detached($header_sign, $totem_request, PUBLIC_KEY);
				if ($sign_verify2) {
					wt_logs('YES', 'VERIFY 2');
					$sign_good = true;
				}
				else {
					wt_logs('NO', 'VERIFY 2');
					$sign_good = false;
				}
			}
		}
		else {
			$sign_good = true;
		}
			
        if ( ($sign_good && CHECKSIGNATURE) || (!CHECKSIGNATURE) ) {
            wt_logs('YES (or pass) SIGNATURED: sign in header right 0', 'INFO');
            $timestamp = wtam_substr($totem_request, 0, 8);
            $timestamp = unpack('P', $timestamp);
            $timestamp = $timestamp[1];
            wt_logs($timestamp, 'timestamp');
            $hash_temp = wtam_substr($totem_request, 8, 64); // sha512 (temp)
            wt_logs($hash_temp, 'hash_temp');
            $nonce = wtam_substr($totem_request, 72, 12); // nonce
            $hmac = wtam_substr($totem_request, 84, 16); // poly
            wt_logs($hmac, 'hmac');
            $request_encrypted = wtam_substr($totem_request, 100); // chacha20(temp)
            wt_logs($request_encrypted, 'request_encrypted');
            wt_logs(wtam_strlen($request_encrypted), 'request_encrypted (wtam_strlen)');
            if( !verify($hmac, AGENT_KEY, $request_encrypted) ) { // poly1305
                wt_logs('VERIFYED: [hmac in body is wrong] (receiveHashedRequest)', 'ERROR');
                die(sendRequest(wt_handle_error($text='hmac in body is wrong', $code=8), $seskey));
            }
            wt_logs($seskey, '[hmac in body is right] seskey');
            wt_logs(wtam_strlen($seskey), 'seskey (wtam_strlen)');
            $request = decrypt_chacha20($request_encrypted, $seskey, $nonce);
            wt_logs($request, 'request');
            $sha512_temp_str = hash('sha512', $request, true);
            if ($sha512_temp_str === $hash_temp) {
                $res = true;
                wt_logs('YES', 'Equal!');
            }
            else {
                $res = false;
                wt_logs('NO', 'Not equal!');
                wt_logs(base64_encode($sha512_temp_str), 'sha512_temp_str (base64)');
                wt_logs(base64_encode($hash_temp), 'hash_temp (base64)');
            }
            wt_logs($sha512_temp_str, 'sha512_temp_str');
            wt_logs($hash_temp, 'hash_temp');

            $return = array('hash'=>$hash_temp, 'test_str'=>$request, 'res'=>$res);
            wt_logs($return, 'return');
            return $return;
        }
		else {
			die(sendRequest(wt_handle_error($text='signature is incorrect', $code=1), $seskey));
		}
    }
}
function sendRequest($data='', $seskey=AGENT_KEY)
{
    $headers_for_send = headers_list();
    wt_logs($headers_for_send, 'headers_for_send');
	if (DEBUGAM===true) {
		return $data;
	}
	else {
		wt_logs('start', 'sendRequest');
		wt_logs($data, 'data');
		$nonce = randomStr(12);
		$encrypted_data = encrypt_chacha20($data, $seskey, $nonce); //chacha20
		$poly1305 = authenticate(AGENT_KEY, $encrypted_data); // poly1305
		$request = $nonce.$poly1305.$encrypted_data; 
		wt_logs($request, 'request');
		return $request;
	}
}
function resetStorage($storage_data = false) {
    wt_logs('resetStorage', 'INFO');
    $data_for_storage = array(
        'am'=>array(
            'version' => AM_VERSION,
            'timestamp' => AM_UPD,
            'name' => basename(__FILE__),
        ),
        'av'=>array(
            'version' => null,
            'timestamp' => null,
            'name' => null,
        ),
        'waf'=>array(
            'version' => null,
            'timestamp' => null,
            'name' => null,
        ),
    );
    if ($storage_data) {
        array_merge($data_for_storage, $storage_data);
    }
    wt_logs($data_for_storage, 'data_for_storage');
    $save_res = saveData($data_for_storage, $ses_storage=false);
    if ( $save_res === FALSE ) {
        die(sendRequest(microtime_pack().wt_handle_error($text='storage not saved', $code=6), AGENT_KEY));
    }
}
//////////////////////////////////////////////
///////////// BEGIN //////////////////////////
if ( isset($_GET) ) {
    if ( isset($_GET['ping']) ) {
        die(USER_IDENTIFIER);
    }
}
wt_logs('BEGIN', '___');
wt_logs('START', 'REQUEST');
$php_ver = phpversion();
wt_logs($php_ver, 'php_ver');
if (version_compare($php_ver, '5.6.0', '<')) {
	wt_logs($php_ver, 'less than PHP 5.6 versions is not supported');
	die('less than PHP 5.6 versions is not supported');
}
$empty = wtam_strlen(FILESTUB)+2;
wt_logs($empty, 'empty');
wt_logs(CACHE_DIR, 'CACHE_DIR');
wt_logs(STOCK_DIR, 'STOCK_DIR'); 

$storage_size = @filesize(CACHE_DIR);
wt_logs($storage_size, 'storage_size');
if ( file_exists(CACHE_DIR)===false || $storage_size <= $empty ) {
    wt_logs('CACHE_DIR', 'not found or small size');
    $stock_size = @filesize(STOCK_DIR);
    wt_logs($stock_size, 'stock_size');
    if (file_exists(STOCK_DIR)!==false || $stock_size > $empty ) { // STOCK is found
        wt_logs('STOCK_DIR', 'is found (and > empty)');
        $data_for_storage = getData($path=STOCK_DIR, $array=true);
        wt_logs($data_for_storage, 'data_for_storage');
        $save_res = saveData($data_for_storage, $ses_storage=false);
        if ( $save_res === FALSE ) {
            die(sendRequest(microtime_pack().wt_handle_error($text='storage not saved', $code=6), AGENT_KEY));
        }
    }
    else { // STOCK is not found
        wt_logs('STOCK_DIR', 'is not found');
        resetStorage(false);
    }
}
else {
    wt_logs('Default storage exist', 'INFO');
}
$storage_data = getData($ses_storage=false, $array=true);
if ( $storage_data === FALSE ) {
    die(sendRequest(microtime_pack().wt_handle_error($text='storage not allowed', $code=7), AGENT_KEY));
}
$logs = dirname(__FILE__).'/logs_'.wtam_substr(basename(__FILE__),0,10).'.txt';
$ses_name = randomStr(12);
$cookie_name = '_wtotem';
$allheaders = getallheaders();
wt_logs($allheaders, 'allheaders');
if (isset($_COOKIE[$cookie_name])) {
	$cook = $_COOKIE[$cookie_name];
	wt_logs($cook, 'cook');
	if ($cook) {
		$ses_name = $cook;
		wt_logs('SET', 'ses_name FROM COOKIE');
	}
}
wt_logs($ses_name, 'ses_name (RESULT)');
$sn = wtam_substr($ses_name, 0, 2).' ';
define('WTSN', $sn);
$ses_storage_exist = isset($storage_data[$ses_name]);
wt_logs($ses_storage_exist, 'ses_storage_exist');
if ( $ses_storage_exist ) {
	wt_logs($ses_name, 'ses_name (yes)');
	$seskey_decoded = base64_decode($storage_data[$ses_name]['seskey_base64']);
	$sesid = $storage_data[$ses_name]['sid'];
}
else {
	wt_logs($ses_name, 'ses_name (no)');
	$seskey_decoded = '00000000000000001111111111111111';
	$sesid = 0;
}
setcookie($cookie_name, $ses_name, time()+3600, "/", $_SERVER['SERVER_NAME'], false, true);
wt_logs($seskey_decoded, 'seskey_decoded');
wt_logs($cookie_name, 'cookie "name"');
wt_logs($ses_name, 'ses_name (cookies value)');
wt_logs($sesid, 'sesid (switch)');
switch ($sesid) {
    case 0:
        $request = receiveRequest();
        $SSPubKey = $request;
        $SSPub_base64 = base64_encode($SSPubKey);
        wt_logs($SSPub_base64, 'SSPub_base64');
        $CSKeys = Salt::box_keypair();
        $CSSecKey = $CSKeys[0];
        $CSPubKey = $CSKeys[1];
        $CSSecKey = byteObj2String($CSSecKey);
        $CSPubKey = byteObj2String($CSPubKey);
        $CSPubKey_base64 = base64_encode($CSPubKey);
        $CSSecKey_base64 = base64_encode($CSSecKey);
		if ( wtam_strlen($CSSecKey_base64) === 44 && wtam_strlen($SSPub_base64)=== 44 ) {
			$SesKey = Salt::scalarmult($CSSecKey_base64, $SSPub_base64);
			$SesKey = byteObj2String($SesKey);
			$SesKey_base64 = base64_encode($SesKey);
			wt_logs($SesKey_base64, 'SesKey (base64_encode)');
            $current_date = date(DATE_FORMAT);
            wt_logs($current_date, 'current_date');
			$data_for_ses = array(
				'sid' => 1,
				'seskey_base64' => $SesKey_base64,
                'date' => $current_date,
			);
			$storage_data[$ses_name] = $data_for_ses;
			wt_logs($storage_data, 'storage_data (updated)');
			saveData($storage_data, $ses_storage=false);
			$storage_data = getData($ses_storage=false, $array=true);
			$result = sendRequest($CSPubKey);
			wt_logs($result, 'result :::'.PHP_EOL.'END');
			die($result);
		}
		else {
			die(sendRequest(wt_handle_error($text='keys length error', $code=2)));
		}
        break;

    case 1:
        $request = receiveHashedRequest($seskey_decoded);
        wt_logs($request, 'request');
        $hash = $request['hash']; // 64 byte sha512
        $test_str = $request['test_str'];
        $hashed_test_str = hash('sha512', $test_str, true);
        $equal = strcasecmp($hash, $hashed_test_str);
        $storage_data[$ses_name]['sid'] = 2;
        if ($equal === 0) {
            wt_logs('DONE!', 'strings is equal');
            //saveData($storage_data, STOCK_DIR);
        }
        else {
            wt_logs('NONE!', 'strings is NOT equal');
			die(sendRequest(wt_handle_error($text='strings is not equal', $code=3)));
        }
        $send = $test_str.USER_IDENTIFIER;
        $result = sendRequest($send, $seskey_decoded);
        wt_logs($result, 'result :::'.PHP_EOL.'END');
        saveData($storage_data, $ses_storage=false);
		$storage_data = getData($ses_storage=false, $array=true);
		wt_logs($storage_data, 'storage_data sesid 2');
        die($result);
        break;
    
    default:
        $request = receiveRequest($seskey_decoded);
		wt_logs('request', 'receiveRequest($seskey_decoded)');
        $sesid += 1;
        $storage_data[$ses_name]['sid'] = $sesid;
        wt_logs($request, 'request');
        $json = json_decode($request, true);
        if ($json !== NULL && $json !== FALSE) {
            $cmd = $json['cmd'];
			$module = $json['module'];
            wt_logs($cmd, 'cmd');
            switch ($cmd) {
				case 'update_waf':
                    $data = update_agent_inc('waf', $json['params']['filename'], $json['params']['content'], $json['params']['upd_time'], $json['params']['agent_version']);
                    $data = json_encode($data);
                    $send = microtime_pack().$data;
                    $result = sendRequest($send, $seskey_decoded);
                    die($result);

                    break;

                case 'update_av':
					$data = update_agent_inc('av', $json['params']['filename'], $json['params']['content'], $json['params']['upd_time'], $json['params']['agent_version']);
                    $data = json_encode($data);
                    $send = microtime_pack().$data;
                    $result = sendRequest($send, $seskey_decoded);
                    die($result);

                    break;
				
				case 'update_am':
                    $check_res = check_update_agent();
                    wt_logs($check_res, 'check_res');
					$data = update_agent($module='am', $json['params']['filename'], $json['params']['content'], $json['params']['upd_time'], $json['params']['agent_version']);
                    $data = json_encode($data);
                    $send = microtime_pack().$data;
                    $result = sendRequest($send, $seskey_decoded);
                    die($result);

                    break;
				
                case 'get_upd_timestamp':
                    $timestamp = '';
                    $text = 'timestamp not found';
					if (isset($storage_data[$module]['timestamp'])) {
                        $timestamp = $storage_data[$module]['timestamp'];
                        $text = 'timestamp from storage';
                    }					
					wt_logs($timestamp, ' timestamp ('.$module.')');
					$data = array('version'=>AM_VERSION, 'result'=>array('status'=>100, 'cmd'=>'get_upd_timestamp', 'timestamp'=>$timestamp), 'text'=>$text);
					wt_logs($data, 'data');
					$data = json_encode($data);
					$send = microtime_pack().$data;
					$result = sendRequest($send, $seskey_decoded);
					die($result);
					
                    break;
				
				case 'postinstall':
					$res = false; $error = 'start error';
					if ($module === 'waf' ) {
						$waf_agent = $storage_data['waf']['name'];
						$waf_key = $json['key'];
						$agent_code = prepare_agent_inc('waf', $waf_agent, $waf_key);
                        if ($agent_code !== false) {
                            eval($agent_code);
                            if ( class_exists('Waf') ) {
                                wt_logs('exists', 'class Waf');
                                $waf = new Waf;
                                $result = $waf->cmd_create_file();
                                $result_decode = json_decode($result, true);
                                if ($result_decode['result']['status'] === 1) {
                                    if (WTWPP!==true) {
                                        // include waf
                                        $base_path = dirname(__FILE__).'/';
                                        $entrypoint = 'index.php';
                                        $target = $base_path.$entrypoint;
                                        $waf_agent_inc = '_include_'.$waf_agent; //prefix
                                        $include = '<?php $wtwaf = dirname(__FILE__) ."/'.$waf_agent_inc.'"; if (file_exists($wtwaf)) { @include_once($wtwaf); } unset($wtwaf); ?>'.PHP_EOL;
                                        $target_content = file_get_contents($target);
                                        $include_len = wtam_strlen($include);
                                        $start = wtam_substr($target_content, 0, $include_len);
                                        if ( $start !== $include ) {
                                            $included = $include.$target_content.PHP_EOL;
                                            $res = file_put_contents($target, $included, LOCK_EX);
                                            $res_text = 'insert in entrypoint (now)';
                                        }
                                        else {
                                            $res = true;
                                            $res_text = 'was included in entrypoint (earlier)';
                                        }
                                    }
                                    else {
                                        $res = true;
                                        $res_text = 'no need include in entrypoint (WP)';
                                    }
                                }
                                else {
                                    $res = false;
                                    $error = 'create file error (inc)';
                                }
                            }
                            else {
                                $res = false;
                                $error = 'prepare file error: decrypt (waf)';
                            }
                        }
                        else {
                            $res = false;
                            $error = 'prepare file error: content of file (waf)';
                        }
					}
                    if ($module === 'av' || $module === 'am' ) {
						$res = true;
                        $res_text = 'nothing to do (av|am)';
                    }
					
					if ($res !== false) {
						$data = array('version'=>AM_VERSION, 'result'=>array('status'=>100, 'cmd'=>'postinstall', 'postinstall_status'=>100, 'text'=>$res_text));
                        $data = json_encode($data);
                        $send = microtime_pack().$data;
                        $result = sendRequest($send, $seskey_decoded);
                        die($result);
					}
					else {
						die(sendRequest(microtime_pack().wt_handle_error($text=$error, $code=5), $seskey_decoded));
					}

                    break;
				
				case 'delete':
                    $waf_agent = $storage_data['waf']['name'];
                    wt_logs($waf_agent, 'waf_agent');
                    wt_logs($module, 'module');
					if ($module==='am') {
						unlink($storage_data['av']['name']);
						unlink($waf_agent);
						postdelete($module='waf', $waf_agent);
                        wt_logs($storage_data, 'storage_data');
                        $waf_dir = wt_check_cache_dir_for_waf($waf_agent); // TODO wp dir
                        wt_logs($waf_dir, 'waf_dir');
						deleteStorage();
                        deleteWAFStorage($waf_dir, $waf_agent);
                        $module = 'am,av,waf';
                        if (DEBUGAM===true) {
                            wt_logs('DEBUGAM = true', 'INFO');
                            rename($storage_data['am']['name'], $storage_data['am']['name'].'_deleted');
                        }
                        else {
                            wt_logs('DEBUGAM = false', 'INFO');
                            @unlink($storage_data['am']['name']);
                        }
                        wt_logs($module, '$module');
					}
					else {
						@unlink($storage_data[$module]['name']);
						$storage_data = array(
							$module=>array(
								'version' => 0,
								'timestamp' => 'deleted',
								'name' => 'deleted',
							)
						);
                        wt_logs($storage_data, '$storage_data');
						updateData($storage_data, $ses_storage=false);

                        if ($module==='waf') {
                            wt_logs($module, '$module (postdelete)');
                            postdelete($module='waf', $waf_agent);
                            $waf_dir = wt_check_cache_dir_for_waf($waf_agent); // TODO
                            deleteWAFStorage($waf_dir, $waf_agent);
                        }
                        wt_logs($storage_data, '$storage_data');
					}
                    $data = array('version'=>AM_VERSION, 'result'=>array('status'=>100, 'cmd'=>'delete', 'module'=>$module, 'delete_status'=>100));
                    wt_logs($data, '$data');
                    $data = json_encode($data);
                    $send = microtime_pack().$data;
                    wt_logs($send, '$send');
                    $result = sendRequest($send, $seskey_decoded);
                    wt_logs($send, '$send');
                    die($result);

                    break;
				
                case 'get_stats':
                case 'get_server_stats': //dynamic
                    $data = get_server_stats();
                    $send = microtime_pack().$data;
                    $result = sendRequest($send, $seskey_decoded);
                    wt_logs($send, '$send');
                    die($result);

                    break;

                case 'get_info':
                case 'get_server_info': // static
                    $data = get_server_info();
                    $send = microtime_pack().$data;
                    $result = sendRequest($send, $seskey_decoded);
                    wt_logs($send, '$send');
                    die($result);

                    break;

				case 'logout':
					unset($storage_data[$ses_name]);
                    $storage_data = checkSessions($storage_data);
                    saveData($storage_data, $ses_storage=false);
                    $data = array('version'=>AM_VERSION, 'result'=>array('status'=>100, 'cmd'=>'logout'));
                    $data = json_encode($data);
                    $send = microtime_pack().$data;
                    $result = sendRequest($send, $seskey_decoded);
                    die($result);

                    break;
				
                default:
                    wt_logs($json['cmd'], 'json[cmd]');
                    break;
            }
			
			$waf_agent = $storage_data['waf']['name'];
			$waf_key = $json['key'];
			if ( $module==='waf' ) {
				if ( file_exists($waf_agent) && $waf_key ) {
                    $agent_code = prepare_agent_inc($module, $waf_agent, $waf_key);
                    if ($agent_code !== false) {
                        eval($agent_code);
    					if (class_exists('Waf')) {
    						$waf = new Waf;
    						$params = $json['params'];
    						switch ($cmd) {
    							/////////////////////////////////////////////////////
    							/////////////////////// WAF /////////////////////////
    							case 'ping': // Agent instalation confirmation
    								die(TOTEM_VERIFY_CODE);
    								break;

    							case 'init': // Initialization
    								$send = $waf->cmd_init($params);
    								break;

    							case 'get_blacklist': // Blacklist
    								$send = $waf->cmd_get_blacklist($params);
    								break;

    							case 'update_signatures': //Add/Del signs (1/0)
    								$send = $waf->cmd_update_signatures($params, TOTEM_SIGNATURES_DB);
    								break;

    							case 'update_signatures_files': // Add/del signs for files (1/0)
    								$send = $waf->cmd_update_signatures($params, TOTEM_SIGNATURES_FILES_DB);
    								break;

    							case 'update_blacklist': // Add/Del ip from blacklist (1/0)
    								$send = $waf->cmd_update_blacklist($params);
    								break;

    							case 'update_full_signatures':
    								$send = $waf->cmd_update_full_signatures($params);
    								break;

    							case 'update_full_blacklist':
    								$send = $waf->cmd_update_full_blacklist($params);
    								break;

    							case 'update_full_whitelist':
    								$send = $waf->cmd_update_full_whitelist($params);
    								break;

    							case 'update_full_checklist':
    								$send = $waf->cmd_update_full_checklist($params);
    								break;

    							case 'get_full_blacklist':
    								$send = $waf->cmd_get_full_blacklist($params);
    								break;

    							case 'get_whitelist':
    								$send = $waf->cmd_get_whitelist($params);
    								break;

    							case 'get_checklist':
    								$send = $waf->cmd_get_checklist($params);
    								break;

    							case 'get_stats': // Statistic
    								$send = $waf->cmd_get_stats($params);
    								break;

    							case 'get_full_stats': // Statistic per requests
    								$send = $waf->cmd_get_full_stats($params);
    								break;

    							case 'get_config': // Get user configs (all configs)
    								$send = $waf->cmd_get_configs($params);
    								break;

    							case 'set_config': // Set user configs (all configs)
    								$send = $waf->cmd_set_configs($params);
    								break;

    							case 'get_logs': // Get requests logs
    								$send = $waf->cmd_get_logs();
    								break;
                                
                                default:
                                    $send = json_encode(array('version'=>'','result'=>'cmd not found'));
                                    break;
    						}
    						$send = microtime_pack().$send;
    						$result = sendRequest($send, $seskey_decoded);
    						die($result);
    					}
                        else {
                            $error_text = 'prepare file error: decrypt (waf)';
                            $error_code = 20;
                        }
                    }
                    else {
                        $error_text = 'prepare file error: content of file (waf)';
                        $error_code = 21;
                    }
				}
				else {
                    $error_text = 'KEY or AGENT does not exist (waf)';
                    $error_code = 22;
                    wt_logs($waf_agent, 'waf_agent');
                    wt_logs($waf_key, 'waf_key');
                    if (!$waf_agent) {
                        resetStorage($storage_data);
                    }
				}
                wt_logs($error_text, 'error_text');
                die(sendRequest(microtime_pack().wt_handle_error($text=$error_text, $code=$error_code), $seskey_decoded));
			}
            /*** FOR AV (begin) ***/
            $av_agent = $storage_data['av']['name'];
            $av_key = $json['key'];
            if ( $module==='av' ) {
                if ( file_exists($av_agent) && $av_key ) {
                    $agent_code = prepare_agent_inc($module, $av_agent, $av_key);
                    if ($agent_code !== false) {
                        eval($agent_code);
                        
                        if (class_exists('AV')) {
                            $av = new AV;
                            $params = $json['params'];
                            switch ($cmd) {
                                ////////////// AV /////////////
                                case 'ping': // Agent instalation confirmation
                                    die(TOTEM_VERIFY_CODE);
                                    break;

                                case 'init': // Initialization
                                    $send = $av->cmd_init($params);
                                    break;

                                case 'status': // Server status
                                    $send = $av->cmd_status($params);
                                    break;

                                case 'get_tree': // Get tree files
                                    $get_tree_start = microtime(true);
    								if ( isset($storage_data[$ses_name]['files_count']) ) {
    									$count = $storage_data[$ses_name]['files_count'];
    								}
    								else {
    									$count = count_files();
                                        $count_files_finish = microtime(true);
                                        wt_logs($count_files_finish-$get_tree_start, 'count_files secs');
    									$storage_data[$ses_name]['files_count'] = $count;
    									saveData($storage_data, $ses_storage=false);
                                        wt_logs($av_key, 'av_key');
    								}
                                    $send = $av->cmd_get_tree($params);
    								$send['result']->count = $count;
    								$send = json_encode($send);
                                    $get_tree_finish = microtime(true);
                                    wt_logs($get_tree_finish-$get_tree_start, 'get_tree secs');
                                    break;

                                case 'get_changes': // Get files changes
                                    $get_changes_start = microtime(true);
                                    if ( isset($storage_data[$ses_name]['files_count']) ) {
                                        $count = $storage_data[$ses_name]['files_count'];
                                    }
                                    else {
                                        $count = count_files();
                                        $count_files_finish = microtime(true);
                                        wt_logs($count_files_finish-$get_tree_start, 'count_files secs');
                                        $storage_data[$ses_name]['files_count'] = $count;
                                        saveData($storage_data, $ses_storage=false);
                                    }
                                    $dir = dirname(CACHE_DIR);
                                    $new_dir = '.wtotem_av_'.wtam_substr(basename(__FILE__),0,12);
                                    $storage_path = wt_check_dir($dir, $new_dir);
                                    wt_logs($storage_path, 'storage_path');

                                    $send = $av->cmd_get_changes($storage_path, $count, $params);
                                    $send['result']['count'] = $count;
                                    $send = json_encode($send);
                                    $get_changes_finish = microtime(true);
                                    wt_logs($get_changes_finish-$get_changes_start, 'get_changes secs');
                                    break;

                                case 'get_file': // get_file
                                    $send = $av->cmd_get_file($params);
                                    break;

                                case 'to_quarantine': // Move to quarantine
                                    $to_quarantine_start = microtime(true);
                                    $send = $av->cmd_to_quarantine($params);
                                    $to_quarantine_finish = microtime(true);
                                    wt_logs($to_quarantine_finish-$to_quarantine_start, 'to_quarantine secs');
                                    break;

                                case 'from_quarantine': // Restore from quarantine
                                    $from_quarantine_start = microtime(true);
                                    $send = $av->cmd_from_quarantine($params);
                                    $from_quarantine_finish = microtime(true);
                                    wt_logs($from_quarantine_finish-$from_quarantine_start, 'from_quarantine secs');
                                    break;
                            }
                            $send = microtime_pack().$send;
                            $result = sendRequest($send, $seskey_decoded);
                            die($result);
                        }
                        else {
                            $error_text = 'prepare file error: decrypt (av)';
                            $error_code = 30;
                            wt_logs($av_key, 'av_key');
                        }
                    }
                    else {
                        $error_text = 'prepare file error: content of file (av)';
                        $error_code = 31;
                    }
                }
                else {
                    $error_text = 'KEY or AGENT does not exist (av)';
                    $error_code = 32;
                    wt_logs($av_agent, 'av_agent');
                    wt_logs($av_key, 'av_key');
                    if (!$av_agent) {
                        resetStorage($storage_data);
                    }
                }
                wt_logs($error_text, 'error_text');
                die(sendRequest(microtime_pack().wt_handle_error($text=$error_text, $code=$error_code), $seskey_decoded));
            }
            /* FOR AV (end) */
        }
		else {
			die(sendRequest(microtime_pack().wt_handle_error($text='json is not correct', $code=4), $seskey_decoded));
		}
        break;
}


function postdelete($module='waf', $waf_name='') {
	if ($module === 'waf' ) {
		$res = false;
		$base_path = dirname(__FILE__).'/';
        wt_logs($base_path, '$base_path');
		$entrypoint = 'index.php';
        wt_logs($entrypoint, '$entrypoint');
		$target = $base_path.$entrypoint;
        wt_logs($target, '$target');
        $start_waf = wtam_substr($waf_name,0,9);
        if ($start_waf!=='_include_') { $waf_name = '_include_'.$waf_name; }
        wt_logs($waf_name, '$waf_name');
		$include = '<?php $wtwaf = dirname(__FILE__) ."/'.$waf_name.'"; if (file_exists($wtwaf)) { @include_once($wtwaf); } unset($wtwaf); ?>'.PHP_EOL;
        wt_logs($include, '$include');
		$include_len = wtam_strlen($include);
        wt_logs($include_len, '$include_len');
		$target_content = file_get_contents($target);
		wt_logs($target_content, 'target_content');
		$pos = wtam_stripos($target_content, $include);
        wt_logs($pos, '$pos');
		if ( $pos !== false ) {
			$cutted = wtam_substr($target_content, 0, $pos) . wtam_substr($target_content, ($pos + $include_len) ); 
			wt_logs($cutted, 'cutted'); 
			$res = file_put_contents($target, $cutted, LOCK_EX);
		}
        if ( file_exists($waf_name) ) {
            unlink($waf_name);
        }
        wt_logs($res, '$res');
		return $res;
	}
}
function update_agent($module, $filename, $content, $upd_time, $agent_version) {
	$path = dirname(__FILE__).'/'.$filename;
	$update_res = file_put_contents($path, $content, LOCK_EX);
	if ( $update_res !== false ) {				
		$data_for_storage = array(
			$module=>array(
				'version' => $agent_version,
				'timestamp' => $upd_time,
				'name' => $filename,
			)
		);
		updateData($data_for_storage, $ses_storage=false);
		$storage_data = getData($ses_storage=false, $array=true);
		$data = array('version'=>AM_VERSION, 'result'=>array('status'=>100, 'cmd'=>'update_'.$module, 'install_status'=>100));
	}
	else {
		$data = array('version'=>AM_VERSION, 'result'=>array('status'=>-1, 'cmd'=>'update_'.$module, 'install_status'=>-1, 'text'=>'agent was not updated (permissions)'));
	}
    wt_logs($data, 'data');
	return $data;
}

function update_agent_inc($module, $filename, $content, $upd_time, $agent_version) {
    $path = dirname(__FILE__).'/'.$filename;
    $content = '<?php if (isset($_GET["ping"])) { die("'.USER_IDENTIFIER.'");} $agent_content = \''.$content.'\'; ?>';
    $update_res = file_put_contents($path, $content, LOCK_EX);
    if ( $update_res !== false ) {              
        $data_for_storage = array(
            $module=>array(
                'version' => $agent_version,
                'timestamp' => $upd_time,
                'name' => $filename,
            )
        );
        updateData($data_for_storage, $ses_storage=false);
        $storage_data = getData($ses_storage=false, $array=true);
        $data = array('version'=>AM_VERSION, 'result'=>array('status'=>100, 'cmd'=>'update_'.$module, 'install_status'=>100));
    }
    else {
        $data = array('version'=>AM_VERSION, 'result'=>array('status'=>-1, 'cmd'=>'update_'.$module, 'install_status'=>-1, 'text'=>'agent was not updated (permissions)'));
    }
    wt_logs($data, 'data');
    return $data;
}
function check_update_agent() {
    $am = __FILE__;
    $am_new = $am.'_new';
    if ( !is_writable($am) ) {
        wt_logs('no', 'writable_01');
        if ( is_readable($am) ) {
            $content = file_get_contents($am);
            $create_status = file_put_contents($am_new, $content);
            if ($create_status !== false) {
                unlink($am);
                wt_logs($am_new.' -> '.$am, 'rename');
                rename($am_new, $am);
            }
        }
    }
    if ( !is_writable($am) ) {
        wt_logs('no', 'writable_02');
        chmod($am, 0666);
    }
    if ( is_writable($am) ) {
        wt_logs('done', 'writable_03');
        return true;
    }
    wt_logs('no', 'writable_03');
    return false;
}
function prepare_agent_inc($module='waf', $filename, $key) {
    wt_logs($filename, 'filename');
    if (file_exists($filename)) {
        include_once($filename);
        if (isset($agent_content)) {
            $agent_content = base64_decode($agent_content); // nonce + hmac + encrypted
            $nonce = wtam_substr($agent_content, 0, 12); // nonce 12
            $hmac = wtam_substr($agent_content, 12, 16); // hmac 16
            $agent_content_encrypted = wtam_substr($agent_content, 28); // encrypted 28>all
            if( !verify($hmac, AGENT_KEY, $agent_content_encrypted) ) { // poly1305
                wt_logs('VERIFYED: hmac in agent is wrong (prepare_agent)', 'ERROR');
                die(sendRequest(wt_handle_error($text='hmac in agent is wrong', $code=9), $seskey));
            }
            $agent_content_decrypted = decrypt_chacha20($agent_content_encrypted, $key, $nonce);
            wt_logs(wtam_substr($agent_content_decrypted, 0, 400), 'agent_content_decrypted');
            return $agent_content_decrypted;
        }
        else {
            wt_logs('not found', 'agent_content');
            return false;
        }
    }
    else {
        wt_logs('not found', 'filename');
        return false;
    }
}

function wt_check_dir($dir=false, $new_dir=false) {
    $new_dir_full = $dir.'/'.$new_dir.'/';
    if (is_dir($new_dir_full) && is_writeable($new_dir_full)) $dir = $new_dir_full;
    elseif ( mkdir($new_dir_full, 0755, true) ) $dir = $new_dir_full;
    else $dir = $dir.'/';

    return $dir;
}

function wt_check_cache_dir_for_waf($waf_agent=false) {
    $dir = '';
    $new_dir = '.wtotem_waf_'.substr($waf_agent, 0, 12);
    if (WTWPP === true) { // WP plugin
        $wp_dir = $_SERVER['DOCUMENT_ROOT'].'/wp-content/uploads';
        $dir = wt_check_dir($wp_dir, $new_dir);
    }
    elseif (is_writeable(session_save_path())) { // Next, check php session storage directory
        $ses_dir = session_save_path();
        $dir = wt_check_dir($ses_dir, $new_dir);
    }
    elseif (is_writeable($_SERVER['DOCUMENT_ROOT'])) { // Next, check root directory of the site
        $root_dir = $_SERVER['DOCUMENT_ROOT'];
        $dir = wt_check_dir($root_dir, $new_dir);
    }
    elseif (is_writeable(sys_get_temp_dir())) {  // Lastly, check temporary directory
        $tmp_dir = sys_get_temp_dir(); 
        $dir = wt_check_dir($tmp_dir, $new_dir);
    }
    else $dir = null;

    return $dir;
}

function wt_check_cache_dir_for_quar($prefix=false) {
    $dir = '';
    $new_dir = '.wtotem_data_'.$prefix;
    if (is_writeable(session_save_path()) && session_save_path() !== sys_get_temp_dir() ) { // Check php session storage directory
        $ses_dir = session_save_path();
        $dir = wt_check_dir($ses_dir, $new_dir);
    }
    elseif (is_writeable($_SERVER['DOCUMENT_ROOT'])) { // Next, check root directory of the site
        $root_dir = $_SERVER['DOCUMENT_ROOT'];
        $dir = wt_check_dir($root_dir, $new_dir);
    }
    else $dir = null;

    return $dir;
}
   
function microtime_pack() {
    list($microsec, $sec) = explode(" ", microtime());
    $time = intval($sec.$microsec);
    $time2 = microtime(true)*10000;
    $time3 = (microtime(true)*10000);
    $data = pack('P', $time3);
    return $data;
}

function count_files($dir=false) {
	if ($dir===false) { $dir = dirname(__FILE__); }
	$files = scandir($dir); $i = 0;
    wt_logs('start', 'count_files');
	foreach ($files as $file){
		if (!in_array($file, array(".", ".."))){
			if(is_file($dir.'/'.$file)){$i = $i + 1;}
			if(is_dir($dir.'/'.$file)){$i += count_files($dir.'/'.$file);}
		} 
	}
	return $i;
}

function daysBetween($dt1, $dt2) {
    return date_diff(
        date_create($dt2),  
        date_create($dt1)
    )->format('%a');
}

function get_server_stats() { // dynamic
    $response = array();
    $response['version'] = AM_VERSION;
    $mem_total = $mem_use = 0;
    $space_total = $space_free = 0;
    $cpu_percent = 0;
    $loadavg_1 = $loadavg_5 = $loadavg_15 = 0;
    $win = stristr(PHP_OS, "win");
    wt_logs($win, 'win');

    $shell_exec_enabled = isEnabled('shell_exec');
    $exec_enabled = isEnabled('exec');
    if ($win) {
        // space
        $disks = array ('C', 'D', 'E', 'F', 'G', 'H', 'I', 'M', 'X', 'Z');
        $free = $total = 0;
        foreach ($disks as $disk) {
            $d = $disk.':\\';
            $total += @disk_total_space($d);
            $free += @disk_free_space($d);
        }
        $space_total = round(($total/1048576)); // bytes -> Mb
        $space_free = round(($free/1048576)); // bytes -> Mb
        // memory (ram)

        if ($exec_enabled) {
            // Get total physical memory (this is in bytes)
            $cmd = "wmic ComputerSystem get TotalPhysicalMemory";
            @exec($cmd, $outputTotalPhysicalMemory);
            wt_logs($outputTotalPhysicalMemory, 'outputTotalPhysicalMemory');
            // Get free physical memory (this is in kibibytes!)
            $cmd = "wmic OS get FreePhysicalMemory";
            @exec($cmd, $outputFreePhysicalMemory);
            wt_logs($outputFreePhysicalMemory, 'outputFreePhysicalMemory');
            if ($outputTotalPhysicalMemory && $outputFreePhysicalMemory) {
                // Find total value
                foreach ($outputTotalPhysicalMemory as $line) {
                    if ($line && preg_match("/^[0-9]+\$/", $line)) {
                        $mem_total = $line;
                        break;
                    }
                }

                // Find free value
                foreach ($outputFreePhysicalMemory as $line) {
                    if ($line && preg_match("/^[0-9]+\$/", $line)) {
                        $memoryFree = $line;
                        $memoryFree *= 1024;  // convert from kibibytes to bytes
                        $mem_use = $mem_total - $memoryFree;
                        break;
                    }
                }
                $mem_total = round(($mem_total/1048576)); // bytes -> Mb
                $mem_use = round(($mem_use/1048576)); // bytes -> Mb
            }
        }
    }
    else {
        // space
        $space_total = disk_total_space("/"); // bytes
        $space_free = disk_free_space("/"); // bytes
        $space_total = round(($space_total/1048576)); // bytes -> Mb
        $space_free = round(($space_free/1048576)); // bytes -> Mb

        // cpu
        $loadavg = sys_getloadavg();
        $mul = 100;
        $loadavg_1 = round( ($loadavg[0]*$mul) );
        $loadavg_5 = round( ($loadavg[1]*$mul) );
        $loadavg_15 = round( ($loadavg[2]*$mul) );

        $cpu_percent = 0;
        if ($shell_exec_enabled) {
            $free = shell_exec('free -m');
            $free = (string)trim($free);
            $free_arr = explode("\n", $free);
            $mem = explode(" ", $free_arr[1]);
            $mem = array_filter($mem);
            $mem = array_merge($mem);
            $mem_total = (int)$mem[1];
            $mem_use = (int)$mem[2];
        }
        else {
            wt_logs('shell_exec not enabled', 'INFO');
            $file = '/proc/meminfo';
            if (file_exists($file)) {
                if (is_readable($file)) {
                    $meminfo = getSystemInfo($file);
                    $mem_total = (int)trim(substr($meminfo['MemTotal'],0,-3));
                    $mem_available = (int)trim(substr($meminfo['MemAvailable'],0,-3));
                    $mem_free = (int)trim(substr($meminfo['MemFree'],0,-3));
                    $mem_use = $mem_total - $mem_available - $mem_free;
                    // kb in mb
                    $mem_total = round($mem_total/1024);
                    $mem_available = round($mem_available/1024);
                    $mem_free = round($mem_free/1024);
                    $mem_use = round($mem_use/1024);
                }
            }
        }
    }
    $cpu_used_percent = getServerLoad();
    wt_logs($cpu_used_percent, 'cpu_used_percent');
    // dynamic status start 
    $result = array();
    $result['space'] = array('total'=>$space_total, 'free'=>$space_free);
    $result['memory'] = array('total'=>$mem_total, 'used'=>$mem_use, 'use'=>$mem_use);
    $result['cpu'] = array('used_percent'=>$cpu_used_percent, 'loadavg_1'=>$loadavg_1, 'loadavg_5'=>$loadavg_5, 'loadavg_15'=>$loadavg_15);
    $result['shell_exec'] = $shell_exec_enabled;
    $result['exec'] = $exec_enabled;
    $result['win'] = $win;
    $response['result'] = $result;
    return json_encode($response);
}

function get_server_info() { // static
    $response = array();
    $response['version'] = AM_VERSION;
    // cpu
    $cpu = array();
    $cpu['count'] = 0;
    $cpu['model'] = '';
    $cpu['family'] = '';
    $cpu['lscpu'] = '';
    $cpu['frequency'] = 0;
    if (isEnabled('shell_exec')) {
        $cpu['count'] = (int)trim(shell_exec('nproc'));
        $lscpu = shell_exec('lscpu');
        $cpu['lscpu'] = $lscpu;
        foreach (explode("\n", $lscpu) as $str) {
            $val =  explode(":", $str);
            if ($val[0] === 'Model name') $cpu['model'] = trim($val[1]);
            if ($val[0] === 'CPU MHz') $cpu['frequency'] = (int)trim($val[1]);
            if ($val[0] === 'CPU family') $cpu['family'] = trim($val[1]);
        }
    }
    else {
        wt_logs('shell_exec not enabled', 'INFO');
        $file = '/proc/cpuinfo';
        if (file_exists($file)) {
            if (is_readable($file)) {
                $cpuinfo = file_get_contents($file);
                $cpuinfo = str_replace(":", "", $cpuinfo);
                if ($cpuinfo !== false) {
                    $cpu['count'] = (int)trim(substr(str_replace("cpu cores", "", $cpuinfo[12]),0,-1));
                    $cpu['model'] = trim(substr(str_replace("model name", "", $cpuinfo[4]),0,-1));
                    $cpu['family'] = trim(substr(str_replace("cpu family", "", $cpuinfo[2]),0,-1));
                    $cpu['frequency'] = (int)trim(substr(str_replace("cpu MHz", "", $cpuinfo[7]),0,-1));
                    $cpu['lscpu'] = $cpuinfo;
                }
            }
        }
    }
    $math = function_exists('bccomp') ? 1 : 0;
    $math += function_exists('gmp_cmp') ? 2 : 0;

    $server = array_filter($_SERVER, function ($k)
        {
            return in_array($k, 
                array('USER',
                'SERVER_SOFTWARE',
                'GATEWAY_INTERFACE',
                'SERVER_PROTOCOL'));
        }, ARRAY_FILTER_USE_KEY);
    $server = array_change_key_case($server);
    $result = array();
    $result['php_version'] = phpversion();
    $result['php_server'] = $server;
    $result['os_info'] = php_uname();
    $result['cpu'] = $cpu;
    $result['max_execution_time'] = (int)ini_get('max_execution_time');
    $result['math'] = $math;
    $response['result'] = $result;
    return json_encode($response);
}
function isEnabled($func) {
    return is_callable($func) && false === stripos(ini_get('disable_functions'), $func);
}
function getSystemInfo($file='/proc/meminfo') {
    $data = explode("\n", file_get_contents($file));
    $info = array();
    foreach ($data as $line) {
        list($key, $val) = explode(":", $line);
        $info[$key] = trim($val);
    }
    return $info;
}
function get_cpu_stat_unix() {
    if (is_readable("/proc/stat")) {
        $stats = @file_get_contents("/proc/stat");
        if ($stats !== false) {
            wt_logs($stats, 'stats');
            $stats = preg_replace("/[[:blank:]]+/", " ", $stats); // Remove double spaces
            $stats = str_replace(array("\r\n", "\n\r", "\r"), "\n", $stats); // Split lines
            $stats = explode("\n", $stats);
            // find line "cpu"
            foreach ($stats as $statLine) {
                $statLineData = explode(" ", trim($statLine));
                if ( (count($statLineData) >= 5) && ($statLineData[0] == "cpu") ) { // cpu line
                    return array($statLineData[1], $statLineData[2], $statLineData[3], $statLineData[4]);
                }
            }
        }
    }
    return null;
}

// Returns server load in percent (just number, without percent sign)
function getServerLoad() {
    $load = 0;
    if (stristr(PHP_OS, "win")) {
        if (isEnabled('exec')) {
            wt_logs('enabled', 'exec');
            $cmd = "wmic cpu get loadpercentage /all";
            @exec($cmd, $output);
            wt_logs($output, 'output');
            if ($output) {
                foreach ($output as $line) {
                    if ($line && preg_match("/^[0-9]+\$/", $line)) {
                        $load = $line;
                        break;
                    }
                }
            }
        }
    }
    else {
        if (is_readable("/proc/stat")) {
            // Get 2 data, period 1 second
            $statData1 = get_cpu_stat_unix();
            sleep(2);
            $statData2 = get_cpu_stat_unix();
            if ( (!is_null($statData1)) && (!is_null($statData2)) ) {
                wt_logs($statData1, 'statData1');
                wt_logs($statData2, 'statData2');
                // Get difference
                $statData2[0] -= $statData1[0];
                $statData2[1] -= $statData1[1];
                $statData2[2] -= $statData1[2];
                $statData2[3] -= $statData1[3];
                wt_logs($statData2, 'statData2');
                // Sum up the 4 values for User, Nice, System and Idle and calculate
                // the percentage of idle time (which is part of the 4 values!)
                $cpuTime = $statData2[0] + $statData2[1] + $statData2[2] + $statData2[3];
                wt_logs($cpuTime, 'cpuTime');
                // Invert percentage to get CPU time, not idle time
                $load = round( 100 - ($statData2[3] * 100 / $cpuTime) );
            }
        }
    }

    return $load;
}

?> 
